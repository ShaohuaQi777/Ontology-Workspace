const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/DecisionWorkspace-DLnQoq1W.js","assets/query-vendor-CCrh9h3E.js","assets/info-BUvV26o9.js","assets/DiffMergeWorkspace-DIj2n0oj.js","assets/registryStore-Bnz_Y7r9.js","assets/circle-check-DspmkRLn.js","assets/loader-circle-Do0Q6Lag.js","assets/GraphWorkspace-Dny3nAOi.js","assets/graph-vendor-C_DST6AN.js","assets/graphTheme-CZgtRLnq.js","assets/refresh-cw-gtzKVcUm.js","assets/layers-CQLDPxzU.js","assets/git-branch-B3NGDAwg.js","assets/play-B-Zhq3Fq.js","assets/x-DOS2XFef.js","assets/MemoryWorkspace-sxRCjA3X.js","assets/MarkdownContentViewer-BllL_0Qy.js","assets/copy-DgtYINVh.js","assets/pencil-BlxMtHjL.js","assets/external-link-CMyTuHz0.js","assets/ImportExportWorkspace-XEcfgbkG.js","assets/index-DeRyCZnz.js","assets/file-text-DPB4thcG.js","assets/download-D6KY8v_c.js","assets/LineageDiagram-B3vC6gPJ.js","assets/style-CAMR42T6.js","assets/index-CVqD6U61.js","assets/style-BZV40eAE.css","assets/ReasoningWorkspace-DIR9Cx8Q.js","assets/SparqlWorkspace-Cb9BLgce.js","assets/index-LxgeY4aO.js","assets/VocabularyWorkspace-CWWyOE4h.js","assets/queries-C9olL73s.js","assets/chevron-right-DVFTC2rf.js","assets/RegistryTab-B0_aYFx8.js","assets/trash-2-DgKzgfKH.js","assets/EntityResolutionTab-DogkN3fi.js","assets/KGOverviewTab-lmsMI0ma.js","assets/OntologySummaryTab-CUk0k8ue.js","assets/book-open-Due40JNM.js","assets/index-CbqBGY6W.js"])))=>i.map(i=>d[i]);
import{r as Bf,a as k,j as d,Q as dm,b as mm}from"./query-vendor-CCrh9h3E.js";(function(){const c=document.createElement("link").relList;if(c&&c.supports&&c.supports("modulepreload"))return;for(const D of document.querySelectorAll('link[rel="modulepreload"]'))m(D);new MutationObserver(D=>{for(const B of D)if(B.type==="childList")for(const Y of B.addedNodes)Y.tagName==="LINK"&&Y.rel==="modulepreload"&&m(Y)}).observe(document,{childList:!0,subtree:!0});function T(D){const B={};return D.integrity&&(B.integrity=D.integrity),D.referrerPolicy&&(B.referrerPolicy=D.referrerPolicy),D.crossOrigin==="use-credentials"?B.credentials="include":D.crossOrigin==="anonymous"?B.credentials="omit":B.credentials="same-origin",B}function m(D){if(D.ep)return;D.ep=!0;const B=T(D);fetch(D.href,B)}})();var Of={exports:{}},ai={},Nf={exports:{}},Df={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Hd;function gm(){return Hd||(Hd=1,(function(s){function c(x,A){var j=x.length;x.push(A);l:for(;0<j;){var q=j-1>>>1,X=x[q];if(0<D(X,A))x[q]=A,x[j]=X,j=q;else break l}}function T(x){return x.length===0?null:x[0]}function m(x){if(x.length===0)return null;var A=x[0],j=x.pop();if(j!==A){x[0]=j;l:for(var q=0,X=x.length,vl=X>>>1;q<vl;){var al=2*(q+1)-1,V=x[al],pl=al+1,Wl=x[pl];if(0>D(V,j))pl<X&&0>D(Wl,V)?(x[q]=Wl,x[pl]=j,q=pl):(x[q]=V,x[al]=j,q=al);else if(pl<X&&0>D(Wl,j))x[q]=Wl,x[pl]=j,q=pl;else break l}}return A}function D(x,A){var j=x.sortIndex-A.sortIndex;return j!==0?j:x.id-A.id}if(s.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var B=performance;s.unstable_now=function(){return B.now()}}else{var Y=Date,R=Y.now();s.unstable_now=function(){return Y.now()-R}}var M=[],b=[],w=1,E=null,C=3,tl=!1,$=!1,F=!1,hl=!1,ol=typeof setTimeout=="function"?setTimeout:null,bl=typeof clearTimeout=="function"?clearTimeout:null,sl=typeof setImmediate<"u"?setImmediate:null;function Dl(x){for(var A=T(b);A!==null;){if(A.callback===null)m(b);else if(A.startTime<=x)m(b),A.sortIndex=A.expirationTime,c(M,A);else break;A=T(b)}}function wl(x){if(F=!1,Dl(x),!$)if(T(M)!==null)$=!0,jl||(jl=!0,rl());else{var A=T(b);A!==null&&zl(wl,A.startTime-x)}}var jl=!1,Cl=-1,dl=5,Hl=-1;function Jl(){return hl?!0:!(s.unstable_now()-Hl<dl)}function Bl(){if(hl=!1,jl){var x=s.unstable_now();Hl=x;var A=!0;try{l:{$=!1,F&&(F=!1,bl(Cl),Cl=-1),tl=!0;var j=C;try{a:{for(Dl(x),E=T(M);E!==null&&!(E.expirationTime>x&&Jl());){var q=E.callback;if(typeof q=="function"){E.callback=null,C=E.priorityLevel;var X=q(E.expirationTime<=x);if(x=s.unstable_now(),typeof X=="function"){E.callback=X,Dl(x),A=!0;break a}E===T(M)&&m(M),Dl(x)}else m(M);E=T(M)}if(E!==null)A=!0;else{var vl=T(b);vl!==null&&zl(wl,vl.startTime-x),A=!1}}break l}finally{E=null,C=j,tl=!1}A=void 0}}finally{A?rl():jl=!1}}}var rl;if(typeof sl=="function")rl=function(){sl(Bl)};else if(typeof MessageChannel<"u"){var Fl=new MessageChannel,Ll=Fl.port2;Fl.port1.onmessage=Bl,rl=function(){Ll.postMessage(null)}}else rl=function(){ol(Bl,0)};function zl(x,A){Cl=ol(function(){x(s.unstable_now())},A)}s.unstable_IdlePriority=5,s.unstable_ImmediatePriority=1,s.unstable_LowPriority=4,s.unstable_NormalPriority=3,s.unstable_Profiling=null,s.unstable_UserBlockingPriority=2,s.unstable_cancelCallback=function(x){x.callback=null},s.unstable_forceFrameRate=function(x){0>x||125<x?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):dl=0<x?Math.floor(1e3/x):5},s.unstable_getCurrentPriorityLevel=function(){return C},s.unstable_next=function(x){switch(C){case 1:case 2:case 3:var A=3;break;default:A=C}var j=C;C=A;try{return x()}finally{C=j}},s.unstable_requestPaint=function(){hl=!0},s.unstable_runWithPriority=function(x,A){switch(x){case 1:case 2:case 3:case 4:case 5:break;default:x=3}var j=C;C=x;try{return A()}finally{C=j}},s.unstable_scheduleCallback=function(x,A,j){var q=s.unstable_now();switch(typeof j=="object"&&j!==null?(j=j.delay,j=typeof j=="number"&&0<j?q+j:q):j=q,x){case 1:var X=-1;break;case 2:X=250;break;case 5:X=1073741823;break;case 4:X=1e4;break;default:X=5e3}return X=j+X,x={id:w++,callback:A,priorityLevel:x,startTime:j,expirationTime:X,sortIndex:-1},j>q?(x.sortIndex=j,c(b,x),T(M)===null&&x===T(b)&&(F?(bl(Cl),Cl=-1):F=!0,zl(wl,j-q))):(x.sortIndex=X,c(M,x),$||tl||($=!0,jl||(jl=!0,rl()))),x},s.unstable_shouldYield=Jl,s.unstable_wrapCallback=function(x){var A=C;return function(){var j=C;C=A;try{return x.apply(this,arguments)}finally{C=j}}}})(Df)),Df}var Bd;function hm(){return Bd||(Bd=1,Nf.exports=gm()),Nf.exports}var wf={exports:{}},Kl={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Rd;function ym(){if(Rd)return Kl;Rd=1;var s=Bf();function c(M){var b="https://react.dev/errors/"+M;if(1<arguments.length){b+="?args[]="+encodeURIComponent(arguments[1]);for(var w=2;w<arguments.length;w++)b+="&args[]="+encodeURIComponent(arguments[w])}return"Minified React error #"+M+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function T(){}var m={d:{f:T,r:function(){throw Error(c(522))},D:T,C:T,L:T,m:T,X:T,S:T,M:T},p:0,findDOMNode:null},D=Symbol.for("react.portal");function B(M,b,w){var E=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:D,key:E==null?null:""+E,children:M,containerInfo:b,implementation:w}}var Y=s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function R(M,b){if(M==="font")return"";if(typeof b=="string")return b==="use-credentials"?b:""}return Kl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=m,Kl.createPortal=function(M,b){var w=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!b||b.nodeType!==1&&b.nodeType!==9&&b.nodeType!==11)throw Error(c(299));return B(M,b,null,w)},Kl.flushSync=function(M){var b=Y.T,w=m.p;try{if(Y.T=null,m.p=2,M)return M()}finally{Y.T=b,m.p=w,m.d.f()}},Kl.preconnect=function(M,b){typeof M=="string"&&(b?(b=b.crossOrigin,b=typeof b=="string"?b==="use-credentials"?b:"":void 0):b=null,m.d.C(M,b))},Kl.prefetchDNS=function(M){typeof M=="string"&&m.d.D(M)},Kl.preinit=function(M,b){if(typeof M=="string"&&b&&typeof b.as=="string"){var w=b.as,E=R(w,b.crossOrigin),C=typeof b.integrity=="string"?b.integrity:void 0,tl=typeof b.fetchPriority=="string"?b.fetchPriority:void 0;w==="style"?m.d.S(M,typeof b.precedence=="string"?b.precedence:void 0,{crossOrigin:E,integrity:C,fetchPriority:tl}):w==="script"&&m.d.X(M,{crossOrigin:E,integrity:C,fetchPriority:tl,nonce:typeof b.nonce=="string"?b.nonce:void 0})}},Kl.preinitModule=function(M,b){if(typeof M=="string")if(typeof b=="object"&&b!==null){if(b.as==null||b.as==="script"){var w=R(b.as,b.crossOrigin);m.d.M(M,{crossOrigin:w,integrity:typeof b.integrity=="string"?b.integrity:void 0,nonce:typeof b.nonce=="string"?b.nonce:void 0})}}else b==null&&m.d.M(M)},Kl.preload=function(M,b){if(typeof M=="string"&&typeof b=="object"&&b!==null&&typeof b.as=="string"){var w=b.as,E=R(w,b.crossOrigin);m.d.L(M,w,{crossOrigin:E,integrity:typeof b.integrity=="string"?b.integrity:void 0,nonce:typeof b.nonce=="string"?b.nonce:void 0,type:typeof b.type=="string"?b.type:void 0,fetchPriority:typeof b.fetchPriority=="string"?b.fetchPriority:void 0,referrerPolicy:typeof b.referrerPolicy=="string"?b.referrerPolicy:void 0,imageSrcSet:typeof b.imageSrcSet=="string"?b.imageSrcSet:void 0,imageSizes:typeof b.imageSizes=="string"?b.imageSizes:void 0,media:typeof b.media=="string"?b.media:void 0})}},Kl.preloadModule=function(M,b){if(typeof M=="string")if(b){var w=R(b.as,b.crossOrigin);m.d.m(M,{as:typeof b.as=="string"&&b.as!=="script"?b.as:void 0,crossOrigin:w,integrity:typeof b.integrity=="string"?b.integrity:void 0})}else m.d.m(M)},Kl.requestFormReset=function(M){m.d.r(M)},Kl.unstable_batchedUpdates=function(M,b){return M(b)},Kl.useFormState=function(M,b,w){return Y.H.useFormState(M,b,w)},Kl.useFormStatus=function(){return Y.H.useHostTransitionStatus()},Kl.version="19.2.5",Kl}var qd;function pm(){if(qd)return wf.exports;qd=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(c){console.error(c)}}return s(),wf.exports=ym(),wf.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Yd;function bm(){if(Yd)return ai;Yd=1;var s=hm(),c=Bf(),T=pm();function m(l){var a="https://react.dev/errors/"+l;if(1<arguments.length){a+="?args[]="+encodeURIComponent(arguments[1]);for(var t=2;t<arguments.length;t++)a+="&args[]="+encodeURIComponent(arguments[t])}return"Minified React error #"+l+"; visit "+a+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function D(l){return!(!l||l.nodeType!==1&&l.nodeType!==9&&l.nodeType!==11)}function B(l){var a=l,t=l;if(l.alternate)for(;a.return;)a=a.return;else{l=a;do a=l,(a.flags&4098)!==0&&(t=a.return),l=a.return;while(l)}return a.tag===3?t:null}function Y(l){if(l.tag===13){var a=l.memoizedState;if(a===null&&(l=l.alternate,l!==null&&(a=l.memoizedState)),a!==null)return a.dehydrated}return null}function R(l){if(l.tag===31){var a=l.memoizedState;if(a===null&&(l=l.alternate,l!==null&&(a=l.memoizedState)),a!==null)return a.dehydrated}return null}function M(l){if(B(l)!==l)throw Error(m(188))}function b(l){var a=l.alternate;if(!a){if(a=B(l),a===null)throw Error(m(188));return a!==l?null:l}for(var t=l,e=a;;){var n=t.return;if(n===null)break;var i=n.alternate;if(i===null){if(e=n.return,e!==null){t=e;continue}break}if(n.child===i.child){for(i=n.child;i;){if(i===t)return M(n),l;if(i===e)return M(n),a;i=i.sibling}throw Error(m(188))}if(t.return!==e.return)t=n,e=i;else{for(var u=!1,f=n.child;f;){if(f===t){u=!0,t=n,e=i;break}if(f===e){u=!0,e=n,t=i;break}f=f.sibling}if(!u){for(f=i.child;f;){if(f===t){u=!0,t=i,e=n;break}if(f===e){u=!0,e=i,t=n;break}f=f.sibling}if(!u)throw Error(m(189))}}if(t.alternate!==e)throw Error(m(190))}if(t.tag!==3)throw Error(m(188));return t.stateNode.current===t?l:a}function w(l){var a=l.tag;if(a===5||a===26||a===27||a===6)return l;for(l=l.child;l!==null;){if(a=w(l),a!==null)return a;l=l.sibling}return null}var E=Object.assign,C=Symbol.for("react.element"),tl=Symbol.for("react.transitional.element"),$=Symbol.for("react.portal"),F=Symbol.for("react.fragment"),hl=Symbol.for("react.strict_mode"),ol=Symbol.for("react.profiler"),bl=Symbol.for("react.consumer"),sl=Symbol.for("react.context"),Dl=Symbol.for("react.forward_ref"),wl=Symbol.for("react.suspense"),jl=Symbol.for("react.suspense_list"),Cl=Symbol.for("react.memo"),dl=Symbol.for("react.lazy"),Hl=Symbol.for("react.activity"),Jl=Symbol.for("react.memo_cache_sentinel"),Bl=Symbol.iterator;function rl(l){return l===null||typeof l!="object"?null:(l=Bl&&l[Bl]||l["@@iterator"],typeof l=="function"?l:null)}var Fl=Symbol.for("react.client.reference");function Ll(l){if(l==null)return null;if(typeof l=="function")return l.$$typeof===Fl?null:l.displayName||l.name||null;if(typeof l=="string")return l;switch(l){case F:return"Fragment";case ol:return"Profiler";case hl:return"StrictMode";case wl:return"Suspense";case jl:return"SuspenseList";case Hl:return"Activity"}if(typeof l=="object")switch(l.$$typeof){case $:return"Portal";case sl:return l.displayName||"Context";case bl:return(l._context.displayName||"Context")+".Consumer";case Dl:var a=l.render;return l=l.displayName,l||(l=a.displayName||a.name||"",l=l!==""?"ForwardRef("+l+")":"ForwardRef"),l;case Cl:return a=l.displayName||null,a!==null?a:Ll(l.type)||"Memo";case dl:a=l._payload,l=l._init;try{return Ll(l(a))}catch{}}return null}var zl=Array.isArray,x=c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,A=T.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,j={pending:!1,data:null,method:null,action:null},q=[],X=-1;function vl(l){return{current:l}}function al(l){0>X||(l.current=q[X],q[X]=null,X--)}function V(l,a){X++,q[X]=l.current,l.current=a}var pl=vl(null),Wl=vl(null),ca=vl(null),Da=vl(null);function Za(l,a){switch(V(ca,a),V(Wl,l),V(pl,null),a.nodeType){case 9:case 11:l=(l=a.documentElement)&&(l=l.namespaceURI)?nd(l):0;break;default:if(l=a.tagName,a=a.namespaceURI)a=nd(a),l=id(a,l);else switch(l){case"svg":l=1;break;case"math":l=2;break;default:l=0}}al(pl),V(pl,l)}function fa(){al(pl),al(Wl),al(ca)}function qa(l){l.memoizedState!==null&&V(Da,l);var a=pl.current,t=id(a,l.type);a!==t&&(V(Wl,l),V(pl,t))}function wa(l){Wl.current===l&&(al(pl),al(Wl)),Da.current===l&&(al(Da),Fn._currentValue=j)}var mt,Vt;function pa(l){if(mt===void 0)try{throw Error()}catch(t){var a=t.stack.trim().match(/\n( *(at )?)/);mt=a&&a[1]||"",Vt=-1<t.stack.indexOf(`
    at`)?" (<anonymous>)":-1<t.stack.indexOf("@")?"@unknown:0:0":""}return`
`+mt+l+Vt}var gt=!1;function ht(l,a){if(!l||gt)return"";gt=!0;var t=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var e={DetermineComponentFrameRoot:function(){try{if(a){var _=function(){throw Error()};if(Object.defineProperty(_.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(_,[])}catch(v){var p=v}Reflect.construct(l,[],_)}else{try{_.call()}catch(v){p=v}l.call(_.prototype)}}else{try{throw Error()}catch(v){p=v}(_=l())&&typeof _.catch=="function"&&_.catch(function(){})}}catch(v){if(v&&p&&typeof v.stack=="string")return[v.stack,p.stack]}return[null,null]}};e.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var n=Object.getOwnPropertyDescriptor(e.DetermineComponentFrameRoot,"name");n&&n.configurable&&Object.defineProperty(e.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var i=e.DetermineComponentFrameRoot(),u=i[0],f=i[1];if(u&&f){var r=u.split(`
`),y=f.split(`
`);for(n=e=0;e<r.length&&!r[e].includes("DetermineComponentFrameRoot");)e++;for(;n<y.length&&!y[n].includes("DetermineComponentFrameRoot");)n++;if(e===r.length||n===y.length)for(e=r.length-1,n=y.length-1;1<=e&&0<=n&&r[e]!==y[n];)n--;for(;1<=e&&0<=n;e--,n--)if(r[e]!==y[n]){if(e!==1||n!==1)do if(e--,n--,0>n||r[e]!==y[n]){var S=`
`+r[e].replace(" at new "," at ");return l.displayName&&S.includes("<anonymous>")&&(S=S.replace("<anonymous>",l.displayName)),S}while(1<=e&&0<=n);break}}}finally{gt=!1,Error.prepareStackTrace=t}return(t=l?l.displayName||l.name:"")?pa(t):""}function me(l,a){switch(l.tag){case 26:case 27:case 5:return pa(l.type);case 16:return pa("Lazy");case 13:return l.child!==a&&a!==null?pa("Suspense Fallback"):pa("Suspense");case 19:return pa("SuspenseList");case 0:case 15:return ht(l.type,!1);case 11:return ht(l.type.render,!1);case 1:return ht(l.type,!0);case 31:return pa("Activity");default:return""}}function Zt(l){try{var a="",t=null;do a+=me(l,t),t=l,l=l.return;while(l);return a}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}var yt=Object.prototype.hasOwnProperty,pt=s.unstable_scheduleCallback,bt=s.unstable_cancelCallback,ge=s.unstable_shouldYield,he=s.unstable_requestPaint,Rl=s.unstable_now,ye=s.unstable_getCurrentPriorityLevel,Lt=s.unstable_ImmediatePriority,Kt=s.unstable_UserBlockingPriority,La=s.unstable_NormalPriority,pe=s.unstable_LowPriority,Jt=s.unstable_IdlePriority,be=s.log,ve=s.unstable_setDisableYieldValue,ba=null,El=null;function sa(l){if(typeof be=="function"&&ve(l),El&&typeof El.setStrictMode=="function")try{El.setStrictMode(ba,l)}catch{}}var ql=Math.clz32?Math.clz32:ze,xe=Math.log,Se=Math.LN2;function ze(l){return l>>>=0,l===0?32:31-(xe(l)/Se|0)|0}var ja=256,Ua=262144,Ca=4194304;function va(l){var a=l&42;if(a!==0)return a;switch(l&-l){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return l&261888;case 262144:case 524288:case 1048576:case 2097152:return l&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return l&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return l}}function Ka(l,a,t){var e=l.pendingLanes;if(e===0)return 0;var n=0,i=l.suspendedLanes,u=l.pingedLanes;l=l.warmLanes;var f=e&134217727;return f!==0?(e=f&~i,e!==0?n=va(e):(u&=f,u!==0?n=va(u):t||(t=f&~l,t!==0&&(n=va(t))))):(f=e&~i,f!==0?n=va(f):u!==0?n=va(u):t||(t=e&~l,t!==0&&(n=va(t)))),n===0?0:a!==0&&a!==n&&(a&i)===0&&(i=n&-n,t=a&-a,i>=t||i===32&&(t&4194048)!==0)?a:n}function Ya(l,a){return(l.pendingLanes&~(l.suspendedLanes&~l.pingedLanes)&a)===0}function _e(l,a){switch(l){case 1:case 2:case 4:case 8:case 64:return a+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return a+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Wt(){var l=Ca;return Ca<<=1,(Ca&62914560)===0&&(Ca=4194304),l}function vt(l){for(var a=[],t=0;31>t;t++)a.push(l);return a}function Ga(l,a){l.pendingLanes|=a,a!==268435456&&(l.suspendedLanes=0,l.pingedLanes=0,l.warmLanes=0)}function ei(l,a,t,e,n,i){var u=l.pendingLanes;l.pendingLanes=t,l.suspendedLanes=0,l.pingedLanes=0,l.warmLanes=0,l.expiredLanes&=t,l.entangledLanes&=t,l.errorRecoveryDisabledLanes&=t,l.shellSuspendCounter=0;var f=l.entanglements,r=l.expirationTimes,y=l.hiddenUpdates;for(t=u&~t;0<t;){var S=31-ql(t),_=1<<S;f[S]=0,r[S]=-1;var p=y[S];if(p!==null)for(y[S]=null,S=0;S<p.length;S++){var v=p[S];v!==null&&(v.lane&=-536870913)}t&=~_}e!==0&&Ja(l,e,0),i!==0&&n===0&&l.tag!==0&&(l.suspendedLanes|=i&~(u&~a))}function Ja(l,a,t){l.pendingLanes|=a,l.suspendedLanes&=~a;var e=31-ql(a);l.entangledLanes|=a,l.entanglements[e]=l.entanglements[e]|1073741824|t&261930}function Gf(l,a){var t=l.entangledLanes|=a;for(l=l.entanglements;t;){var e=31-ql(t),n=1<<e;n&a|l[e]&a&&(l[e]|=a),t&=~n}}function Qf(l,a){var t=a&-a;return t=(t&42)!==0?1:yu(t),(t&(l.suspendedLanes|a))!==0?0:t}function yu(l){switch(l){case 2:l=1;break;case 8:l=4;break;case 32:l=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:l=128;break;case 268435456:l=134217728;break;default:l=0}return l}function pu(l){return l&=-l,2<l?8<l?(l&134217727)!==0?32:268435456:8:2}function kf(){var l=A.p;return l!==0?l:(l=window.event,l===void 0?32:Od(l.type))}function Xf(l,a){var t=A.p;try{return A.p=l,a()}finally{A.p=t}}var xt=Math.random().toString(36).slice(2),Ql="__reactFiber$"+xt,Il="__reactProps$"+xt,Ae="__reactContainer$"+xt,bu="__reactEvents$"+xt,a0="__reactListeners$"+xt,t0="__reactHandles$"+xt,Vf="__reactResources$"+xt,dn="__reactMarker$"+xt;function vu(l){delete l[Ql],delete l[Il],delete l[bu],delete l[a0],delete l[t0]}function Ee(l){var a=l[Ql];if(a)return a;for(var t=l.parentNode;t;){if(a=t[Ae]||t[Ql]){if(t=a.alternate,a.child!==null||t!==null&&t.child!==null)for(l=dd(l);l!==null;){if(t=l[Ql])return t;l=dd(l)}return a}l=t,t=l.parentNode}return null}function Te(l){if(l=l[Ql]||l[Ae]){var a=l.tag;if(a===5||a===6||a===13||a===31||a===26||a===27||a===3)return l}return null}function mn(l){var a=l.tag;if(a===5||a===26||a===27||a===6)return l.stateNode;throw Error(m(33))}function Me(l){var a=l[Vf];return a||(a=l[Vf]={hoistableStyles:new Map,hoistableScripts:new Map}),a}function Yl(l){l[dn]=!0}var Zf=new Set,Lf={};function $t(l,a){Oe(l,a),Oe(l+"Capture",a)}function Oe(l,a){for(Lf[l]=a,l=0;l<a.length;l++)Zf.add(a[l])}var e0=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Kf={},Jf={};function n0(l){return yt.call(Jf,l)?!0:yt.call(Kf,l)?!1:e0.test(l)?Jf[l]=!0:(Kf[l]=!0,!1)}function ni(l,a,t){if(n0(a))if(t===null)l.removeAttribute(a);else{switch(typeof t){case"undefined":case"function":case"symbol":l.removeAttribute(a);return;case"boolean":var e=a.toLowerCase().slice(0,5);if(e!=="data-"&&e!=="aria-"){l.removeAttribute(a);return}}l.setAttribute(a,""+t)}}function ii(l,a,t){if(t===null)l.removeAttribute(a);else{switch(typeof t){case"undefined":case"function":case"symbol":case"boolean":l.removeAttribute(a);return}l.setAttribute(a,""+t)}}function Wa(l,a,t,e){if(e===null)l.removeAttribute(t);else{switch(typeof e){case"undefined":case"function":case"symbol":case"boolean":l.removeAttribute(t);return}l.setAttributeNS(a,t,""+e)}}function xa(l){switch(typeof l){case"bigint":case"boolean":case"number":case"string":case"undefined":return l;case"object":return l;default:return""}}function Wf(l){var a=l.type;return(l=l.nodeName)&&l.toLowerCase()==="input"&&(a==="checkbox"||a==="radio")}function i0(l,a,t){var e=Object.getOwnPropertyDescriptor(l.constructor.prototype,a);if(!l.hasOwnProperty(a)&&typeof e<"u"&&typeof e.get=="function"&&typeof e.set=="function"){var n=e.get,i=e.set;return Object.defineProperty(l,a,{configurable:!0,get:function(){return n.call(this)},set:function(u){t=""+u,i.call(this,u)}}),Object.defineProperty(l,a,{enumerable:e.enumerable}),{getValue:function(){return t},setValue:function(u){t=""+u},stopTracking:function(){l._valueTracker=null,delete l[a]}}}}function xu(l){if(!l._valueTracker){var a=Wf(l)?"checked":"value";l._valueTracker=i0(l,a,""+l[a])}}function $f(l){if(!l)return!1;var a=l._valueTracker;if(!a)return!0;var t=a.getValue(),e="";return l&&(e=Wf(l)?l.checked?"true":"false":l.value),l=e,l!==t?(a.setValue(l),!0):!1}function ui(l){if(l=l||(typeof document<"u"?document:void 0),typeof l>"u")return null;try{return l.activeElement||l.body}catch{return l.body}}var u0=/[\n"\\]/g;function Sa(l){return l.replace(u0,function(a){return"\\"+a.charCodeAt(0).toString(16)+" "})}function Su(l,a,t,e,n,i,u,f){l.name="",u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"?l.type=u:l.removeAttribute("type"),a!=null?u==="number"?(a===0&&l.value===""||l.value!=a)&&(l.value=""+xa(a)):l.value!==""+xa(a)&&(l.value=""+xa(a)):u!=="submit"&&u!=="reset"||l.removeAttribute("value"),a!=null?zu(l,u,xa(a)):t!=null?zu(l,u,xa(t)):e!=null&&l.removeAttribute("value"),n==null&&i!=null&&(l.defaultChecked=!!i),n!=null&&(l.checked=n&&typeof n!="function"&&typeof n!="symbol"),f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"?l.name=""+xa(f):l.removeAttribute("name")}function Ff(l,a,t,e,n,i,u,f){if(i!=null&&typeof i!="function"&&typeof i!="symbol"&&typeof i!="boolean"&&(l.type=i),a!=null||t!=null){if(!(i!=="submit"&&i!=="reset"||a!=null)){xu(l);return}t=t!=null?""+xa(t):"",a=a!=null?""+xa(a):t,f||a===l.value||(l.value=a),l.defaultValue=a}e=e??n,e=typeof e!="function"&&typeof e!="symbol"&&!!e,l.checked=f?l.checked:!!e,l.defaultChecked=!!e,u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"&&(l.name=u),xu(l)}function zu(l,a,t){a==="number"&&ui(l.ownerDocument)===l||l.defaultValue===""+t||(l.defaultValue=""+t)}function Ne(l,a,t,e){if(l=l.options,a){a={};for(var n=0;n<t.length;n++)a["$"+t[n]]=!0;for(t=0;t<l.length;t++)n=a.hasOwnProperty("$"+l[t].value),l[t].selected!==n&&(l[t].selected=n),n&&e&&(l[t].defaultSelected=!0)}else{for(t=""+xa(t),a=null,n=0;n<l.length;n++){if(l[n].value===t){l[n].selected=!0,e&&(l[n].defaultSelected=!0);return}a!==null||l[n].disabled||(a=l[n])}a!==null&&(a.selected=!0)}}function If(l,a,t){if(a!=null&&(a=""+xa(a),a!==l.value&&(l.value=a),t==null)){l.defaultValue!==a&&(l.defaultValue=a);return}l.defaultValue=t!=null?""+xa(t):""}function Pf(l,a,t,e){if(a==null){if(e!=null){if(t!=null)throw Error(m(92));if(zl(e)){if(1<e.length)throw Error(m(93));e=e[0]}t=e}t==null&&(t=""),a=t}t=xa(a),l.defaultValue=t,e=l.textContent,e===t&&e!==""&&e!==null&&(l.value=e),xu(l)}function De(l,a){if(a){var t=l.firstChild;if(t&&t===l.lastChild&&t.nodeType===3){t.nodeValue=a;return}}l.textContent=a}var c0=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ls(l,a,t){var e=a.indexOf("--")===0;t==null||typeof t=="boolean"||t===""?e?l.setProperty(a,""):a==="float"?l.cssFloat="":l[a]="":e?l.setProperty(a,t):typeof t!="number"||t===0||c0.has(a)?a==="float"?l.cssFloat=t:l[a]=(""+t).trim():l[a]=t+"px"}function as(l,a,t){if(a!=null&&typeof a!="object")throw Error(m(62));if(l=l.style,t!=null){for(var e in t)!t.hasOwnProperty(e)||a!=null&&a.hasOwnProperty(e)||(e.indexOf("--")===0?l.setProperty(e,""):e==="float"?l.cssFloat="":l[e]="");for(var n in a)e=a[n],a.hasOwnProperty(n)&&t[n]!==e&&ls(l,n,e)}else for(var i in a)a.hasOwnProperty(i)&&ls(l,i,a[i])}function _u(l){if(l.indexOf("-")===-1)return!1;switch(l){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var f0=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),s0=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function ci(l){return s0.test(""+l)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":l}function $a(){}var Au=null;function Eu(l){return l=l.target||l.srcElement||window,l.correspondingUseElement&&(l=l.correspondingUseElement),l.nodeType===3?l.parentNode:l}var we=null,je=null;function ts(l){var a=Te(l);if(a&&(l=a.stateNode)){var t=l[Il]||null;l:switch(l=a.stateNode,a.type){case"input":if(Su(l,t.value,t.defaultValue,t.defaultValue,t.checked,t.defaultChecked,t.type,t.name),a=t.name,t.type==="radio"&&a!=null){for(t=l;t.parentNode;)t=t.parentNode;for(t=t.querySelectorAll('input[name="'+Sa(""+a)+'"][type="radio"]'),a=0;a<t.length;a++){var e=t[a];if(e!==l&&e.form===l.form){var n=e[Il]||null;if(!n)throw Error(m(90));Su(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name)}}for(a=0;a<t.length;a++)e=t[a],e.form===l.form&&$f(e)}break l;case"textarea":If(l,t.value,t.defaultValue);break l;case"select":a=t.value,a!=null&&Ne(l,!!t.multiple,a,!1)}}}var Tu=!1;function es(l,a,t){if(Tu)return l(a,t);Tu=!0;try{var e=l(a);return e}finally{if(Tu=!1,(we!==null||je!==null)&&(Ji(),we&&(a=we,l=je,je=we=null,ts(a),l)))for(a=0;a<l.length;a++)ts(l[a])}}function gn(l,a){var t=l.stateNode;if(t===null)return null;var e=t[Il]||null;if(e===null)return null;t=e[a];l:switch(a){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(e=!e.disabled)||(l=l.type,e=!(l==="button"||l==="input"||l==="select"||l==="textarea")),l=!e;break l;default:l=!1}if(l)return null;if(t&&typeof t!="function")throw Error(m(231,a,typeof t));return t}var Fa=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Mu=!1;if(Fa)try{var hn={};Object.defineProperty(hn,"passive",{get:function(){Mu=!0}}),window.addEventListener("test",hn,hn),window.removeEventListener("test",hn,hn)}catch{Mu=!1}var St=null,Ou=null,fi=null;function ns(){if(fi)return fi;var l,a=Ou,t=a.length,e,n="value"in St?St.value:St.textContent,i=n.length;for(l=0;l<t&&a[l]===n[l];l++);var u=t-l;for(e=1;e<=u&&a[t-e]===n[i-e];e++);return fi=n.slice(l,1<e?1-e:void 0)}function si(l){var a=l.keyCode;return"charCode"in l?(l=l.charCode,l===0&&a===13&&(l=13)):l=a,l===10&&(l=13),32<=l||l===13?l:0}function ri(){return!0}function is(){return!1}function Pl(l){function a(t,e,n,i,u){this._reactName=t,this._targetInst=n,this.type=e,this.nativeEvent=i,this.target=u,this.currentTarget=null;for(var f in l)l.hasOwnProperty(f)&&(t=l[f],this[f]=t?t(i):i[f]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?ri:is,this.isPropagationStopped=is,this}return E(a.prototype,{preventDefault:function(){this.defaultPrevented=!0;var t=this.nativeEvent;t&&(t.preventDefault?t.preventDefault():typeof t.returnValue!="unknown"&&(t.returnValue=!1),this.isDefaultPrevented=ri)},stopPropagation:function(){var t=this.nativeEvent;t&&(t.stopPropagation?t.stopPropagation():typeof t.cancelBubble!="unknown"&&(t.cancelBubble=!0),this.isPropagationStopped=ri)},persist:function(){},isPersistent:ri}),a}var Ft={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(l){return l.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},oi=Pl(Ft),yn=E({},Ft,{view:0,detail:0}),r0=Pl(yn),Nu,Du,pn,di=E({},yn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ju,button:0,buttons:0,relatedTarget:function(l){return l.relatedTarget===void 0?l.fromElement===l.srcElement?l.toElement:l.fromElement:l.relatedTarget},movementX:function(l){return"movementX"in l?l.movementX:(l!==pn&&(pn&&l.type==="mousemove"?(Nu=l.screenX-pn.screenX,Du=l.screenY-pn.screenY):Du=Nu=0,pn=l),Nu)},movementY:function(l){return"movementY"in l?l.movementY:Du}}),us=Pl(di),o0=E({},di,{dataTransfer:0}),d0=Pl(o0),m0=E({},yn,{relatedTarget:0}),wu=Pl(m0),g0=E({},Ft,{animationName:0,elapsedTime:0,pseudoElement:0}),h0=Pl(g0),y0=E({},Ft,{clipboardData:function(l){return"clipboardData"in l?l.clipboardData:window.clipboardData}}),p0=Pl(y0),b0=E({},Ft,{data:0}),cs=Pl(b0),v0={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},x0={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},S0={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function z0(l){var a=this.nativeEvent;return a.getModifierState?a.getModifierState(l):(l=S0[l])?!!a[l]:!1}function ju(){return z0}var _0=E({},yn,{key:function(l){if(l.key){var a=v0[l.key]||l.key;if(a!=="Unidentified")return a}return l.type==="keypress"?(l=si(l),l===13?"Enter":String.fromCharCode(l)):l.type==="keydown"||l.type==="keyup"?x0[l.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ju,charCode:function(l){return l.type==="keypress"?si(l):0},keyCode:function(l){return l.type==="keydown"||l.type==="keyup"?l.keyCode:0},which:function(l){return l.type==="keypress"?si(l):l.type==="keydown"||l.type==="keyup"?l.keyCode:0}}),A0=Pl(_0),E0=E({},di,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),fs=Pl(E0),T0=E({},yn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ju}),M0=Pl(T0),O0=E({},Ft,{propertyName:0,elapsedTime:0,pseudoElement:0}),N0=Pl(O0),D0=E({},di,{deltaX:function(l){return"deltaX"in l?l.deltaX:"wheelDeltaX"in l?-l.wheelDeltaX:0},deltaY:function(l){return"deltaY"in l?l.deltaY:"wheelDeltaY"in l?-l.wheelDeltaY:"wheelDelta"in l?-l.wheelDelta:0},deltaZ:0,deltaMode:0}),w0=Pl(D0),j0=E({},Ft,{newState:0,oldState:0}),U0=Pl(j0),C0=[9,13,27,32],Uu=Fa&&"CompositionEvent"in window,bn=null;Fa&&"documentMode"in document&&(bn=document.documentMode);var H0=Fa&&"TextEvent"in window&&!bn,ss=Fa&&(!Uu||bn&&8<bn&&11>=bn),rs=" ",os=!1;function ds(l,a){switch(l){case"keyup":return C0.indexOf(a.keyCode)!==-1;case"keydown":return a.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function ms(l){return l=l.detail,typeof l=="object"&&"data"in l?l.data:null}var Ue=!1;function B0(l,a){switch(l){case"compositionend":return ms(a);case"keypress":return a.which!==32?null:(os=!0,rs);case"textInput":return l=a.data,l===rs&&os?null:l;default:return null}}function R0(l,a){if(Ue)return l==="compositionend"||!Uu&&ds(l,a)?(l=ns(),fi=Ou=St=null,Ue=!1,l):null;switch(l){case"paste":return null;case"keypress":if(!(a.ctrlKey||a.altKey||a.metaKey)||a.ctrlKey&&a.altKey){if(a.char&&1<a.char.length)return a.char;if(a.which)return String.fromCharCode(a.which)}return null;case"compositionend":return ss&&a.locale!=="ko"?null:a.data;default:return null}}var q0={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function gs(l){var a=l&&l.nodeName&&l.nodeName.toLowerCase();return a==="input"?!!q0[l.type]:a==="textarea"}function hs(l,a,t,e){we?je?je.push(e):je=[e]:we=e,a=au(a,"onChange"),0<a.length&&(t=new oi("onChange","change",null,t,e),l.push({event:t,listeners:a}))}var vn=null,xn=null;function Y0(l){Io(l,0)}function mi(l){var a=mn(l);if($f(a))return l}function ys(l,a){if(l==="change")return a}var ps=!1;if(Fa){var Cu;if(Fa){var Hu="oninput"in document;if(!Hu){var bs=document.createElement("div");bs.setAttribute("oninput","return;"),Hu=typeof bs.oninput=="function"}Cu=Hu}else Cu=!1;ps=Cu&&(!document.documentMode||9<document.documentMode)}function vs(){vn&&(vn.detachEvent("onpropertychange",xs),xn=vn=null)}function xs(l){if(l.propertyName==="value"&&mi(xn)){var a=[];hs(a,xn,l,Eu(l)),es(Y0,a)}}function G0(l,a,t){l==="focusin"?(vs(),vn=a,xn=t,vn.attachEvent("onpropertychange",xs)):l==="focusout"&&vs()}function Q0(l){if(l==="selectionchange"||l==="keyup"||l==="keydown")return mi(xn)}function k0(l,a){if(l==="click")return mi(a)}function X0(l,a){if(l==="input"||l==="change")return mi(a)}function V0(l,a){return l===a&&(l!==0||1/l===1/a)||l!==l&&a!==a}var ra=typeof Object.is=="function"?Object.is:V0;function Sn(l,a){if(ra(l,a))return!0;if(typeof l!="object"||l===null||typeof a!="object"||a===null)return!1;var t=Object.keys(l),e=Object.keys(a);if(t.length!==e.length)return!1;for(e=0;e<t.length;e++){var n=t[e];if(!yt.call(a,n)||!ra(l[n],a[n]))return!1}return!0}function Ss(l){for(;l&&l.firstChild;)l=l.firstChild;return l}function zs(l,a){var t=Ss(l);l=0;for(var e;t;){if(t.nodeType===3){if(e=l+t.textContent.length,l<=a&&e>=a)return{node:t,offset:a-l};l=e}l:{for(;t;){if(t.nextSibling){t=t.nextSibling;break l}t=t.parentNode}t=void 0}t=Ss(t)}}function _s(l,a){return l&&a?l===a?!0:l&&l.nodeType===3?!1:a&&a.nodeType===3?_s(l,a.parentNode):"contains"in l?l.contains(a):l.compareDocumentPosition?!!(l.compareDocumentPosition(a)&16):!1:!1}function As(l){l=l!=null&&l.ownerDocument!=null&&l.ownerDocument.defaultView!=null?l.ownerDocument.defaultView:window;for(var a=ui(l.document);a instanceof l.HTMLIFrameElement;){try{var t=typeof a.contentWindow.location.href=="string"}catch{t=!1}if(t)l=a.contentWindow;else break;a=ui(l.document)}return a}function Bu(l){var a=l&&l.nodeName&&l.nodeName.toLowerCase();return a&&(a==="input"&&(l.type==="text"||l.type==="search"||l.type==="tel"||l.type==="url"||l.type==="password")||a==="textarea"||l.contentEditable==="true")}var Z0=Fa&&"documentMode"in document&&11>=document.documentMode,Ce=null,Ru=null,zn=null,qu=!1;function Es(l,a,t){var e=t.window===t?t.document:t.nodeType===9?t:t.ownerDocument;qu||Ce==null||Ce!==ui(e)||(e=Ce,"selectionStart"in e&&Bu(e)?e={start:e.selectionStart,end:e.selectionEnd}:(e=(e.ownerDocument&&e.ownerDocument.defaultView||window).getSelection(),e={anchorNode:e.anchorNode,anchorOffset:e.anchorOffset,focusNode:e.focusNode,focusOffset:e.focusOffset}),zn&&Sn(zn,e)||(zn=e,e=au(Ru,"onSelect"),0<e.length&&(a=new oi("onSelect","select",null,a,t),l.push({event:a,listeners:e}),a.target=Ce)))}function It(l,a){var t={};return t[l.toLowerCase()]=a.toLowerCase(),t["Webkit"+l]="webkit"+a,t["Moz"+l]="moz"+a,t}var He={animationend:It("Animation","AnimationEnd"),animationiteration:It("Animation","AnimationIteration"),animationstart:It("Animation","AnimationStart"),transitionrun:It("Transition","TransitionRun"),transitionstart:It("Transition","TransitionStart"),transitioncancel:It("Transition","TransitionCancel"),transitionend:It("Transition","TransitionEnd")},Yu={},Ts={};Fa&&(Ts=document.createElement("div").style,"AnimationEvent"in window||(delete He.animationend.animation,delete He.animationiteration.animation,delete He.animationstart.animation),"TransitionEvent"in window||delete He.transitionend.transition);function Pt(l){if(Yu[l])return Yu[l];if(!He[l])return l;var a=He[l],t;for(t in a)if(a.hasOwnProperty(t)&&t in Ts)return Yu[l]=a[t];return l}var Ms=Pt("animationend"),Os=Pt("animationiteration"),Ns=Pt("animationstart"),L0=Pt("transitionrun"),K0=Pt("transitionstart"),J0=Pt("transitioncancel"),Ds=Pt("transitionend"),ws=new Map,Gu="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Gu.push("scrollEnd");function Ha(l,a){ws.set(l,a),$t(a,[l])}var gi=typeof reportError=="function"?reportError:function(l){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var a=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof l=="object"&&l!==null&&typeof l.message=="string"?String(l.message):String(l),error:l});if(!window.dispatchEvent(a))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",l);return}console.error(l)},za=[],Be=0,Qu=0;function hi(){for(var l=Be,a=Qu=Be=0;a<l;){var t=za[a];za[a++]=null;var e=za[a];za[a++]=null;var n=za[a];za[a++]=null;var i=za[a];if(za[a++]=null,e!==null&&n!==null){var u=e.pending;u===null?n.next=n:(n.next=u.next,u.next=n),e.pending=n}i!==0&&js(t,n,i)}}function yi(l,a,t,e){za[Be++]=l,za[Be++]=a,za[Be++]=t,za[Be++]=e,Qu|=e,l.lanes|=e,l=l.alternate,l!==null&&(l.lanes|=e)}function ku(l,a,t,e){return yi(l,a,t,e),pi(l)}function le(l,a){return yi(l,null,null,a),pi(l)}function js(l,a,t){l.lanes|=t;var e=l.alternate;e!==null&&(e.lanes|=t);for(var n=!1,i=l.return;i!==null;)i.childLanes|=t,e=i.alternate,e!==null&&(e.childLanes|=t),i.tag===22&&(l=i.stateNode,l===null||l._visibility&1||(n=!0)),l=i,i=i.return;return l.tag===3?(i=l.stateNode,n&&a!==null&&(n=31-ql(t),l=i.hiddenUpdates,e=l[n],e===null?l[n]=[a]:e.push(a),a.lane=t|536870912),i):null}function pi(l){if(50<Vn)throw Vn=0,Fc=null,Error(m(185));for(var a=l.return;a!==null;)l=a,a=l.return;return l.tag===3?l.stateNode:null}var Re={};function W0(l,a,t,e){this.tag=l,this.key=t,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=a,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=e,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function oa(l,a,t,e){return new W0(l,a,t,e)}function Xu(l){return l=l.prototype,!(!l||!l.isReactComponent)}function Ia(l,a){var t=l.alternate;return t===null?(t=oa(l.tag,a,l.key,l.mode),t.elementType=l.elementType,t.type=l.type,t.stateNode=l.stateNode,t.alternate=l,l.alternate=t):(t.pendingProps=a,t.type=l.type,t.flags=0,t.subtreeFlags=0,t.deletions=null),t.flags=l.flags&65011712,t.childLanes=l.childLanes,t.lanes=l.lanes,t.child=l.child,t.memoizedProps=l.memoizedProps,t.memoizedState=l.memoizedState,t.updateQueue=l.updateQueue,a=l.dependencies,t.dependencies=a===null?null:{lanes:a.lanes,firstContext:a.firstContext},t.sibling=l.sibling,t.index=l.index,t.ref=l.ref,t.refCleanup=l.refCleanup,t}function Us(l,a){l.flags&=65011714;var t=l.alternate;return t===null?(l.childLanes=0,l.lanes=a,l.child=null,l.subtreeFlags=0,l.memoizedProps=null,l.memoizedState=null,l.updateQueue=null,l.dependencies=null,l.stateNode=null):(l.childLanes=t.childLanes,l.lanes=t.lanes,l.child=t.child,l.subtreeFlags=0,l.deletions=null,l.memoizedProps=t.memoizedProps,l.memoizedState=t.memoizedState,l.updateQueue=t.updateQueue,l.type=t.type,a=t.dependencies,l.dependencies=a===null?null:{lanes:a.lanes,firstContext:a.firstContext}),l}function bi(l,a,t,e,n,i){var u=0;if(e=l,typeof l=="function")Xu(l)&&(u=1);else if(typeof l=="string")u=lm(l,t,pl.current)?26:l==="html"||l==="head"||l==="body"?27:5;else l:switch(l){case Hl:return l=oa(31,t,a,n),l.elementType=Hl,l.lanes=i,l;case F:return ae(t.children,n,i,a);case hl:u=8,n|=24;break;case ol:return l=oa(12,t,a,n|2),l.elementType=ol,l.lanes=i,l;case wl:return l=oa(13,t,a,n),l.elementType=wl,l.lanes=i,l;case jl:return l=oa(19,t,a,n),l.elementType=jl,l.lanes=i,l;default:if(typeof l=="object"&&l!==null)switch(l.$$typeof){case sl:u=10;break l;case bl:u=9;break l;case Dl:u=11;break l;case Cl:u=14;break l;case dl:u=16,e=null;break l}u=29,t=Error(m(130,l===null?"null":typeof l,"")),e=null}return a=oa(u,t,a,n),a.elementType=l,a.type=e,a.lanes=i,a}function ae(l,a,t,e){return l=oa(7,l,e,a),l.lanes=t,l}function Vu(l,a,t){return l=oa(6,l,null,a),l.lanes=t,l}function Cs(l){var a=oa(18,null,null,0);return a.stateNode=l,a}function Zu(l,a,t){return a=oa(4,l.children!==null?l.children:[],l.key,a),a.lanes=t,a.stateNode={containerInfo:l.containerInfo,pendingChildren:null,implementation:l.implementation},a}var Hs=new WeakMap;function _a(l,a){if(typeof l=="object"&&l!==null){var t=Hs.get(l);return t!==void 0?t:(a={value:l,source:a,stack:Zt(a)},Hs.set(l,a),a)}return{value:l,source:a,stack:Zt(a)}}var qe=[],Ye=0,vi=null,_n=0,Aa=[],Ea=0,zt=null,Qa=1,ka="";function Pa(l,a){qe[Ye++]=_n,qe[Ye++]=vi,vi=l,_n=a}function Bs(l,a,t){Aa[Ea++]=Qa,Aa[Ea++]=ka,Aa[Ea++]=zt,zt=l;var e=Qa;l=ka;var n=32-ql(e)-1;e&=~(1<<n),t+=1;var i=32-ql(a)+n;if(30<i){var u=n-n%5;i=(e&(1<<u)-1).toString(32),e>>=u,n-=u,Qa=1<<32-ql(a)+n|t<<n|e,ka=i+l}else Qa=1<<i|t<<n|e,ka=l}function Lu(l){l.return!==null&&(Pa(l,1),Bs(l,1,0))}function Ku(l){for(;l===vi;)vi=qe[--Ye],qe[Ye]=null,_n=qe[--Ye],qe[Ye]=null;for(;l===zt;)zt=Aa[--Ea],Aa[Ea]=null,ka=Aa[--Ea],Aa[Ea]=null,Qa=Aa[--Ea],Aa[Ea]=null}function Rs(l,a){Aa[Ea++]=Qa,Aa[Ea++]=ka,Aa[Ea++]=zt,Qa=a.id,ka=a.overflow,zt=l}var kl=null,ml=null,W=!1,_t=null,Ta=!1,Ju=Error(m(519));function At(l){var a=Error(m(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw An(_a(a,l)),Ju}function qs(l){var a=l.stateNode,t=l.type,e=l.memoizedProps;switch(a[Ql]=l,a[Il]=e,t){case"dialog":L("cancel",a),L("close",a);break;case"iframe":case"object":case"embed":L("load",a);break;case"video":case"audio":for(t=0;t<Ln.length;t++)L(Ln[t],a);break;case"source":L("error",a);break;case"img":case"image":case"link":L("error",a),L("load",a);break;case"details":L("toggle",a);break;case"input":L("invalid",a),Ff(a,e.value,e.defaultValue,e.checked,e.defaultChecked,e.type,e.name,!0);break;case"select":L("invalid",a);break;case"textarea":L("invalid",a),Pf(a,e.value,e.defaultValue,e.children)}t=e.children,typeof t!="string"&&typeof t!="number"&&typeof t!="bigint"||a.textContent===""+t||e.suppressHydrationWarning===!0||td(a.textContent,t)?(e.popover!=null&&(L("beforetoggle",a),L("toggle",a)),e.onScroll!=null&&L("scroll",a),e.onScrollEnd!=null&&L("scrollend",a),e.onClick!=null&&(a.onclick=$a),a=!0):a=!1,a||At(l,!0)}function Ys(l){for(kl=l.return;kl;)switch(kl.tag){case 5:case 31:case 13:Ta=!1;return;case 27:case 3:Ta=!0;return;default:kl=kl.return}}function Ge(l){if(l!==kl)return!1;if(!W)return Ys(l),W=!0,!1;var a=l.tag,t;if((t=a!==3&&a!==27)&&((t=a===5)&&(t=l.type,t=!(t!=="form"&&t!=="button")||mf(l.type,l.memoizedProps)),t=!t),t&&ml&&At(l),Ys(l),a===13){if(l=l.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(m(317));ml=od(l)}else if(a===31){if(l=l.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(m(317));ml=od(l)}else a===27?(a=ml,qt(l.type)?(l=bf,bf=null,ml=l):ml=a):ml=kl?Oa(l.stateNode.nextSibling):null;return!0}function te(){ml=kl=null,W=!1}function Wu(){var l=_t;return l!==null&&(ea===null?ea=l:ea.push.apply(ea,l),_t=null),l}function An(l){_t===null?_t=[l]:_t.push(l)}var $u=vl(null),ee=null,lt=null;function Et(l,a,t){V($u,a._currentValue),a._currentValue=t}function at(l){l._currentValue=$u.current,al($u)}function Fu(l,a,t){for(;l!==null;){var e=l.alternate;if((l.childLanes&a)!==a?(l.childLanes|=a,e!==null&&(e.childLanes|=a)):e!==null&&(e.childLanes&a)!==a&&(e.childLanes|=a),l===t)break;l=l.return}}function Iu(l,a,t,e){var n=l.child;for(n!==null&&(n.return=l);n!==null;){var i=n.dependencies;if(i!==null){var u=n.child;i=i.firstContext;l:for(;i!==null;){var f=i;i=n;for(var r=0;r<a.length;r++)if(f.context===a[r]){i.lanes|=t,f=i.alternate,f!==null&&(f.lanes|=t),Fu(i.return,t,l),e||(u=null);break l}i=f.next}}else if(n.tag===18){if(u=n.return,u===null)throw Error(m(341));u.lanes|=t,i=u.alternate,i!==null&&(i.lanes|=t),Fu(u,t,l),u=null}else u=n.child;if(u!==null)u.return=n;else for(u=n;u!==null;){if(u===l){u=null;break}if(n=u.sibling,n!==null){n.return=u.return,u=n;break}u=u.return}n=u}}function Qe(l,a,t,e){l=null;for(var n=a,i=!1;n!==null;){if(!i){if((n.flags&524288)!==0)i=!0;else if((n.flags&262144)!==0)break}if(n.tag===10){var u=n.alternate;if(u===null)throw Error(m(387));if(u=u.memoizedProps,u!==null){var f=n.type;ra(n.pendingProps.value,u.value)||(l!==null?l.push(f):l=[f])}}else if(n===Da.current){if(u=n.alternate,u===null)throw Error(m(387));u.memoizedState.memoizedState!==n.memoizedState.memoizedState&&(l!==null?l.push(Fn):l=[Fn])}n=n.return}l!==null&&Iu(a,l,t,e),a.flags|=262144}function xi(l){for(l=l.firstContext;l!==null;){if(!ra(l.context._currentValue,l.memoizedValue))return!0;l=l.next}return!1}function ne(l){ee=l,lt=null,l=l.dependencies,l!==null&&(l.firstContext=null)}function Xl(l){return Gs(ee,l)}function Si(l,a){return ee===null&&ne(l),Gs(l,a)}function Gs(l,a){var t=a._currentValue;if(a={context:a,memoizedValue:t,next:null},lt===null){if(l===null)throw Error(m(308));lt=a,l.dependencies={lanes:0,firstContext:a},l.flags|=524288}else lt=lt.next=a;return t}var $0=typeof AbortController<"u"?AbortController:function(){var l=[],a=this.signal={aborted:!1,addEventListener:function(t,e){l.push(e)}};this.abort=function(){a.aborted=!0,l.forEach(function(t){return t()})}},F0=s.unstable_scheduleCallback,I0=s.unstable_NormalPriority,Tl={$$typeof:sl,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Pu(){return{controller:new $0,data:new Map,refCount:0}}function En(l){l.refCount--,l.refCount===0&&F0(I0,function(){l.controller.abort()})}var Tn=null,lc=0,ke=0,Xe=null;function P0(l,a){if(Tn===null){var t=Tn=[];lc=0,ke=ef(),Xe={status:"pending",value:void 0,then:function(e){t.push(e)}}}return lc++,a.then(Qs,Qs),a}function Qs(){if(--lc===0&&Tn!==null){Xe!==null&&(Xe.status="fulfilled");var l=Tn;Tn=null,ke=0,Xe=null;for(var a=0;a<l.length;a++)(0,l[a])()}}function l1(l,a){var t=[],e={status:"pending",value:null,reason:null,then:function(n){t.push(n)}};return l.then(function(){e.status="fulfilled",e.value=a;for(var n=0;n<t.length;n++)(0,t[n])(a)},function(n){for(e.status="rejected",e.reason=n,n=0;n<t.length;n++)(0,t[n])(void 0)}),e}var ks=x.S;x.S=function(l,a){To=Rl(),typeof a=="object"&&a!==null&&typeof a.then=="function"&&P0(l,a),ks!==null&&ks(l,a)};var ie=vl(null);function ac(){var l=ie.current;return l!==null?l:fl.pooledCache}function zi(l,a){a===null?V(ie,ie.current):V(ie,a.pool)}function Xs(){var l=ac();return l===null?null:{parent:Tl._currentValue,pool:l}}var Ve=Error(m(460)),tc=Error(m(474)),_i=Error(m(542)),Ai={then:function(){}};function Vs(l){return l=l.status,l==="fulfilled"||l==="rejected"}function Zs(l,a,t){switch(t=l[t],t===void 0?l.push(a):t!==a&&(a.then($a,$a),a=t),a.status){case"fulfilled":return a.value;case"rejected":throw l=a.reason,Ks(l),l;default:if(typeof a.status=="string")a.then($a,$a);else{if(l=fl,l!==null&&100<l.shellSuspendCounter)throw Error(m(482));l=a,l.status="pending",l.then(function(e){if(a.status==="pending"){var n=a;n.status="fulfilled",n.value=e}},function(e){if(a.status==="pending"){var n=a;n.status="rejected",n.reason=e}})}switch(a.status){case"fulfilled":return a.value;case"rejected":throw l=a.reason,Ks(l),l}throw ce=a,Ve}}function ue(l){try{var a=l._init;return a(l._payload)}catch(t){throw t!==null&&typeof t=="object"&&typeof t.then=="function"?(ce=t,Ve):t}}var ce=null;function Ls(){if(ce===null)throw Error(m(459));var l=ce;return ce=null,l}function Ks(l){if(l===Ve||l===_i)throw Error(m(483))}var Ze=null,Mn=0;function Ei(l){var a=Mn;return Mn+=1,Ze===null&&(Ze=[]),Zs(Ze,l,a)}function On(l,a){a=a.props.ref,l.ref=a!==void 0?a:null}function Ti(l,a){throw a.$$typeof===C?Error(m(525)):(l=Object.prototype.toString.call(a),Error(m(31,l==="[object Object]"?"object with keys {"+Object.keys(a).join(", ")+"}":l)))}function Js(l){function a(g,o){if(l){var h=g.deletions;h===null?(g.deletions=[o],g.flags|=16):h.push(o)}}function t(g,o){if(!l)return null;for(;o!==null;)a(g,o),o=o.sibling;return null}function e(g){for(var o=new Map;g!==null;)g.key!==null?o.set(g.key,g):o.set(g.index,g),g=g.sibling;return o}function n(g,o){return g=Ia(g,o),g.index=0,g.sibling=null,g}function i(g,o,h){return g.index=h,l?(h=g.alternate,h!==null?(h=h.index,h<o?(g.flags|=67108866,o):h):(g.flags|=67108866,o)):(g.flags|=1048576,o)}function u(g){return l&&g.alternate===null&&(g.flags|=67108866),g}function f(g,o,h,z){return o===null||o.tag!==6?(o=Vu(h,g.mode,z),o.return=g,o):(o=n(o,h),o.return=g,o)}function r(g,o,h,z){var U=h.type;return U===F?S(g,o,h.props.children,z,h.key):o!==null&&(o.elementType===U||typeof U=="object"&&U!==null&&U.$$typeof===dl&&ue(U)===o.type)?(o=n(o,h.props),On(o,h),o.return=g,o):(o=bi(h.type,h.key,h.props,null,g.mode,z),On(o,h),o.return=g,o)}function y(g,o,h,z){return o===null||o.tag!==4||o.stateNode.containerInfo!==h.containerInfo||o.stateNode.implementation!==h.implementation?(o=Zu(h,g.mode,z),o.return=g,o):(o=n(o,h.children||[]),o.return=g,o)}function S(g,o,h,z,U){return o===null||o.tag!==7?(o=ae(h,g.mode,z,U),o.return=g,o):(o=n(o,h),o.return=g,o)}function _(g,o,h){if(typeof o=="string"&&o!==""||typeof o=="number"||typeof o=="bigint")return o=Vu(""+o,g.mode,h),o.return=g,o;if(typeof o=="object"&&o!==null){switch(o.$$typeof){case tl:return h=bi(o.type,o.key,o.props,null,g.mode,h),On(h,o),h.return=g,h;case $:return o=Zu(o,g.mode,h),o.return=g,o;case dl:return o=ue(o),_(g,o,h)}if(zl(o)||rl(o))return o=ae(o,g.mode,h,null),o.return=g,o;if(typeof o.then=="function")return _(g,Ei(o),h);if(o.$$typeof===sl)return _(g,Si(g,o),h);Ti(g,o)}return null}function p(g,o,h,z){var U=o!==null?o.key:null;if(typeof h=="string"&&h!==""||typeof h=="number"||typeof h=="bigint")return U!==null?null:f(g,o,""+h,z);if(typeof h=="object"&&h!==null){switch(h.$$typeof){case tl:return h.key===U?r(g,o,h,z):null;case $:return h.key===U?y(g,o,h,z):null;case dl:return h=ue(h),p(g,o,h,z)}if(zl(h)||rl(h))return U!==null?null:S(g,o,h,z,null);if(typeof h.then=="function")return p(g,o,Ei(h),z);if(h.$$typeof===sl)return p(g,o,Si(g,h),z);Ti(g,h)}return null}function v(g,o,h,z,U){if(typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint")return g=g.get(h)||null,f(o,g,""+z,U);if(typeof z=="object"&&z!==null){switch(z.$$typeof){case tl:return g=g.get(z.key===null?h:z.key)||null,r(o,g,z,U);case $:return g=g.get(z.key===null?h:z.key)||null,y(o,g,z,U);case dl:return z=ue(z),v(g,o,h,z,U)}if(zl(z)||rl(z))return g=g.get(h)||null,S(o,g,z,U,null);if(typeof z.then=="function")return v(g,o,h,Ei(z),U);if(z.$$typeof===sl)return v(g,o,h,Si(o,z),U);Ti(o,z)}return null}function O(g,o,h,z){for(var U=null,I=null,N=o,Q=o=0,J=null;N!==null&&Q<h.length;Q++){N.index>Q?(J=N,N=null):J=N.sibling;var P=p(g,N,h[Q],z);if(P===null){N===null&&(N=J);break}l&&N&&P.alternate===null&&a(g,N),o=i(P,o,Q),I===null?U=P:I.sibling=P,I=P,N=J}if(Q===h.length)return t(g,N),W&&Pa(g,Q),U;if(N===null){for(;Q<h.length;Q++)N=_(g,h[Q],z),N!==null&&(o=i(N,o,Q),I===null?U=N:I.sibling=N,I=N);return W&&Pa(g,Q),U}for(N=e(N);Q<h.length;Q++)J=v(N,g,Q,h[Q],z),J!==null&&(l&&J.alternate!==null&&N.delete(J.key===null?Q:J.key),o=i(J,o,Q),I===null?U=J:I.sibling=J,I=J);return l&&N.forEach(function(Xt){return a(g,Xt)}),W&&Pa(g,Q),U}function H(g,o,h,z){if(h==null)throw Error(m(151));for(var U=null,I=null,N=o,Q=o=0,J=null,P=h.next();N!==null&&!P.done;Q++,P=h.next()){N.index>Q?(J=N,N=null):J=N.sibling;var Xt=p(g,N,P.value,z);if(Xt===null){N===null&&(N=J);break}l&&N&&Xt.alternate===null&&a(g,N),o=i(Xt,o,Q),I===null?U=Xt:I.sibling=Xt,I=Xt,N=J}if(P.done)return t(g,N),W&&Pa(g,Q),U;if(N===null){for(;!P.done;Q++,P=h.next())P=_(g,P.value,z),P!==null&&(o=i(P,o,Q),I===null?U=P:I.sibling=P,I=P);return W&&Pa(g,Q),U}for(N=e(N);!P.done;Q++,P=h.next())P=v(N,g,Q,P.value,z),P!==null&&(l&&P.alternate!==null&&N.delete(P.key===null?Q:P.key),o=i(P,o,Q),I===null?U=P:I.sibling=P,I=P);return l&&N.forEach(function(om){return a(g,om)}),W&&Pa(g,Q),U}function cl(g,o,h,z){if(typeof h=="object"&&h!==null&&h.type===F&&h.key===null&&(h=h.props.children),typeof h=="object"&&h!==null){switch(h.$$typeof){case tl:l:{for(var U=h.key;o!==null;){if(o.key===U){if(U=h.type,U===F){if(o.tag===7){t(g,o.sibling),z=n(o,h.props.children),z.return=g,g=z;break l}}else if(o.elementType===U||typeof U=="object"&&U!==null&&U.$$typeof===dl&&ue(U)===o.type){t(g,o.sibling),z=n(o,h.props),On(z,h),z.return=g,g=z;break l}t(g,o);break}else a(g,o);o=o.sibling}h.type===F?(z=ae(h.props.children,g.mode,z,h.key),z.return=g,g=z):(z=bi(h.type,h.key,h.props,null,g.mode,z),On(z,h),z.return=g,g=z)}return u(g);case $:l:{for(U=h.key;o!==null;){if(o.key===U)if(o.tag===4&&o.stateNode.containerInfo===h.containerInfo&&o.stateNode.implementation===h.implementation){t(g,o.sibling),z=n(o,h.children||[]),z.return=g,g=z;break l}else{t(g,o);break}else a(g,o);o=o.sibling}z=Zu(h,g.mode,z),z.return=g,g=z}return u(g);case dl:return h=ue(h),cl(g,o,h,z)}if(zl(h))return O(g,o,h,z);if(rl(h)){if(U=rl(h),typeof U!="function")throw Error(m(150));return h=U.call(h),H(g,o,h,z)}if(typeof h.then=="function")return cl(g,o,Ei(h),z);if(h.$$typeof===sl)return cl(g,o,Si(g,h),z);Ti(g,h)}return typeof h=="string"&&h!==""||typeof h=="number"||typeof h=="bigint"?(h=""+h,o!==null&&o.tag===6?(t(g,o.sibling),z=n(o,h),z.return=g,g=z):(t(g,o),z=Vu(h,g.mode,z),z.return=g,g=z),u(g)):t(g,o)}return function(g,o,h,z){try{Mn=0;var U=cl(g,o,h,z);return Ze=null,U}catch(N){if(N===Ve||N===_i)throw N;var I=oa(29,N,null,g.mode);return I.lanes=z,I.return=g,I}}}var fe=Js(!0),Ws=Js(!1),Tt=!1;function ec(l){l.updateQueue={baseState:l.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function nc(l,a){l=l.updateQueue,a.updateQueue===l&&(a.updateQueue={baseState:l.baseState,firstBaseUpdate:l.firstBaseUpdate,lastBaseUpdate:l.lastBaseUpdate,shared:l.shared,callbacks:null})}function Mt(l){return{lane:l,tag:0,payload:null,callback:null,next:null}}function Ot(l,a,t){var e=l.updateQueue;if(e===null)return null;if(e=e.shared,(ll&2)!==0){var n=e.pending;return n===null?a.next=a:(a.next=n.next,n.next=a),e.pending=a,a=pi(l),js(l,null,t),a}return yi(l,e,a,t),pi(l)}function Nn(l,a,t){if(a=a.updateQueue,a!==null&&(a=a.shared,(t&4194048)!==0)){var e=a.lanes;e&=l.pendingLanes,t|=e,a.lanes=t,Gf(l,t)}}function ic(l,a){var t=l.updateQueue,e=l.alternate;if(e!==null&&(e=e.updateQueue,t===e)){var n=null,i=null;if(t=t.firstBaseUpdate,t!==null){do{var u={lane:t.lane,tag:t.tag,payload:t.payload,callback:null,next:null};i===null?n=i=u:i=i.next=u,t=t.next}while(t!==null);i===null?n=i=a:i=i.next=a}else n=i=a;t={baseState:e.baseState,firstBaseUpdate:n,lastBaseUpdate:i,shared:e.shared,callbacks:e.callbacks},l.updateQueue=t;return}l=t.lastBaseUpdate,l===null?t.firstBaseUpdate=a:l.next=a,t.lastBaseUpdate=a}var uc=!1;function Dn(){if(uc){var l=Xe;if(l!==null)throw l}}function wn(l,a,t,e){uc=!1;var n=l.updateQueue;Tt=!1;var i=n.firstBaseUpdate,u=n.lastBaseUpdate,f=n.shared.pending;if(f!==null){n.shared.pending=null;var r=f,y=r.next;r.next=null,u===null?i=y:u.next=y,u=r;var S=l.alternate;S!==null&&(S=S.updateQueue,f=S.lastBaseUpdate,f!==u&&(f===null?S.firstBaseUpdate=y:f.next=y,S.lastBaseUpdate=r))}if(i!==null){var _=n.baseState;u=0,S=y=r=null,f=i;do{var p=f.lane&-536870913,v=p!==f.lane;if(v?(K&p)===p:(e&p)===p){p!==0&&p===ke&&(uc=!0),S!==null&&(S=S.next={lane:0,tag:f.tag,payload:f.payload,callback:null,next:null});l:{var O=l,H=f;p=a;var cl=t;switch(H.tag){case 1:if(O=H.payload,typeof O=="function"){_=O.call(cl,_,p);break l}_=O;break l;case 3:O.flags=O.flags&-65537|128;case 0:if(O=H.payload,p=typeof O=="function"?O.call(cl,_,p):O,p==null)break l;_=E({},_,p);break l;case 2:Tt=!0}}p=f.callback,p!==null&&(l.flags|=64,v&&(l.flags|=8192),v=n.callbacks,v===null?n.callbacks=[p]:v.push(p))}else v={lane:p,tag:f.tag,payload:f.payload,callback:f.callback,next:null},S===null?(y=S=v,r=_):S=S.next=v,u|=p;if(f=f.next,f===null){if(f=n.shared.pending,f===null)break;v=f,f=v.next,v.next=null,n.lastBaseUpdate=v,n.shared.pending=null}}while(!0);S===null&&(r=_),n.baseState=r,n.firstBaseUpdate=y,n.lastBaseUpdate=S,i===null&&(n.shared.lanes=0),Ut|=u,l.lanes=u,l.memoizedState=_}}function $s(l,a){if(typeof l!="function")throw Error(m(191,l));l.call(a)}function Fs(l,a){var t=l.callbacks;if(t!==null)for(l.callbacks=null,l=0;l<t.length;l++)$s(t[l],a)}var Le=vl(null),Mi=vl(0);function Is(l,a){l=rt,V(Mi,l),V(Le,a),rt=l|a.baseLanes}function cc(){V(Mi,rt),V(Le,Le.current)}function fc(){rt=Mi.current,al(Le),al(Mi)}var da=vl(null),Ma=null;function Nt(l){var a=l.alternate;V(_l,_l.current&1),V(da,l),Ma===null&&(a===null||Le.current!==null||a.memoizedState!==null)&&(Ma=l)}function sc(l){V(_l,_l.current),V(da,l),Ma===null&&(Ma=l)}function Ps(l){l.tag===22?(V(_l,_l.current),V(da,l),Ma===null&&(Ma=l)):Dt()}function Dt(){V(_l,_l.current),V(da,da.current)}function ma(l){al(da),Ma===l&&(Ma=null),al(_l)}var _l=vl(0);function Oi(l){for(var a=l;a!==null;){if(a.tag===13){var t=a.memoizedState;if(t!==null&&(t=t.dehydrated,t===null||yf(t)||pf(t)))return a}else if(a.tag===19&&(a.memoizedProps.revealOrder==="forwards"||a.memoizedProps.revealOrder==="backwards"||a.memoizedProps.revealOrder==="unstable_legacy-backwards"||a.memoizedProps.revealOrder==="together")){if((a.flags&128)!==0)return a}else if(a.child!==null){a.child.return=a,a=a.child;continue}if(a===l)break;for(;a.sibling===null;){if(a.return===null||a.return===l)return null;a=a.return}a.sibling.return=a.return,a=a.sibling}return null}var tt=0,G=null,il=null,Ml=null,Ni=!1,Ke=!1,se=!1,Di=0,jn=0,Je=null,a1=0;function xl(){throw Error(m(321))}function rc(l,a){if(a===null)return!1;for(var t=0;t<a.length&&t<l.length;t++)if(!ra(l[t],a[t]))return!1;return!0}function oc(l,a,t,e,n,i){return tt=i,G=a,a.memoizedState=null,a.updateQueue=null,a.lanes=0,x.H=l===null||l.memoizedState===null?Br:Tc,se=!1,i=t(e,n),se=!1,Ke&&(i=ar(a,t,e,n)),lr(l),i}function lr(l){x.H=Hn;var a=il!==null&&il.next!==null;if(tt=0,Ml=il=G=null,Ni=!1,jn=0,Je=null,a)throw Error(m(300));l===null||Ol||(l=l.dependencies,l!==null&&xi(l)&&(Ol=!0))}function ar(l,a,t,e){G=l;var n=0;do{if(Ke&&(Je=null),jn=0,Ke=!1,25<=n)throw Error(m(301));if(n+=1,Ml=il=null,l.updateQueue!=null){var i=l.updateQueue;i.lastEffect=null,i.events=null,i.stores=null,i.memoCache!=null&&(i.memoCache.index=0)}x.H=Rr,i=a(t,e)}while(Ke);return i}function t1(){var l=x.H,a=l.useState()[0];return a=typeof a.then=="function"?Un(a):a,l=l.useState()[0],(il!==null?il.memoizedState:null)!==l&&(G.flags|=1024),a}function dc(){var l=Di!==0;return Di=0,l}function mc(l,a,t){a.updateQueue=l.updateQueue,a.flags&=-2053,l.lanes&=~t}function gc(l){if(Ni){for(l=l.memoizedState;l!==null;){var a=l.queue;a!==null&&(a.pending=null),l=l.next}Ni=!1}tt=0,Ml=il=G=null,Ke=!1,jn=Di=0,Je=null}function $l(){var l={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Ml===null?G.memoizedState=Ml=l:Ml=Ml.next=l,Ml}function Al(){if(il===null){var l=G.alternate;l=l!==null?l.memoizedState:null}else l=il.next;var a=Ml===null?G.memoizedState:Ml.next;if(a!==null)Ml=a,il=l;else{if(l===null)throw G.alternate===null?Error(m(467)):Error(m(310));il=l,l={memoizedState:il.memoizedState,baseState:il.baseState,baseQueue:il.baseQueue,queue:il.queue,next:null},Ml===null?G.memoizedState=Ml=l:Ml=Ml.next=l}return Ml}function wi(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Un(l){var a=jn;return jn+=1,Je===null&&(Je=[]),l=Zs(Je,l,a),a=G,(Ml===null?a.memoizedState:Ml.next)===null&&(a=a.alternate,x.H=a===null||a.memoizedState===null?Br:Tc),l}function ji(l){if(l!==null&&typeof l=="object"){if(typeof l.then=="function")return Un(l);if(l.$$typeof===sl)return Xl(l)}throw Error(m(438,String(l)))}function hc(l){var a=null,t=G.updateQueue;if(t!==null&&(a=t.memoCache),a==null){var e=G.alternate;e!==null&&(e=e.updateQueue,e!==null&&(e=e.memoCache,e!=null&&(a={data:e.data.map(function(n){return n.slice()}),index:0})))}if(a==null&&(a={data:[],index:0}),t===null&&(t=wi(),G.updateQueue=t),t.memoCache=a,t=a.data[a.index],t===void 0)for(t=a.data[a.index]=Array(l),e=0;e<l;e++)t[e]=Jl;return a.index++,t}function et(l,a){return typeof a=="function"?a(l):a}function Ui(l){var a=Al();return yc(a,il,l)}function yc(l,a,t){var e=l.queue;if(e===null)throw Error(m(311));e.lastRenderedReducer=t;var n=l.baseQueue,i=e.pending;if(i!==null){if(n!==null){var u=n.next;n.next=i.next,i.next=u}a.baseQueue=n=i,e.pending=null}if(i=l.baseState,n===null)l.memoizedState=i;else{a=n.next;var f=u=null,r=null,y=a,S=!1;do{var _=y.lane&-536870913;if(_!==y.lane?(K&_)===_:(tt&_)===_){var p=y.revertLane;if(p===0)r!==null&&(r=r.next={lane:0,revertLane:0,gesture:null,action:y.action,hasEagerState:y.hasEagerState,eagerState:y.eagerState,next:null}),_===ke&&(S=!0);else if((tt&p)===p){y=y.next,p===ke&&(S=!0);continue}else _={lane:0,revertLane:y.revertLane,gesture:null,action:y.action,hasEagerState:y.hasEagerState,eagerState:y.eagerState,next:null},r===null?(f=r=_,u=i):r=r.next=_,G.lanes|=p,Ut|=p;_=y.action,se&&t(i,_),i=y.hasEagerState?y.eagerState:t(i,_)}else p={lane:_,revertLane:y.revertLane,gesture:y.gesture,action:y.action,hasEagerState:y.hasEagerState,eagerState:y.eagerState,next:null},r===null?(f=r=p,u=i):r=r.next=p,G.lanes|=_,Ut|=_;y=y.next}while(y!==null&&y!==a);if(r===null?u=i:r.next=f,!ra(i,l.memoizedState)&&(Ol=!0,S&&(t=Xe,t!==null)))throw t;l.memoizedState=i,l.baseState=u,l.baseQueue=r,e.lastRenderedState=i}return n===null&&(e.lanes=0),[l.memoizedState,e.dispatch]}function pc(l){var a=Al(),t=a.queue;if(t===null)throw Error(m(311));t.lastRenderedReducer=l;var e=t.dispatch,n=t.pending,i=a.memoizedState;if(n!==null){t.pending=null;var u=n=n.next;do i=l(i,u.action),u=u.next;while(u!==n);ra(i,a.memoizedState)||(Ol=!0),a.memoizedState=i,a.baseQueue===null&&(a.baseState=i),t.lastRenderedState=i}return[i,e]}function tr(l,a,t){var e=G,n=Al(),i=W;if(i){if(t===void 0)throw Error(m(407));t=t()}else t=a();var u=!ra((il||n).memoizedState,t);if(u&&(n.memoizedState=t,Ol=!0),n=n.queue,xc(ir.bind(null,e,n,l),[l]),n.getSnapshot!==a||u||Ml!==null&&Ml.memoizedState.tag&1){if(e.flags|=2048,We(9,{destroy:void 0},nr.bind(null,e,n,t,a),null),fl===null)throw Error(m(349));i||(tt&127)!==0||er(e,a,t)}return t}function er(l,a,t){l.flags|=16384,l={getSnapshot:a,value:t},a=G.updateQueue,a===null?(a=wi(),G.updateQueue=a,a.stores=[l]):(t=a.stores,t===null?a.stores=[l]:t.push(l))}function nr(l,a,t,e){a.value=t,a.getSnapshot=e,ur(a)&&cr(l)}function ir(l,a,t){return t(function(){ur(a)&&cr(l)})}function ur(l){var a=l.getSnapshot;l=l.value;try{var t=a();return!ra(l,t)}catch{return!0}}function cr(l){var a=le(l,2);a!==null&&na(a,l,2)}function bc(l){var a=$l();if(typeof l=="function"){var t=l;if(l=t(),se){sa(!0);try{t()}finally{sa(!1)}}}return a.memoizedState=a.baseState=l,a.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:et,lastRenderedState:l},a}function fr(l,a,t,e){return l.baseState=t,yc(l,il,typeof e=="function"?e:et)}function e1(l,a,t,e,n){if(Bi(l))throw Error(m(485));if(l=a.action,l!==null){var i={payload:n,action:l,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(u){i.listeners.push(u)}};x.T!==null?t(!0):i.isTransition=!1,e(i),t=a.pending,t===null?(i.next=a.pending=i,sr(a,i)):(i.next=t.next,a.pending=t.next=i)}}function sr(l,a){var t=a.action,e=a.payload,n=l.state;if(a.isTransition){var i=x.T,u={};x.T=u;try{var f=t(n,e),r=x.S;r!==null&&r(u,f),rr(l,a,f)}catch(y){vc(l,a,y)}finally{i!==null&&u.types!==null&&(i.types=u.types),x.T=i}}else try{i=t(n,e),rr(l,a,i)}catch(y){vc(l,a,y)}}function rr(l,a,t){t!==null&&typeof t=="object"&&typeof t.then=="function"?t.then(function(e){or(l,a,e)},function(e){return vc(l,a,e)}):or(l,a,t)}function or(l,a,t){a.status="fulfilled",a.value=t,dr(a),l.state=t,a=l.pending,a!==null&&(t=a.next,t===a?l.pending=null:(t=t.next,a.next=t,sr(l,t)))}function vc(l,a,t){var e=l.pending;if(l.pending=null,e!==null){e=e.next;do a.status="rejected",a.reason=t,dr(a),a=a.next;while(a!==e)}l.action=null}function dr(l){l=l.listeners;for(var a=0;a<l.length;a++)(0,l[a])()}function mr(l,a){return a}function gr(l,a){if(W){var t=fl.formState;if(t!==null){l:{var e=G;if(W){if(ml){a:{for(var n=ml,i=Ta;n.nodeType!==8;){if(!i){n=null;break a}if(n=Oa(n.nextSibling),n===null){n=null;break a}}i=n.data,n=i==="F!"||i==="F"?n:null}if(n){ml=Oa(n.nextSibling),e=n.data==="F!";break l}}At(e)}e=!1}e&&(a=t[0])}}return t=$l(),t.memoizedState=t.baseState=a,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:mr,lastRenderedState:a},t.queue=e,t=Ur.bind(null,G,e),e.dispatch=t,e=bc(!1),i=Ec.bind(null,G,!1,e.queue),e=$l(),n={state:a,dispatch:null,action:l,pending:null},e.queue=n,t=e1.bind(null,G,n,i,t),n.dispatch=t,e.memoizedState=l,[a,t,!1]}function hr(l){var a=Al();return yr(a,il,l)}function yr(l,a,t){if(a=yc(l,a,mr)[0],l=Ui(et)[0],typeof a=="object"&&a!==null&&typeof a.then=="function")try{var e=Un(a)}catch(u){throw u===Ve?_i:u}else e=a;a=Al();var n=a.queue,i=n.dispatch;return t!==a.memoizedState&&(G.flags|=2048,We(9,{destroy:void 0},n1.bind(null,n,t),null)),[e,i,l]}function n1(l,a){l.action=a}function pr(l){var a=Al(),t=il;if(t!==null)return yr(a,t,l);Al(),a=a.memoizedState,t=Al();var e=t.queue.dispatch;return t.memoizedState=l,[a,e,!1]}function We(l,a,t,e){return l={tag:l,create:t,deps:e,inst:a,next:null},a=G.updateQueue,a===null&&(a=wi(),G.updateQueue=a),t=a.lastEffect,t===null?a.lastEffect=l.next=l:(e=t.next,t.next=l,l.next=e,a.lastEffect=l),l}function br(){return Al().memoizedState}function Ci(l,a,t,e){var n=$l();G.flags|=l,n.memoizedState=We(1|a,{destroy:void 0},t,e===void 0?null:e)}function Hi(l,a,t,e){var n=Al();e=e===void 0?null:e;var i=n.memoizedState.inst;il!==null&&e!==null&&rc(e,il.memoizedState.deps)?n.memoizedState=We(a,i,t,e):(G.flags|=l,n.memoizedState=We(1|a,i,t,e))}function vr(l,a){Ci(8390656,8,l,a)}function xc(l,a){Hi(2048,8,l,a)}function i1(l){G.flags|=4;var a=G.updateQueue;if(a===null)a=wi(),G.updateQueue=a,a.events=[l];else{var t=a.events;t===null?a.events=[l]:t.push(l)}}function xr(l){var a=Al().memoizedState;return i1({ref:a,nextImpl:l}),function(){if((ll&2)!==0)throw Error(m(440));return a.impl.apply(void 0,arguments)}}function Sr(l,a){return Hi(4,2,l,a)}function zr(l,a){return Hi(4,4,l,a)}function _r(l,a){if(typeof a=="function"){l=l();var t=a(l);return function(){typeof t=="function"?t():a(null)}}if(a!=null)return l=l(),a.current=l,function(){a.current=null}}function Ar(l,a,t){t=t!=null?t.concat([l]):null,Hi(4,4,_r.bind(null,a,l),t)}function Sc(){}function Er(l,a){var t=Al();a=a===void 0?null:a;var e=t.memoizedState;return a!==null&&rc(a,e[1])?e[0]:(t.memoizedState=[l,a],l)}function Tr(l,a){var t=Al();a=a===void 0?null:a;var e=t.memoizedState;if(a!==null&&rc(a,e[1]))return e[0];if(e=l(),se){sa(!0);try{l()}finally{sa(!1)}}return t.memoizedState=[e,a],e}function zc(l,a,t){return t===void 0||(tt&1073741824)!==0&&(K&261930)===0?l.memoizedState=a:(l.memoizedState=t,l=Oo(),G.lanes|=l,Ut|=l,t)}function Mr(l,a,t,e){return ra(t,a)?t:Le.current!==null?(l=zc(l,t,e),ra(l,a)||(Ol=!0),l):(tt&42)===0||(tt&1073741824)!==0&&(K&261930)===0?(Ol=!0,l.memoizedState=t):(l=Oo(),G.lanes|=l,Ut|=l,a)}function Or(l,a,t,e,n){var i=A.p;A.p=i!==0&&8>i?i:8;var u=x.T,f={};x.T=f,Ec(l,!1,a,t);try{var r=n(),y=x.S;if(y!==null&&y(f,r),r!==null&&typeof r=="object"&&typeof r.then=="function"){var S=l1(r,e);Cn(l,a,S,ya(l))}else Cn(l,a,e,ya(l))}catch(_){Cn(l,a,{then:function(){},status:"rejected",reason:_},ya())}finally{A.p=i,u!==null&&f.types!==null&&(u.types=f.types),x.T=u}}function u1(){}function _c(l,a,t,e){if(l.tag!==5)throw Error(m(476));var n=Nr(l).queue;Or(l,n,a,j,t===null?u1:function(){return Dr(l),t(e)})}function Nr(l){var a=l.memoizedState;if(a!==null)return a;a={memoizedState:j,baseState:j,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:et,lastRenderedState:j},next:null};var t={};return a.next={memoizedState:t,baseState:t,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:et,lastRenderedState:t},next:null},l.memoizedState=a,l=l.alternate,l!==null&&(l.memoizedState=a),a}function Dr(l){var a=Nr(l);a.next===null&&(a=l.alternate.memoizedState),Cn(l,a.next.queue,{},ya())}function Ac(){return Xl(Fn)}function wr(){return Al().memoizedState}function jr(){return Al().memoizedState}function c1(l){for(var a=l.return;a!==null;){switch(a.tag){case 24:case 3:var t=ya();l=Mt(t);var e=Ot(a,l,t);e!==null&&(na(e,a,t),Nn(e,a,t)),a={cache:Pu()},l.payload=a;return}a=a.return}}function f1(l,a,t){var e=ya();t={lane:e,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null},Bi(l)?Cr(a,t):(t=ku(l,a,t,e),t!==null&&(na(t,l,e),Hr(t,a,e)))}function Ur(l,a,t){var e=ya();Cn(l,a,t,e)}function Cn(l,a,t,e){var n={lane:e,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null};if(Bi(l))Cr(a,n);else{var i=l.alternate;if(l.lanes===0&&(i===null||i.lanes===0)&&(i=a.lastRenderedReducer,i!==null))try{var u=a.lastRenderedState,f=i(u,t);if(n.hasEagerState=!0,n.eagerState=f,ra(f,u))return yi(l,a,n,0),fl===null&&hi(),!1}catch{}if(t=ku(l,a,n,e),t!==null)return na(t,l,e),Hr(t,a,e),!0}return!1}function Ec(l,a,t,e){if(e={lane:2,revertLane:ef(),gesture:null,action:e,hasEagerState:!1,eagerState:null,next:null},Bi(l)){if(a)throw Error(m(479))}else a=ku(l,t,e,2),a!==null&&na(a,l,2)}function Bi(l){var a=l.alternate;return l===G||a!==null&&a===G}function Cr(l,a){Ke=Ni=!0;var t=l.pending;t===null?a.next=a:(a.next=t.next,t.next=a),l.pending=a}function Hr(l,a,t){if((t&4194048)!==0){var e=a.lanes;e&=l.pendingLanes,t|=e,a.lanes=t,Gf(l,t)}}var Hn={readContext:Xl,use:ji,useCallback:xl,useContext:xl,useEffect:xl,useImperativeHandle:xl,useLayoutEffect:xl,useInsertionEffect:xl,useMemo:xl,useReducer:xl,useRef:xl,useState:xl,useDebugValue:xl,useDeferredValue:xl,useTransition:xl,useSyncExternalStore:xl,useId:xl,useHostTransitionStatus:xl,useFormState:xl,useActionState:xl,useOptimistic:xl,useMemoCache:xl,useCacheRefresh:xl};Hn.useEffectEvent=xl;var Br={readContext:Xl,use:ji,useCallback:function(l,a){return $l().memoizedState=[l,a===void 0?null:a],l},useContext:Xl,useEffect:vr,useImperativeHandle:function(l,a,t){t=t!=null?t.concat([l]):null,Ci(4194308,4,_r.bind(null,a,l),t)},useLayoutEffect:function(l,a){return Ci(4194308,4,l,a)},useInsertionEffect:function(l,a){Ci(4,2,l,a)},useMemo:function(l,a){var t=$l();a=a===void 0?null:a;var e=l();if(se){sa(!0);try{l()}finally{sa(!1)}}return t.memoizedState=[e,a],e},useReducer:function(l,a,t){var e=$l();if(t!==void 0){var n=t(a);if(se){sa(!0);try{t(a)}finally{sa(!1)}}}else n=a;return e.memoizedState=e.baseState=n,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:l,lastRenderedState:n},e.queue=l,l=l.dispatch=f1.bind(null,G,l),[e.memoizedState,l]},useRef:function(l){var a=$l();return l={current:l},a.memoizedState=l},useState:function(l){l=bc(l);var a=l.queue,t=Ur.bind(null,G,a);return a.dispatch=t,[l.memoizedState,t]},useDebugValue:Sc,useDeferredValue:function(l,a){var t=$l();return zc(t,l,a)},useTransition:function(){var l=bc(!1);return l=Or.bind(null,G,l.queue,!0,!1),$l().memoizedState=l,[!1,l]},useSyncExternalStore:function(l,a,t){var e=G,n=$l();if(W){if(t===void 0)throw Error(m(407));t=t()}else{if(t=a(),fl===null)throw Error(m(349));(K&127)!==0||er(e,a,t)}n.memoizedState=t;var i={value:t,getSnapshot:a};return n.queue=i,vr(ir.bind(null,e,i,l),[l]),e.flags|=2048,We(9,{destroy:void 0},nr.bind(null,e,i,t,a),null),t},useId:function(){var l=$l(),a=fl.identifierPrefix;if(W){var t=ka,e=Qa;t=(e&~(1<<32-ql(e)-1)).toString(32)+t,a="_"+a+"R_"+t,t=Di++,0<t&&(a+="H"+t.toString(32)),a+="_"}else t=a1++,a="_"+a+"r_"+t.toString(32)+"_";return l.memoizedState=a},useHostTransitionStatus:Ac,useFormState:gr,useActionState:gr,useOptimistic:function(l){var a=$l();a.memoizedState=a.baseState=l;var t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return a.queue=t,a=Ec.bind(null,G,!0,t),t.dispatch=a,[l,a]},useMemoCache:hc,useCacheRefresh:function(){return $l().memoizedState=c1.bind(null,G)},useEffectEvent:function(l){var a=$l(),t={impl:l};return a.memoizedState=t,function(){if((ll&2)!==0)throw Error(m(440));return t.impl.apply(void 0,arguments)}}},Tc={readContext:Xl,use:ji,useCallback:Er,useContext:Xl,useEffect:xc,useImperativeHandle:Ar,useInsertionEffect:Sr,useLayoutEffect:zr,useMemo:Tr,useReducer:Ui,useRef:br,useState:function(){return Ui(et)},useDebugValue:Sc,useDeferredValue:function(l,a){var t=Al();return Mr(t,il.memoizedState,l,a)},useTransition:function(){var l=Ui(et)[0],a=Al().memoizedState;return[typeof l=="boolean"?l:Un(l),a]},useSyncExternalStore:tr,useId:wr,useHostTransitionStatus:Ac,useFormState:hr,useActionState:hr,useOptimistic:function(l,a){var t=Al();return fr(t,il,l,a)},useMemoCache:hc,useCacheRefresh:jr};Tc.useEffectEvent=xr;var Rr={readContext:Xl,use:ji,useCallback:Er,useContext:Xl,useEffect:xc,useImperativeHandle:Ar,useInsertionEffect:Sr,useLayoutEffect:zr,useMemo:Tr,useReducer:pc,useRef:br,useState:function(){return pc(et)},useDebugValue:Sc,useDeferredValue:function(l,a){var t=Al();return il===null?zc(t,l,a):Mr(t,il.memoizedState,l,a)},useTransition:function(){var l=pc(et)[0],a=Al().memoizedState;return[typeof l=="boolean"?l:Un(l),a]},useSyncExternalStore:tr,useId:wr,useHostTransitionStatus:Ac,useFormState:pr,useActionState:pr,useOptimistic:function(l,a){var t=Al();return il!==null?fr(t,il,l,a):(t.baseState=l,[l,t.queue.dispatch])},useMemoCache:hc,useCacheRefresh:jr};Rr.useEffectEvent=xr;function Mc(l,a,t,e){a=l.memoizedState,t=t(e,a),t=t==null?a:E({},a,t),l.memoizedState=t,l.lanes===0&&(l.updateQueue.baseState=t)}var Oc={enqueueSetState:function(l,a,t){l=l._reactInternals;var e=ya(),n=Mt(e);n.payload=a,t!=null&&(n.callback=t),a=Ot(l,n,e),a!==null&&(na(a,l,e),Nn(a,l,e))},enqueueReplaceState:function(l,a,t){l=l._reactInternals;var e=ya(),n=Mt(e);n.tag=1,n.payload=a,t!=null&&(n.callback=t),a=Ot(l,n,e),a!==null&&(na(a,l,e),Nn(a,l,e))},enqueueForceUpdate:function(l,a){l=l._reactInternals;var t=ya(),e=Mt(t);e.tag=2,a!=null&&(e.callback=a),a=Ot(l,e,t),a!==null&&(na(a,l,t),Nn(a,l,t))}};function qr(l,a,t,e,n,i,u){return l=l.stateNode,typeof l.shouldComponentUpdate=="function"?l.shouldComponentUpdate(e,i,u):a.prototype&&a.prototype.isPureReactComponent?!Sn(t,e)||!Sn(n,i):!0}function Yr(l,a,t,e){l=a.state,typeof a.componentWillReceiveProps=="function"&&a.componentWillReceiveProps(t,e),typeof a.UNSAFE_componentWillReceiveProps=="function"&&a.UNSAFE_componentWillReceiveProps(t,e),a.state!==l&&Oc.enqueueReplaceState(a,a.state,null)}function re(l,a){var t=a;if("ref"in a){t={};for(var e in a)e!=="ref"&&(t[e]=a[e])}if(l=l.defaultProps){t===a&&(t=E({},t));for(var n in l)t[n]===void 0&&(t[n]=l[n])}return t}function Gr(l){gi(l)}function Qr(l){console.error(l)}function kr(l){gi(l)}function Ri(l,a){try{var t=l.onUncaughtError;t(a.value,{componentStack:a.stack})}catch(e){setTimeout(function(){throw e})}}function Xr(l,a,t){try{var e=l.onCaughtError;e(t.value,{componentStack:t.stack,errorBoundary:a.tag===1?a.stateNode:null})}catch(n){setTimeout(function(){throw n})}}function Nc(l,a,t){return t=Mt(t),t.tag=3,t.payload={element:null},t.callback=function(){Ri(l,a)},t}function Vr(l){return l=Mt(l),l.tag=3,l}function Zr(l,a,t,e){var n=t.type.getDerivedStateFromError;if(typeof n=="function"){var i=e.value;l.payload=function(){return n(i)},l.callback=function(){Xr(a,t,e)}}var u=t.stateNode;u!==null&&typeof u.componentDidCatch=="function"&&(l.callback=function(){Xr(a,t,e),typeof n!="function"&&(Ct===null?Ct=new Set([this]):Ct.add(this));var f=e.stack;this.componentDidCatch(e.value,{componentStack:f!==null?f:""})})}function s1(l,a,t,e,n){if(t.flags|=32768,e!==null&&typeof e=="object"&&typeof e.then=="function"){if(a=t.alternate,a!==null&&Qe(a,t,n,!0),t=da.current,t!==null){switch(t.tag){case 31:case 13:return Ma===null?Wi():t.alternate===null&&Sl===0&&(Sl=3),t.flags&=-257,t.flags|=65536,t.lanes=n,e===Ai?t.flags|=16384:(a=t.updateQueue,a===null?t.updateQueue=new Set([e]):a.add(e),lf(l,e,n)),!1;case 22:return t.flags|=65536,e===Ai?t.flags|=16384:(a=t.updateQueue,a===null?(a={transitions:null,markerInstances:null,retryQueue:new Set([e])},t.updateQueue=a):(t=a.retryQueue,t===null?a.retryQueue=new Set([e]):t.add(e)),lf(l,e,n)),!1}throw Error(m(435,t.tag))}return lf(l,e,n),Wi(),!1}if(W)return a=da.current,a!==null?((a.flags&65536)===0&&(a.flags|=256),a.flags|=65536,a.lanes=n,e!==Ju&&(l=Error(m(422),{cause:e}),An(_a(l,t)))):(e!==Ju&&(a=Error(m(423),{cause:e}),An(_a(a,t))),l=l.current.alternate,l.flags|=65536,n&=-n,l.lanes|=n,e=_a(e,t),n=Nc(l.stateNode,e,n),ic(l,n),Sl!==4&&(Sl=2)),!1;var i=Error(m(520),{cause:e});if(i=_a(i,t),Xn===null?Xn=[i]:Xn.push(i),Sl!==4&&(Sl=2),a===null)return!0;e=_a(e,t),t=a;do{switch(t.tag){case 3:return t.flags|=65536,l=n&-n,t.lanes|=l,l=Nc(t.stateNode,e,l),ic(t,l),!1;case 1:if(a=t.type,i=t.stateNode,(t.flags&128)===0&&(typeof a.getDerivedStateFromError=="function"||i!==null&&typeof i.componentDidCatch=="function"&&(Ct===null||!Ct.has(i))))return t.flags|=65536,n&=-n,t.lanes|=n,n=Vr(n),Zr(n,l,t,e),ic(t,n),!1}t=t.return}while(t!==null);return!1}var Dc=Error(m(461)),Ol=!1;function Vl(l,a,t,e){a.child=l===null?Ws(a,null,t,e):fe(a,l.child,t,e)}function Lr(l,a,t,e,n){t=t.render;var i=a.ref;if("ref"in e){var u={};for(var f in e)f!=="ref"&&(u[f]=e[f])}else u=e;return ne(a),e=oc(l,a,t,u,i,n),f=dc(),l!==null&&!Ol?(mc(l,a,n),nt(l,a,n)):(W&&f&&Lu(a),a.flags|=1,Vl(l,a,e,n),a.child)}function Kr(l,a,t,e,n){if(l===null){var i=t.type;return typeof i=="function"&&!Xu(i)&&i.defaultProps===void 0&&t.compare===null?(a.tag=15,a.type=i,Jr(l,a,i,e,n)):(l=bi(t.type,null,e,a,a.mode,n),l.ref=a.ref,l.return=a,a.child=l)}if(i=l.child,!qc(l,n)){var u=i.memoizedProps;if(t=t.compare,t=t!==null?t:Sn,t(u,e)&&l.ref===a.ref)return nt(l,a,n)}return a.flags|=1,l=Ia(i,e),l.ref=a.ref,l.return=a,a.child=l}function Jr(l,a,t,e,n){if(l!==null){var i=l.memoizedProps;if(Sn(i,e)&&l.ref===a.ref)if(Ol=!1,a.pendingProps=e=i,qc(l,n))(l.flags&131072)!==0&&(Ol=!0);else return a.lanes=l.lanes,nt(l,a,n)}return wc(l,a,t,e,n)}function Wr(l,a,t,e){var n=e.children,i=l!==null?l.memoizedState:null;if(l===null&&a.stateNode===null&&(a.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),e.mode==="hidden"){if((a.flags&128)!==0){if(i=i!==null?i.baseLanes|t:t,l!==null){for(e=a.child=l.child,n=0;e!==null;)n=n|e.lanes|e.childLanes,e=e.sibling;e=n&~i}else e=0,a.child=null;return $r(l,a,i,t,e)}if((t&536870912)!==0)a.memoizedState={baseLanes:0,cachePool:null},l!==null&&zi(a,i!==null?i.cachePool:null),i!==null?Is(a,i):cc(),Ps(a);else return e=a.lanes=536870912,$r(l,a,i!==null?i.baseLanes|t:t,t,e)}else i!==null?(zi(a,i.cachePool),Is(a,i),Dt(),a.memoizedState=null):(l!==null&&zi(a,null),cc(),Dt());return Vl(l,a,n,t),a.child}function Bn(l,a){return l!==null&&l.tag===22||a.stateNode!==null||(a.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),a.sibling}function $r(l,a,t,e,n){var i=ac();return i=i===null?null:{parent:Tl._currentValue,pool:i},a.memoizedState={baseLanes:t,cachePool:i},l!==null&&zi(a,null),cc(),Ps(a),l!==null&&Qe(l,a,e,!0),a.childLanes=n,null}function qi(l,a){return a=Gi({mode:a.mode,children:a.children},l.mode),a.ref=l.ref,l.child=a,a.return=l,a}function Fr(l,a,t){return fe(a,l.child,null,t),l=qi(a,a.pendingProps),l.flags|=2,ma(a),a.memoizedState=null,l}function r1(l,a,t){var e=a.pendingProps,n=(a.flags&128)!==0;if(a.flags&=-129,l===null){if(W){if(e.mode==="hidden")return l=qi(a,e),a.lanes=536870912,Bn(null,l);if(sc(a),(l=ml)?(l=rd(l,Ta),l=l!==null&&l.data==="&"?l:null,l!==null&&(a.memoizedState={dehydrated:l,treeContext:zt!==null?{id:Qa,overflow:ka}:null,retryLane:536870912,hydrationErrors:null},t=Cs(l),t.return=a,a.child=t,kl=a,ml=null)):l=null,l===null)throw At(a);return a.lanes=536870912,null}return qi(a,e)}var i=l.memoizedState;if(i!==null){var u=i.dehydrated;if(sc(a),n)if(a.flags&256)a.flags&=-257,a=Fr(l,a,t);else if(a.memoizedState!==null)a.child=l.child,a.flags|=128,a=null;else throw Error(m(558));else if(Ol||Qe(l,a,t,!1),n=(t&l.childLanes)!==0,Ol||n){if(e=fl,e!==null&&(u=Qf(e,t),u!==0&&u!==i.retryLane))throw i.retryLane=u,le(l,u),na(e,l,u),Dc;Wi(),a=Fr(l,a,t)}else l=i.treeContext,ml=Oa(u.nextSibling),kl=a,W=!0,_t=null,Ta=!1,l!==null&&Rs(a,l),a=qi(a,e),a.flags|=4096;return a}return l=Ia(l.child,{mode:e.mode,children:e.children}),l.ref=a.ref,a.child=l,l.return=a,l}function Yi(l,a){var t=a.ref;if(t===null)l!==null&&l.ref!==null&&(a.flags|=4194816);else{if(typeof t!="function"&&typeof t!="object")throw Error(m(284));(l===null||l.ref!==t)&&(a.flags|=4194816)}}function wc(l,a,t,e,n){return ne(a),t=oc(l,a,t,e,void 0,n),e=dc(),l!==null&&!Ol?(mc(l,a,n),nt(l,a,n)):(W&&e&&Lu(a),a.flags|=1,Vl(l,a,t,n),a.child)}function Ir(l,a,t,e,n,i){return ne(a),a.updateQueue=null,t=ar(a,e,t,n),lr(l),e=dc(),l!==null&&!Ol?(mc(l,a,i),nt(l,a,i)):(W&&e&&Lu(a),a.flags|=1,Vl(l,a,t,i),a.child)}function Pr(l,a,t,e,n){if(ne(a),a.stateNode===null){var i=Re,u=t.contextType;typeof u=="object"&&u!==null&&(i=Xl(u)),i=new t(e,i),a.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,i.updater=Oc,a.stateNode=i,i._reactInternals=a,i=a.stateNode,i.props=e,i.state=a.memoizedState,i.refs={},ec(a),u=t.contextType,i.context=typeof u=="object"&&u!==null?Xl(u):Re,i.state=a.memoizedState,u=t.getDerivedStateFromProps,typeof u=="function"&&(Mc(a,t,u,e),i.state=a.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(u=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),u!==i.state&&Oc.enqueueReplaceState(i,i.state,null),wn(a,e,i,n),Dn(),i.state=a.memoizedState),typeof i.componentDidMount=="function"&&(a.flags|=4194308),e=!0}else if(l===null){i=a.stateNode;var f=a.memoizedProps,r=re(t,f);i.props=r;var y=i.context,S=t.contextType;u=Re,typeof S=="object"&&S!==null&&(u=Xl(S));var _=t.getDerivedStateFromProps;S=typeof _=="function"||typeof i.getSnapshotBeforeUpdate=="function",f=a.pendingProps!==f,S||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(f||y!==u)&&Yr(a,i,e,u),Tt=!1;var p=a.memoizedState;i.state=p,wn(a,e,i,n),Dn(),y=a.memoizedState,f||p!==y||Tt?(typeof _=="function"&&(Mc(a,t,_,e),y=a.memoizedState),(r=Tt||qr(a,t,r,e,p,y,u))?(S||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(a.flags|=4194308)):(typeof i.componentDidMount=="function"&&(a.flags|=4194308),a.memoizedProps=e,a.memoizedState=y),i.props=e,i.state=y,i.context=u,e=r):(typeof i.componentDidMount=="function"&&(a.flags|=4194308),e=!1)}else{i=a.stateNode,nc(l,a),u=a.memoizedProps,S=re(t,u),i.props=S,_=a.pendingProps,p=i.context,y=t.contextType,r=Re,typeof y=="object"&&y!==null&&(r=Xl(y)),f=t.getDerivedStateFromProps,(y=typeof f=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(u!==_||p!==r)&&Yr(a,i,e,r),Tt=!1,p=a.memoizedState,i.state=p,wn(a,e,i,n),Dn();var v=a.memoizedState;u!==_||p!==v||Tt||l!==null&&l.dependencies!==null&&xi(l.dependencies)?(typeof f=="function"&&(Mc(a,t,f,e),v=a.memoizedState),(S=Tt||qr(a,t,S,e,p,v,r)||l!==null&&l.dependencies!==null&&xi(l.dependencies))?(y||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(e,v,r),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(e,v,r)),typeof i.componentDidUpdate=="function"&&(a.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(a.flags|=1024)):(typeof i.componentDidUpdate!="function"||u===l.memoizedProps&&p===l.memoizedState||(a.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===l.memoizedProps&&p===l.memoizedState||(a.flags|=1024),a.memoizedProps=e,a.memoizedState=v),i.props=e,i.state=v,i.context=r,e=S):(typeof i.componentDidUpdate!="function"||u===l.memoizedProps&&p===l.memoizedState||(a.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===l.memoizedProps&&p===l.memoizedState||(a.flags|=1024),e=!1)}return i=e,Yi(l,a),e=(a.flags&128)!==0,i||e?(i=a.stateNode,t=e&&typeof t.getDerivedStateFromError!="function"?null:i.render(),a.flags|=1,l!==null&&e?(a.child=fe(a,l.child,null,n),a.child=fe(a,null,t,n)):Vl(l,a,t,n),a.memoizedState=i.state,l=a.child):l=nt(l,a,n),l}function lo(l,a,t,e){return te(),a.flags|=256,Vl(l,a,t,e),a.child}var jc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Uc(l){return{baseLanes:l,cachePool:Xs()}}function Cc(l,a,t){return l=l!==null?l.childLanes&~t:0,a&&(l|=ha),l}function ao(l,a,t){var e=a.pendingProps,n=!1,i=(a.flags&128)!==0,u;if((u=i)||(u=l!==null&&l.memoizedState===null?!1:(_l.current&2)!==0),u&&(n=!0,a.flags&=-129),u=(a.flags&32)!==0,a.flags&=-33,l===null){if(W){if(n?Nt(a):Dt(),(l=ml)?(l=rd(l,Ta),l=l!==null&&l.data!=="&"?l:null,l!==null&&(a.memoizedState={dehydrated:l,treeContext:zt!==null?{id:Qa,overflow:ka}:null,retryLane:536870912,hydrationErrors:null},t=Cs(l),t.return=a,a.child=t,kl=a,ml=null)):l=null,l===null)throw At(a);return pf(l)?a.lanes=32:a.lanes=536870912,null}var f=e.children;return e=e.fallback,n?(Dt(),n=a.mode,f=Gi({mode:"hidden",children:f},n),e=ae(e,n,t,null),f.return=a,e.return=a,f.sibling=e,a.child=f,e=a.child,e.memoizedState=Uc(t),e.childLanes=Cc(l,u,t),a.memoizedState=jc,Bn(null,e)):(Nt(a),Hc(a,f))}var r=l.memoizedState;if(r!==null&&(f=r.dehydrated,f!==null)){if(i)a.flags&256?(Nt(a),a.flags&=-257,a=Bc(l,a,t)):a.memoizedState!==null?(Dt(),a.child=l.child,a.flags|=128,a=null):(Dt(),f=e.fallback,n=a.mode,e=Gi({mode:"visible",children:e.children},n),f=ae(f,n,t,null),f.flags|=2,e.return=a,f.return=a,e.sibling=f,a.child=e,fe(a,l.child,null,t),e=a.child,e.memoizedState=Uc(t),e.childLanes=Cc(l,u,t),a.memoizedState=jc,a=Bn(null,e));else if(Nt(a),pf(f)){if(u=f.nextSibling&&f.nextSibling.dataset,u)var y=u.dgst;u=y,e=Error(m(419)),e.stack="",e.digest=u,An({value:e,source:null,stack:null}),a=Bc(l,a,t)}else if(Ol||Qe(l,a,t,!1),u=(t&l.childLanes)!==0,Ol||u){if(u=fl,u!==null&&(e=Qf(u,t),e!==0&&e!==r.retryLane))throw r.retryLane=e,le(l,e),na(u,l,e),Dc;yf(f)||Wi(),a=Bc(l,a,t)}else yf(f)?(a.flags|=192,a.child=l.child,a=null):(l=r.treeContext,ml=Oa(f.nextSibling),kl=a,W=!0,_t=null,Ta=!1,l!==null&&Rs(a,l),a=Hc(a,e.children),a.flags|=4096);return a}return n?(Dt(),f=e.fallback,n=a.mode,r=l.child,y=r.sibling,e=Ia(r,{mode:"hidden",children:e.children}),e.subtreeFlags=r.subtreeFlags&65011712,y!==null?f=Ia(y,f):(f=ae(f,n,t,null),f.flags|=2),f.return=a,e.return=a,e.sibling=f,a.child=e,Bn(null,e),e=a.child,f=l.child.memoizedState,f===null?f=Uc(t):(n=f.cachePool,n!==null?(r=Tl._currentValue,n=n.parent!==r?{parent:r,pool:r}:n):n=Xs(),f={baseLanes:f.baseLanes|t,cachePool:n}),e.memoizedState=f,e.childLanes=Cc(l,u,t),a.memoizedState=jc,Bn(l.child,e)):(Nt(a),t=l.child,l=t.sibling,t=Ia(t,{mode:"visible",children:e.children}),t.return=a,t.sibling=null,l!==null&&(u=a.deletions,u===null?(a.deletions=[l],a.flags|=16):u.push(l)),a.child=t,a.memoizedState=null,t)}function Hc(l,a){return a=Gi({mode:"visible",children:a},l.mode),a.return=l,l.child=a}function Gi(l,a){return l=oa(22,l,null,a),l.lanes=0,l}function Bc(l,a,t){return fe(a,l.child,null,t),l=Hc(a,a.pendingProps.children),l.flags|=2,a.memoizedState=null,l}function to(l,a,t){l.lanes|=a;var e=l.alternate;e!==null&&(e.lanes|=a),Fu(l.return,a,t)}function Rc(l,a,t,e,n,i){var u=l.memoizedState;u===null?l.memoizedState={isBackwards:a,rendering:null,renderingStartTime:0,last:e,tail:t,tailMode:n,treeForkCount:i}:(u.isBackwards=a,u.rendering=null,u.renderingStartTime=0,u.last=e,u.tail=t,u.tailMode=n,u.treeForkCount=i)}function eo(l,a,t){var e=a.pendingProps,n=e.revealOrder,i=e.tail;e=e.children;var u=_l.current,f=(u&2)!==0;if(f?(u=u&1|2,a.flags|=128):u&=1,V(_l,u),Vl(l,a,e,t),e=W?_n:0,!f&&l!==null&&(l.flags&128)!==0)l:for(l=a.child;l!==null;){if(l.tag===13)l.memoizedState!==null&&to(l,t,a);else if(l.tag===19)to(l,t,a);else if(l.child!==null){l.child.return=l,l=l.child;continue}if(l===a)break l;for(;l.sibling===null;){if(l.return===null||l.return===a)break l;l=l.return}l.sibling.return=l.return,l=l.sibling}switch(n){case"forwards":for(t=a.child,n=null;t!==null;)l=t.alternate,l!==null&&Oi(l)===null&&(n=t),t=t.sibling;t=n,t===null?(n=a.child,a.child=null):(n=t.sibling,t.sibling=null),Rc(a,!1,n,t,i,e);break;case"backwards":case"unstable_legacy-backwards":for(t=null,n=a.child,a.child=null;n!==null;){if(l=n.alternate,l!==null&&Oi(l)===null){a.child=n;break}l=n.sibling,n.sibling=t,t=n,n=l}Rc(a,!0,t,null,i,e);break;case"together":Rc(a,!1,null,null,void 0,e);break;default:a.memoizedState=null}return a.child}function nt(l,a,t){if(l!==null&&(a.dependencies=l.dependencies),Ut|=a.lanes,(t&a.childLanes)===0)if(l!==null){if(Qe(l,a,t,!1),(t&a.childLanes)===0)return null}else return null;if(l!==null&&a.child!==l.child)throw Error(m(153));if(a.child!==null){for(l=a.child,t=Ia(l,l.pendingProps),a.child=t,t.return=a;l.sibling!==null;)l=l.sibling,t=t.sibling=Ia(l,l.pendingProps),t.return=a;t.sibling=null}return a.child}function qc(l,a){return(l.lanes&a)!==0?!0:(l=l.dependencies,!!(l!==null&&xi(l)))}function o1(l,a,t){switch(a.tag){case 3:Za(a,a.stateNode.containerInfo),Et(a,Tl,l.memoizedState.cache),te();break;case 27:case 5:qa(a);break;case 4:Za(a,a.stateNode.containerInfo);break;case 10:Et(a,a.type,a.memoizedProps.value);break;case 31:if(a.memoizedState!==null)return a.flags|=128,sc(a),null;break;case 13:var e=a.memoizedState;if(e!==null)return e.dehydrated!==null?(Nt(a),a.flags|=128,null):(t&a.child.childLanes)!==0?ao(l,a,t):(Nt(a),l=nt(l,a,t),l!==null?l.sibling:null);Nt(a);break;case 19:var n=(l.flags&128)!==0;if(e=(t&a.childLanes)!==0,e||(Qe(l,a,t,!1),e=(t&a.childLanes)!==0),n){if(e)return eo(l,a,t);a.flags|=128}if(n=a.memoizedState,n!==null&&(n.rendering=null,n.tail=null,n.lastEffect=null),V(_l,_l.current),e)break;return null;case 22:return a.lanes=0,Wr(l,a,t,a.pendingProps);case 24:Et(a,Tl,l.memoizedState.cache)}return nt(l,a,t)}function no(l,a,t){if(l!==null)if(l.memoizedProps!==a.pendingProps)Ol=!0;else{if(!qc(l,t)&&(a.flags&128)===0)return Ol=!1,o1(l,a,t);Ol=(l.flags&131072)!==0}else Ol=!1,W&&(a.flags&1048576)!==0&&Bs(a,_n,a.index);switch(a.lanes=0,a.tag){case 16:l:{var e=a.pendingProps;if(l=ue(a.elementType),a.type=l,typeof l=="function")Xu(l)?(e=re(l,e),a.tag=1,a=Pr(null,a,l,e,t)):(a.tag=0,a=wc(null,a,l,e,t));else{if(l!=null){var n=l.$$typeof;if(n===Dl){a.tag=11,a=Lr(null,a,l,e,t);break l}else if(n===Cl){a.tag=14,a=Kr(null,a,l,e,t);break l}}throw a=Ll(l)||l,Error(m(306,a,""))}}return a;case 0:return wc(l,a,a.type,a.pendingProps,t);case 1:return e=a.type,n=re(e,a.pendingProps),Pr(l,a,e,n,t);case 3:l:{if(Za(a,a.stateNode.containerInfo),l===null)throw Error(m(387));e=a.pendingProps;var i=a.memoizedState;n=i.element,nc(l,a),wn(a,e,null,t);var u=a.memoizedState;if(e=u.cache,Et(a,Tl,e),e!==i.cache&&Iu(a,[Tl],t,!0),Dn(),e=u.element,i.isDehydrated)if(i={element:e,isDehydrated:!1,cache:u.cache},a.updateQueue.baseState=i,a.memoizedState=i,a.flags&256){a=lo(l,a,e,t);break l}else if(e!==n){n=_a(Error(m(424)),a),An(n),a=lo(l,a,e,t);break l}else for(l=a.stateNode.containerInfo,l.nodeType===9?l=l.body:l=l.nodeName==="HTML"?l.ownerDocument.body:l,ml=Oa(l.firstChild),kl=a,W=!0,_t=null,Ta=!0,t=Ws(a,null,e,t),a.child=t;t;)t.flags=t.flags&-3|4096,t=t.sibling;else{if(te(),e===n){a=nt(l,a,t);break l}Vl(l,a,e,t)}a=a.child}return a;case 26:return Yi(l,a),l===null?(t=yd(a.type,null,a.pendingProps,null))?a.memoizedState=t:W||(t=a.type,l=a.pendingProps,e=tu(ca.current).createElement(t),e[Ql]=a,e[Il]=l,Zl(e,t,l),Yl(e),a.stateNode=e):a.memoizedState=yd(a.type,l.memoizedProps,a.pendingProps,l.memoizedState),null;case 27:return qa(a),l===null&&W&&(e=a.stateNode=md(a.type,a.pendingProps,ca.current),kl=a,Ta=!0,n=ml,qt(a.type)?(bf=n,ml=Oa(e.firstChild)):ml=n),Vl(l,a,a.pendingProps.children,t),Yi(l,a),l===null&&(a.flags|=4194304),a.child;case 5:return l===null&&W&&((n=e=ml)&&(e=Q1(e,a.type,a.pendingProps,Ta),e!==null?(a.stateNode=e,kl=a,ml=Oa(e.firstChild),Ta=!1,n=!0):n=!1),n||At(a)),qa(a),n=a.type,i=a.pendingProps,u=l!==null?l.memoizedProps:null,e=i.children,mf(n,i)?e=null:u!==null&&mf(n,u)&&(a.flags|=32),a.memoizedState!==null&&(n=oc(l,a,t1,null,null,t),Fn._currentValue=n),Yi(l,a),Vl(l,a,e,t),a.child;case 6:return l===null&&W&&((l=t=ml)&&(t=k1(t,a.pendingProps,Ta),t!==null?(a.stateNode=t,kl=a,ml=null,l=!0):l=!1),l||At(a)),null;case 13:return ao(l,a,t);case 4:return Za(a,a.stateNode.containerInfo),e=a.pendingProps,l===null?a.child=fe(a,null,e,t):Vl(l,a,e,t),a.child;case 11:return Lr(l,a,a.type,a.pendingProps,t);case 7:return Vl(l,a,a.pendingProps,t),a.child;case 8:return Vl(l,a,a.pendingProps.children,t),a.child;case 12:return Vl(l,a,a.pendingProps.children,t),a.child;case 10:return e=a.pendingProps,Et(a,a.type,e.value),Vl(l,a,e.children,t),a.child;case 9:return n=a.type._context,e=a.pendingProps.children,ne(a),n=Xl(n),e=e(n),a.flags|=1,Vl(l,a,e,t),a.child;case 14:return Kr(l,a,a.type,a.pendingProps,t);case 15:return Jr(l,a,a.type,a.pendingProps,t);case 19:return eo(l,a,t);case 31:return r1(l,a,t);case 22:return Wr(l,a,t,a.pendingProps);case 24:return ne(a),e=Xl(Tl),l===null?(n=ac(),n===null&&(n=fl,i=Pu(),n.pooledCache=i,i.refCount++,i!==null&&(n.pooledCacheLanes|=t),n=i),a.memoizedState={parent:e,cache:n},ec(a),Et(a,Tl,n)):((l.lanes&t)!==0&&(nc(l,a),wn(a,null,null,t),Dn()),n=l.memoizedState,i=a.memoizedState,n.parent!==e?(n={parent:e,cache:e},a.memoizedState=n,a.lanes===0&&(a.memoizedState=a.updateQueue.baseState=n),Et(a,Tl,e)):(e=i.cache,Et(a,Tl,e),e!==n.cache&&Iu(a,[Tl],t,!0))),Vl(l,a,a.pendingProps.children,t),a.child;case 29:throw a.pendingProps}throw Error(m(156,a.tag))}function it(l){l.flags|=4}function Yc(l,a,t,e,n){if((a=(l.mode&32)!==0)&&(a=!1),a){if(l.flags|=16777216,(n&335544128)===n)if(l.stateNode.complete)l.flags|=8192;else if(jo())l.flags|=8192;else throw ce=Ai,tc}else l.flags&=-16777217}function io(l,a){if(a.type!=="stylesheet"||(a.state.loading&4)!==0)l.flags&=-16777217;else if(l.flags|=16777216,!Sd(a))if(jo())l.flags|=8192;else throw ce=Ai,tc}function Qi(l,a){a!==null&&(l.flags|=4),l.flags&16384&&(a=l.tag!==22?Wt():536870912,l.lanes|=a,Pe|=a)}function Rn(l,a){if(!W)switch(l.tailMode){case"hidden":a=l.tail;for(var t=null;a!==null;)a.alternate!==null&&(t=a),a=a.sibling;t===null?l.tail=null:t.sibling=null;break;case"collapsed":t=l.tail;for(var e=null;t!==null;)t.alternate!==null&&(e=t),t=t.sibling;e===null?a||l.tail===null?l.tail=null:l.tail.sibling=null:e.sibling=null}}function gl(l){var a=l.alternate!==null&&l.alternate.child===l.child,t=0,e=0;if(a)for(var n=l.child;n!==null;)t|=n.lanes|n.childLanes,e|=n.subtreeFlags&65011712,e|=n.flags&65011712,n.return=l,n=n.sibling;else for(n=l.child;n!==null;)t|=n.lanes|n.childLanes,e|=n.subtreeFlags,e|=n.flags,n.return=l,n=n.sibling;return l.subtreeFlags|=e,l.childLanes=t,a}function d1(l,a,t){var e=a.pendingProps;switch(Ku(a),a.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return gl(a),null;case 1:return gl(a),null;case 3:return t=a.stateNode,e=null,l!==null&&(e=l.memoizedState.cache),a.memoizedState.cache!==e&&(a.flags|=2048),at(Tl),fa(),t.pendingContext&&(t.context=t.pendingContext,t.pendingContext=null),(l===null||l.child===null)&&(Ge(a)?it(a):l===null||l.memoizedState.isDehydrated&&(a.flags&256)===0||(a.flags|=1024,Wu())),gl(a),null;case 26:var n=a.type,i=a.memoizedState;return l===null?(it(a),i!==null?(gl(a),io(a,i)):(gl(a),Yc(a,n,null,e,t))):i?i!==l.memoizedState?(it(a),gl(a),io(a,i)):(gl(a),a.flags&=-16777217):(l=l.memoizedProps,l!==e&&it(a),gl(a),Yc(a,n,l,e,t)),null;case 27:if(wa(a),t=ca.current,n=a.type,l!==null&&a.stateNode!=null)l.memoizedProps!==e&&it(a);else{if(!e){if(a.stateNode===null)throw Error(m(166));return gl(a),null}l=pl.current,Ge(a)?qs(a):(l=md(n,e,t),a.stateNode=l,it(a))}return gl(a),null;case 5:if(wa(a),n=a.type,l!==null&&a.stateNode!=null)l.memoizedProps!==e&&it(a);else{if(!e){if(a.stateNode===null)throw Error(m(166));return gl(a),null}if(i=pl.current,Ge(a))qs(a);else{var u=tu(ca.current);switch(i){case 1:i=u.createElementNS("http://www.w3.org/2000/svg",n);break;case 2:i=u.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;default:switch(n){case"svg":i=u.createElementNS("http://www.w3.org/2000/svg",n);break;case"math":i=u.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;case"script":i=u.createElement("div"),i.innerHTML="<script><\/script>",i=i.removeChild(i.firstChild);break;case"select":i=typeof e.is=="string"?u.createElement("select",{is:e.is}):u.createElement("select"),e.multiple?i.multiple=!0:e.size&&(i.size=e.size);break;default:i=typeof e.is=="string"?u.createElement(n,{is:e.is}):u.createElement(n)}}i[Ql]=a,i[Il]=e;l:for(u=a.child;u!==null;){if(u.tag===5||u.tag===6)i.appendChild(u.stateNode);else if(u.tag!==4&&u.tag!==27&&u.child!==null){u.child.return=u,u=u.child;continue}if(u===a)break l;for(;u.sibling===null;){if(u.return===null||u.return===a)break l;u=u.return}u.sibling.return=u.return,u=u.sibling}a.stateNode=i;l:switch(Zl(i,n,e),n){case"button":case"input":case"select":case"textarea":e=!!e.autoFocus;break l;case"img":e=!0;break l;default:e=!1}e&&it(a)}}return gl(a),Yc(a,a.type,l===null?null:l.memoizedProps,a.pendingProps,t),null;case 6:if(l&&a.stateNode!=null)l.memoizedProps!==e&&it(a);else{if(typeof e!="string"&&a.stateNode===null)throw Error(m(166));if(l=ca.current,Ge(a)){if(l=a.stateNode,t=a.memoizedProps,e=null,n=kl,n!==null)switch(n.tag){case 27:case 5:e=n.memoizedProps}l[Ql]=a,l=!!(l.nodeValue===t||e!==null&&e.suppressHydrationWarning===!0||td(l.nodeValue,t)),l||At(a,!0)}else l=tu(l).createTextNode(e),l[Ql]=a,a.stateNode=l}return gl(a),null;case 31:if(t=a.memoizedState,l===null||l.memoizedState!==null){if(e=Ge(a),t!==null){if(l===null){if(!e)throw Error(m(318));if(l=a.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(m(557));l[Ql]=a}else te(),(a.flags&128)===0&&(a.memoizedState=null),a.flags|=4;gl(a),l=!1}else t=Wu(),l!==null&&l.memoizedState!==null&&(l.memoizedState.hydrationErrors=t),l=!0;if(!l)return a.flags&256?(ma(a),a):(ma(a),null);if((a.flags&128)!==0)throw Error(m(558))}return gl(a),null;case 13:if(e=a.memoizedState,l===null||l.memoizedState!==null&&l.memoizedState.dehydrated!==null){if(n=Ge(a),e!==null&&e.dehydrated!==null){if(l===null){if(!n)throw Error(m(318));if(n=a.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(m(317));n[Ql]=a}else te(),(a.flags&128)===0&&(a.memoizedState=null),a.flags|=4;gl(a),n=!1}else n=Wu(),l!==null&&l.memoizedState!==null&&(l.memoizedState.hydrationErrors=n),n=!0;if(!n)return a.flags&256?(ma(a),a):(ma(a),null)}return ma(a),(a.flags&128)!==0?(a.lanes=t,a):(t=e!==null,l=l!==null&&l.memoizedState!==null,t&&(e=a.child,n=null,e.alternate!==null&&e.alternate.memoizedState!==null&&e.alternate.memoizedState.cachePool!==null&&(n=e.alternate.memoizedState.cachePool.pool),i=null,e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(i=e.memoizedState.cachePool.pool),i!==n&&(e.flags|=2048)),t!==l&&t&&(a.child.flags|=8192),Qi(a,a.updateQueue),gl(a),null);case 4:return fa(),l===null&&ff(a.stateNode.containerInfo),gl(a),null;case 10:return at(a.type),gl(a),null;case 19:if(al(_l),e=a.memoizedState,e===null)return gl(a),null;if(n=(a.flags&128)!==0,i=e.rendering,i===null)if(n)Rn(e,!1);else{if(Sl!==0||l!==null&&(l.flags&128)!==0)for(l=a.child;l!==null;){if(i=Oi(l),i!==null){for(a.flags|=128,Rn(e,!1),l=i.updateQueue,a.updateQueue=l,Qi(a,l),a.subtreeFlags=0,l=t,t=a.child;t!==null;)Us(t,l),t=t.sibling;return V(_l,_l.current&1|2),W&&Pa(a,e.treeForkCount),a.child}l=l.sibling}e.tail!==null&&Rl()>Li&&(a.flags|=128,n=!0,Rn(e,!1),a.lanes=4194304)}else{if(!n)if(l=Oi(i),l!==null){if(a.flags|=128,n=!0,l=l.updateQueue,a.updateQueue=l,Qi(a,l),Rn(e,!0),e.tail===null&&e.tailMode==="hidden"&&!i.alternate&&!W)return gl(a),null}else 2*Rl()-e.renderingStartTime>Li&&t!==536870912&&(a.flags|=128,n=!0,Rn(e,!1),a.lanes=4194304);e.isBackwards?(i.sibling=a.child,a.child=i):(l=e.last,l!==null?l.sibling=i:a.child=i,e.last=i)}return e.tail!==null?(l=e.tail,e.rendering=l,e.tail=l.sibling,e.renderingStartTime=Rl(),l.sibling=null,t=_l.current,V(_l,n?t&1|2:t&1),W&&Pa(a,e.treeForkCount),l):(gl(a),null);case 22:case 23:return ma(a),fc(),e=a.memoizedState!==null,l!==null?l.memoizedState!==null!==e&&(a.flags|=8192):e&&(a.flags|=8192),e?(t&536870912)!==0&&(a.flags&128)===0&&(gl(a),a.subtreeFlags&6&&(a.flags|=8192)):gl(a),t=a.updateQueue,t!==null&&Qi(a,t.retryQueue),t=null,l!==null&&l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(t=l.memoizedState.cachePool.pool),e=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(e=a.memoizedState.cachePool.pool),e!==t&&(a.flags|=2048),l!==null&&al(ie),null;case 24:return t=null,l!==null&&(t=l.memoizedState.cache),a.memoizedState.cache!==t&&(a.flags|=2048),at(Tl),gl(a),null;case 25:return null;case 30:return null}throw Error(m(156,a.tag))}function m1(l,a){switch(Ku(a),a.tag){case 1:return l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 3:return at(Tl),fa(),l=a.flags,(l&65536)!==0&&(l&128)===0?(a.flags=l&-65537|128,a):null;case 26:case 27:case 5:return wa(a),null;case 31:if(a.memoizedState!==null){if(ma(a),a.alternate===null)throw Error(m(340));te()}return l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 13:if(ma(a),l=a.memoizedState,l!==null&&l.dehydrated!==null){if(a.alternate===null)throw Error(m(340));te()}return l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 19:return al(_l),null;case 4:return fa(),null;case 10:return at(a.type),null;case 22:case 23:return ma(a),fc(),l!==null&&al(ie),l=a.flags,l&65536?(a.flags=l&-65537|128,a):null;case 24:return at(Tl),null;case 25:return null;default:return null}}function uo(l,a){switch(Ku(a),a.tag){case 3:at(Tl),fa();break;case 26:case 27:case 5:wa(a);break;case 4:fa();break;case 31:a.memoizedState!==null&&ma(a);break;case 13:ma(a);break;case 19:al(_l);break;case 10:at(a.type);break;case 22:case 23:ma(a),fc(),l!==null&&al(ie);break;case 24:at(Tl)}}function qn(l,a){try{var t=a.updateQueue,e=t!==null?t.lastEffect:null;if(e!==null){var n=e.next;t=n;do{if((t.tag&l)===l){e=void 0;var i=t.create,u=t.inst;e=i(),u.destroy=e}t=t.next}while(t!==n)}}catch(f){nl(a,a.return,f)}}function wt(l,a,t){try{var e=a.updateQueue,n=e!==null?e.lastEffect:null;if(n!==null){var i=n.next;e=i;do{if((e.tag&l)===l){var u=e.inst,f=u.destroy;if(f!==void 0){u.destroy=void 0,n=a;var r=t,y=f;try{y()}catch(S){nl(n,r,S)}}}e=e.next}while(e!==i)}}catch(S){nl(a,a.return,S)}}function co(l){var a=l.updateQueue;if(a!==null){var t=l.stateNode;try{Fs(a,t)}catch(e){nl(l,l.return,e)}}}function fo(l,a,t){t.props=re(l.type,l.memoizedProps),t.state=l.memoizedState;try{t.componentWillUnmount()}catch(e){nl(l,a,e)}}function Yn(l,a){try{var t=l.ref;if(t!==null){switch(l.tag){case 26:case 27:case 5:var e=l.stateNode;break;case 30:e=l.stateNode;break;default:e=l.stateNode}typeof t=="function"?l.refCleanup=t(e):t.current=e}}catch(n){nl(l,a,n)}}function Xa(l,a){var t=l.ref,e=l.refCleanup;if(t!==null)if(typeof e=="function")try{e()}catch(n){nl(l,a,n)}finally{l.refCleanup=null,l=l.alternate,l!=null&&(l.refCleanup=null)}else if(typeof t=="function")try{t(null)}catch(n){nl(l,a,n)}else t.current=null}function so(l){var a=l.type,t=l.memoizedProps,e=l.stateNode;try{l:switch(a){case"button":case"input":case"select":case"textarea":t.autoFocus&&e.focus();break l;case"img":t.src?e.src=t.src:t.srcSet&&(e.srcset=t.srcSet)}}catch(n){nl(l,l.return,n)}}function Gc(l,a,t){try{var e=l.stateNode;H1(e,l.type,t,a),e[Il]=a}catch(n){nl(l,l.return,n)}}function ro(l){return l.tag===5||l.tag===3||l.tag===26||l.tag===27&&qt(l.type)||l.tag===4}function Qc(l){l:for(;;){for(;l.sibling===null;){if(l.return===null||ro(l.return))return null;l=l.return}for(l.sibling.return=l.return,l=l.sibling;l.tag!==5&&l.tag!==6&&l.tag!==18;){if(l.tag===27&&qt(l.type)||l.flags&2||l.child===null||l.tag===4)continue l;l.child.return=l,l=l.child}if(!(l.flags&2))return l.stateNode}}function kc(l,a,t){var e=l.tag;if(e===5||e===6)l=l.stateNode,a?(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t).insertBefore(l,a):(a=t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,a.appendChild(l),t=t._reactRootContainer,t!=null||a.onclick!==null||(a.onclick=$a));else if(e!==4&&(e===27&&qt(l.type)&&(t=l.stateNode,a=null),l=l.child,l!==null))for(kc(l,a,t),l=l.sibling;l!==null;)kc(l,a,t),l=l.sibling}function ki(l,a,t){var e=l.tag;if(e===5||e===6)l=l.stateNode,a?t.insertBefore(l,a):t.appendChild(l);else if(e!==4&&(e===27&&qt(l.type)&&(t=l.stateNode),l=l.child,l!==null))for(ki(l,a,t),l=l.sibling;l!==null;)ki(l,a,t),l=l.sibling}function oo(l){var a=l.stateNode,t=l.memoizedProps;try{for(var e=l.type,n=a.attributes;n.length;)a.removeAttributeNode(n[0]);Zl(a,e,t),a[Ql]=l,a[Il]=t}catch(i){nl(l,l.return,i)}}var ut=!1,Nl=!1,Xc=!1,mo=typeof WeakSet=="function"?WeakSet:Set,Gl=null;function g1(l,a){if(l=l.containerInfo,of=su,l=As(l),Bu(l)){if("selectionStart"in l)var t={start:l.selectionStart,end:l.selectionEnd};else l:{t=(t=l.ownerDocument)&&t.defaultView||window;var e=t.getSelection&&t.getSelection();if(e&&e.rangeCount!==0){t=e.anchorNode;var n=e.anchorOffset,i=e.focusNode;e=e.focusOffset;try{t.nodeType,i.nodeType}catch{t=null;break l}var u=0,f=-1,r=-1,y=0,S=0,_=l,p=null;a:for(;;){for(var v;_!==t||n!==0&&_.nodeType!==3||(f=u+n),_!==i||e!==0&&_.nodeType!==3||(r=u+e),_.nodeType===3&&(u+=_.nodeValue.length),(v=_.firstChild)!==null;)p=_,_=v;for(;;){if(_===l)break a;if(p===t&&++y===n&&(f=u),p===i&&++S===e&&(r=u),(v=_.nextSibling)!==null)break;_=p,p=_.parentNode}_=v}t=f===-1||r===-1?null:{start:f,end:r}}else t=null}t=t||{start:0,end:0}}else t=null;for(df={focusedElem:l,selectionRange:t},su=!1,Gl=a;Gl!==null;)if(a=Gl,l=a.child,(a.subtreeFlags&1028)!==0&&l!==null)l.return=a,Gl=l;else for(;Gl!==null;){switch(a=Gl,i=a.alternate,l=a.flags,a.tag){case 0:if((l&4)!==0&&(l=a.updateQueue,l=l!==null?l.events:null,l!==null))for(t=0;t<l.length;t++)n=l[t],n.ref.impl=n.nextImpl;break;case 11:case 15:break;case 1:if((l&1024)!==0&&i!==null){l=void 0,t=a,n=i.memoizedProps,i=i.memoizedState,e=t.stateNode;try{var O=re(t.type,n);l=e.getSnapshotBeforeUpdate(O,i),e.__reactInternalSnapshotBeforeUpdate=l}catch(H){nl(t,t.return,H)}}break;case 3:if((l&1024)!==0){if(l=a.stateNode.containerInfo,t=l.nodeType,t===9)hf(l);else if(t===1)switch(l.nodeName){case"HEAD":case"HTML":case"BODY":hf(l);break;default:l.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((l&1024)!==0)throw Error(m(163))}if(l=a.sibling,l!==null){l.return=a.return,Gl=l;break}Gl=a.return}}function go(l,a,t){var e=t.flags;switch(t.tag){case 0:case 11:case 15:ft(l,t),e&4&&qn(5,t);break;case 1:if(ft(l,t),e&4)if(l=t.stateNode,a===null)try{l.componentDidMount()}catch(u){nl(t,t.return,u)}else{var n=re(t.type,a.memoizedProps);a=a.memoizedState;try{l.componentDidUpdate(n,a,l.__reactInternalSnapshotBeforeUpdate)}catch(u){nl(t,t.return,u)}}e&64&&co(t),e&512&&Yn(t,t.return);break;case 3:if(ft(l,t),e&64&&(l=t.updateQueue,l!==null)){if(a=null,t.child!==null)switch(t.child.tag){case 27:case 5:a=t.child.stateNode;break;case 1:a=t.child.stateNode}try{Fs(l,a)}catch(u){nl(t,t.return,u)}}break;case 27:a===null&&e&4&&oo(t);case 26:case 5:ft(l,t),a===null&&e&4&&so(t),e&512&&Yn(t,t.return);break;case 12:ft(l,t);break;case 31:ft(l,t),e&4&&po(l,t);break;case 13:ft(l,t),e&4&&bo(l,t),e&64&&(l=t.memoizedState,l!==null&&(l=l.dehydrated,l!==null&&(t=_1.bind(null,t),X1(l,t))));break;case 22:if(e=t.memoizedState!==null||ut,!e){a=a!==null&&a.memoizedState!==null||Nl,n=ut;var i=Nl;ut=e,(Nl=a)&&!i?st(l,t,(t.subtreeFlags&8772)!==0):ft(l,t),ut=n,Nl=i}break;case 30:break;default:ft(l,t)}}function ho(l){var a=l.alternate;a!==null&&(l.alternate=null,ho(a)),l.child=null,l.deletions=null,l.sibling=null,l.tag===5&&(a=l.stateNode,a!==null&&vu(a)),l.stateNode=null,l.return=null,l.dependencies=null,l.memoizedProps=null,l.memoizedState=null,l.pendingProps=null,l.stateNode=null,l.updateQueue=null}var yl=null,la=!1;function ct(l,a,t){for(t=t.child;t!==null;)yo(l,a,t),t=t.sibling}function yo(l,a,t){if(El&&typeof El.onCommitFiberUnmount=="function")try{El.onCommitFiberUnmount(ba,t)}catch{}switch(t.tag){case 26:Nl||Xa(t,a),ct(l,a,t),t.memoizedState?t.memoizedState.count--:t.stateNode&&(t=t.stateNode,t.parentNode.removeChild(t));break;case 27:Nl||Xa(t,a);var e=yl,n=la;qt(t.type)&&(yl=t.stateNode,la=!1),ct(l,a,t),Jn(t.stateNode),yl=e,la=n;break;case 5:Nl||Xa(t,a);case 6:if(e=yl,n=la,yl=null,ct(l,a,t),yl=e,la=n,yl!==null)if(la)try{(yl.nodeType===9?yl.body:yl.nodeName==="HTML"?yl.ownerDocument.body:yl).removeChild(t.stateNode)}catch(i){nl(t,a,i)}else try{yl.removeChild(t.stateNode)}catch(i){nl(t,a,i)}break;case 18:yl!==null&&(la?(l=yl,fd(l.nodeType===9?l.body:l.nodeName==="HTML"?l.ownerDocument.body:l,t.stateNode),fn(l)):fd(yl,t.stateNode));break;case 4:e=yl,n=la,yl=t.stateNode.containerInfo,la=!0,ct(l,a,t),yl=e,la=n;break;case 0:case 11:case 14:case 15:wt(2,t,a),Nl||wt(4,t,a),ct(l,a,t);break;case 1:Nl||(Xa(t,a),e=t.stateNode,typeof e.componentWillUnmount=="function"&&fo(t,a,e)),ct(l,a,t);break;case 21:ct(l,a,t);break;case 22:Nl=(e=Nl)||t.memoizedState!==null,ct(l,a,t),Nl=e;break;default:ct(l,a,t)}}function po(l,a){if(a.memoizedState===null&&(l=a.alternate,l!==null&&(l=l.memoizedState,l!==null))){l=l.dehydrated;try{fn(l)}catch(t){nl(a,a.return,t)}}}function bo(l,a){if(a.memoizedState===null&&(l=a.alternate,l!==null&&(l=l.memoizedState,l!==null&&(l=l.dehydrated,l!==null))))try{fn(l)}catch(t){nl(a,a.return,t)}}function h1(l){switch(l.tag){case 31:case 13:case 19:var a=l.stateNode;return a===null&&(a=l.stateNode=new mo),a;case 22:return l=l.stateNode,a=l._retryCache,a===null&&(a=l._retryCache=new mo),a;default:throw Error(m(435,l.tag))}}function Xi(l,a){var t=h1(l);a.forEach(function(e){if(!t.has(e)){t.add(e);var n=A1.bind(null,l,e);e.then(n,n)}})}function aa(l,a){var t=a.deletions;if(t!==null)for(var e=0;e<t.length;e++){var n=t[e],i=l,u=a,f=u;l:for(;f!==null;){switch(f.tag){case 27:if(qt(f.type)){yl=f.stateNode,la=!1;break l}break;case 5:yl=f.stateNode,la=!1;break l;case 3:case 4:yl=f.stateNode.containerInfo,la=!0;break l}f=f.return}if(yl===null)throw Error(m(160));yo(i,u,n),yl=null,la=!1,i=n.alternate,i!==null&&(i.return=null),n.return=null}if(a.subtreeFlags&13886)for(a=a.child;a!==null;)vo(a,l),a=a.sibling}var Ba=null;function vo(l,a){var t=l.alternate,e=l.flags;switch(l.tag){case 0:case 11:case 14:case 15:aa(a,l),ta(l),e&4&&(wt(3,l,l.return),qn(3,l),wt(5,l,l.return));break;case 1:aa(a,l),ta(l),e&512&&(Nl||t===null||Xa(t,t.return)),e&64&&ut&&(l=l.updateQueue,l!==null&&(e=l.callbacks,e!==null&&(t=l.shared.hiddenCallbacks,l.shared.hiddenCallbacks=t===null?e:t.concat(e))));break;case 26:var n=Ba;if(aa(a,l),ta(l),e&512&&(Nl||t===null||Xa(t,t.return)),e&4){var i=t!==null?t.memoizedState:null;if(e=l.memoizedState,t===null)if(e===null)if(l.stateNode===null){l:{e=l.type,t=l.memoizedProps,n=n.ownerDocument||n;a:switch(e){case"title":i=n.getElementsByTagName("title")[0],(!i||i[dn]||i[Ql]||i.namespaceURI==="http://www.w3.org/2000/svg"||i.hasAttribute("itemprop"))&&(i=n.createElement(e),n.head.insertBefore(i,n.querySelector("head > title"))),Zl(i,e,t),i[Ql]=l,Yl(i),e=i;break l;case"link":var u=vd("link","href",n).get(e+(t.href||""));if(u){for(var f=0;f<u.length;f++)if(i=u[f],i.getAttribute("href")===(t.href==null||t.href===""?null:t.href)&&i.getAttribute("rel")===(t.rel==null?null:t.rel)&&i.getAttribute("title")===(t.title==null?null:t.title)&&i.getAttribute("crossorigin")===(t.crossOrigin==null?null:t.crossOrigin)){u.splice(f,1);break a}}i=n.createElement(e),Zl(i,e,t),n.head.appendChild(i);break;case"meta":if(u=vd("meta","content",n).get(e+(t.content||""))){for(f=0;f<u.length;f++)if(i=u[f],i.getAttribute("content")===(t.content==null?null:""+t.content)&&i.getAttribute("name")===(t.name==null?null:t.name)&&i.getAttribute("property")===(t.property==null?null:t.property)&&i.getAttribute("http-equiv")===(t.httpEquiv==null?null:t.httpEquiv)&&i.getAttribute("charset")===(t.charSet==null?null:t.charSet)){u.splice(f,1);break a}}i=n.createElement(e),Zl(i,e,t),n.head.appendChild(i);break;default:throw Error(m(468,e))}i[Ql]=l,Yl(i),e=i}l.stateNode=e}else xd(n,l.type,l.stateNode);else l.stateNode=bd(n,e,l.memoizedProps);else i!==e?(i===null?t.stateNode!==null&&(t=t.stateNode,t.parentNode.removeChild(t)):i.count--,e===null?xd(n,l.type,l.stateNode):bd(n,e,l.memoizedProps)):e===null&&l.stateNode!==null&&Gc(l,l.memoizedProps,t.memoizedProps)}break;case 27:aa(a,l),ta(l),e&512&&(Nl||t===null||Xa(t,t.return)),t!==null&&e&4&&Gc(l,l.memoizedProps,t.memoizedProps);break;case 5:if(aa(a,l),ta(l),e&512&&(Nl||t===null||Xa(t,t.return)),l.flags&32){n=l.stateNode;try{De(n,"")}catch(O){nl(l,l.return,O)}}e&4&&l.stateNode!=null&&(n=l.memoizedProps,Gc(l,n,t!==null?t.memoizedProps:n)),e&1024&&(Xc=!0);break;case 6:if(aa(a,l),ta(l),e&4){if(l.stateNode===null)throw Error(m(162));e=l.memoizedProps,t=l.stateNode;try{t.nodeValue=e}catch(O){nl(l,l.return,O)}}break;case 3:if(iu=null,n=Ba,Ba=eu(a.containerInfo),aa(a,l),Ba=n,ta(l),e&4&&t!==null&&t.memoizedState.isDehydrated)try{fn(a.containerInfo)}catch(O){nl(l,l.return,O)}Xc&&(Xc=!1,xo(l));break;case 4:e=Ba,Ba=eu(l.stateNode.containerInfo),aa(a,l),ta(l),Ba=e;break;case 12:aa(a,l),ta(l);break;case 31:aa(a,l),ta(l),e&4&&(e=l.updateQueue,e!==null&&(l.updateQueue=null,Xi(l,e)));break;case 13:aa(a,l),ta(l),l.child.flags&8192&&l.memoizedState!==null!=(t!==null&&t.memoizedState!==null)&&(Zi=Rl()),e&4&&(e=l.updateQueue,e!==null&&(l.updateQueue=null,Xi(l,e)));break;case 22:n=l.memoizedState!==null;var r=t!==null&&t.memoizedState!==null,y=ut,S=Nl;if(ut=y||n,Nl=S||r,aa(a,l),Nl=S,ut=y,ta(l),e&8192)l:for(a=l.stateNode,a._visibility=n?a._visibility&-2:a._visibility|1,n&&(t===null||r||ut||Nl||oe(l)),t=null,a=l;;){if(a.tag===5||a.tag===26){if(t===null){r=t=a;try{if(i=r.stateNode,n)u=i.style,typeof u.setProperty=="function"?u.setProperty("display","none","important"):u.display="none";else{f=r.stateNode;var _=r.memoizedProps.style,p=_!=null&&_.hasOwnProperty("display")?_.display:null;f.style.display=p==null||typeof p=="boolean"?"":(""+p).trim()}}catch(O){nl(r,r.return,O)}}}else if(a.tag===6){if(t===null){r=a;try{r.stateNode.nodeValue=n?"":r.memoizedProps}catch(O){nl(r,r.return,O)}}}else if(a.tag===18){if(t===null){r=a;try{var v=r.stateNode;n?sd(v,!0):sd(r.stateNode,!1)}catch(O){nl(r,r.return,O)}}}else if((a.tag!==22&&a.tag!==23||a.memoizedState===null||a===l)&&a.child!==null){a.child.return=a,a=a.child;continue}if(a===l)break l;for(;a.sibling===null;){if(a.return===null||a.return===l)break l;t===a&&(t=null),a=a.return}t===a&&(t=null),a.sibling.return=a.return,a=a.sibling}e&4&&(e=l.updateQueue,e!==null&&(t=e.retryQueue,t!==null&&(e.retryQueue=null,Xi(l,t))));break;case 19:aa(a,l),ta(l),e&4&&(e=l.updateQueue,e!==null&&(l.updateQueue=null,Xi(l,e)));break;case 30:break;case 21:break;default:aa(a,l),ta(l)}}function ta(l){var a=l.flags;if(a&2){try{for(var t,e=l.return;e!==null;){if(ro(e)){t=e;break}e=e.return}if(t==null)throw Error(m(160));switch(t.tag){case 27:var n=t.stateNode,i=Qc(l);ki(l,i,n);break;case 5:var u=t.stateNode;t.flags&32&&(De(u,""),t.flags&=-33);var f=Qc(l);ki(l,f,u);break;case 3:case 4:var r=t.stateNode.containerInfo,y=Qc(l);kc(l,y,r);break;default:throw Error(m(161))}}catch(S){nl(l,l.return,S)}l.flags&=-3}a&4096&&(l.flags&=-4097)}function xo(l){if(l.subtreeFlags&1024)for(l=l.child;l!==null;){var a=l;xo(a),a.tag===5&&a.flags&1024&&a.stateNode.reset(),l=l.sibling}}function ft(l,a){if(a.subtreeFlags&8772)for(a=a.child;a!==null;)go(l,a.alternate,a),a=a.sibling}function oe(l){for(l=l.child;l!==null;){var a=l;switch(a.tag){case 0:case 11:case 14:case 15:wt(4,a,a.return),oe(a);break;case 1:Xa(a,a.return);var t=a.stateNode;typeof t.componentWillUnmount=="function"&&fo(a,a.return,t),oe(a);break;case 27:Jn(a.stateNode);case 26:case 5:Xa(a,a.return),oe(a);break;case 22:a.memoizedState===null&&oe(a);break;case 30:oe(a);break;default:oe(a)}l=l.sibling}}function st(l,a,t){for(t=t&&(a.subtreeFlags&8772)!==0,a=a.child;a!==null;){var e=a.alternate,n=l,i=a,u=i.flags;switch(i.tag){case 0:case 11:case 15:st(n,i,t),qn(4,i);break;case 1:if(st(n,i,t),e=i,n=e.stateNode,typeof n.componentDidMount=="function")try{n.componentDidMount()}catch(y){nl(e,e.return,y)}if(e=i,n=e.updateQueue,n!==null){var f=e.stateNode;try{var r=n.shared.hiddenCallbacks;if(r!==null)for(n.shared.hiddenCallbacks=null,n=0;n<r.length;n++)$s(r[n],f)}catch(y){nl(e,e.return,y)}}t&&u&64&&co(i),Yn(i,i.return);break;case 27:oo(i);case 26:case 5:st(n,i,t),t&&e===null&&u&4&&so(i),Yn(i,i.return);break;case 12:st(n,i,t);break;case 31:st(n,i,t),t&&u&4&&po(n,i);break;case 13:st(n,i,t),t&&u&4&&bo(n,i);break;case 22:i.memoizedState===null&&st(n,i,t),Yn(i,i.return);break;case 30:break;default:st(n,i,t)}a=a.sibling}}function Vc(l,a){var t=null;l!==null&&l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(t=l.memoizedState.cachePool.pool),l=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(l=a.memoizedState.cachePool.pool),l!==t&&(l!=null&&l.refCount++,t!=null&&En(t))}function Zc(l,a){l=null,a.alternate!==null&&(l=a.alternate.memoizedState.cache),a=a.memoizedState.cache,a!==l&&(a.refCount++,l!=null&&En(l))}function Ra(l,a,t,e){if(a.subtreeFlags&10256)for(a=a.child;a!==null;)So(l,a,t,e),a=a.sibling}function So(l,a,t,e){var n=a.flags;switch(a.tag){case 0:case 11:case 15:Ra(l,a,t,e),n&2048&&qn(9,a);break;case 1:Ra(l,a,t,e);break;case 3:Ra(l,a,t,e),n&2048&&(l=null,a.alternate!==null&&(l=a.alternate.memoizedState.cache),a=a.memoizedState.cache,a!==l&&(a.refCount++,l!=null&&En(l)));break;case 12:if(n&2048){Ra(l,a,t,e),l=a.stateNode;try{var i=a.memoizedProps,u=i.id,f=i.onPostCommit;typeof f=="function"&&f(u,a.alternate===null?"mount":"update",l.passiveEffectDuration,-0)}catch(r){nl(a,a.return,r)}}else Ra(l,a,t,e);break;case 31:Ra(l,a,t,e);break;case 13:Ra(l,a,t,e);break;case 23:break;case 22:i=a.stateNode,u=a.alternate,a.memoizedState!==null?i._visibility&2?Ra(l,a,t,e):Gn(l,a):i._visibility&2?Ra(l,a,t,e):(i._visibility|=2,$e(l,a,t,e,(a.subtreeFlags&10256)!==0||!1)),n&2048&&Vc(u,a);break;case 24:Ra(l,a,t,e),n&2048&&Zc(a.alternate,a);break;default:Ra(l,a,t,e)}}function $e(l,a,t,e,n){for(n=n&&((a.subtreeFlags&10256)!==0||!1),a=a.child;a!==null;){var i=l,u=a,f=t,r=e,y=u.flags;switch(u.tag){case 0:case 11:case 15:$e(i,u,f,r,n),qn(8,u);break;case 23:break;case 22:var S=u.stateNode;u.memoizedState!==null?S._visibility&2?$e(i,u,f,r,n):Gn(i,u):(S._visibility|=2,$e(i,u,f,r,n)),n&&y&2048&&Vc(u.alternate,u);break;case 24:$e(i,u,f,r,n),n&&y&2048&&Zc(u.alternate,u);break;default:$e(i,u,f,r,n)}a=a.sibling}}function Gn(l,a){if(a.subtreeFlags&10256)for(a=a.child;a!==null;){var t=l,e=a,n=e.flags;switch(e.tag){case 22:Gn(t,e),n&2048&&Vc(e.alternate,e);break;case 24:Gn(t,e),n&2048&&Zc(e.alternate,e);break;default:Gn(t,e)}a=a.sibling}}var Qn=8192;function Fe(l,a,t){if(l.subtreeFlags&Qn)for(l=l.child;l!==null;)zo(l,a,t),l=l.sibling}function zo(l,a,t){switch(l.tag){case 26:Fe(l,a,t),l.flags&Qn&&l.memoizedState!==null&&am(t,Ba,l.memoizedState,l.memoizedProps);break;case 5:Fe(l,a,t);break;case 3:case 4:var e=Ba;Ba=eu(l.stateNode.containerInfo),Fe(l,a,t),Ba=e;break;case 22:l.memoizedState===null&&(e=l.alternate,e!==null&&e.memoizedState!==null?(e=Qn,Qn=16777216,Fe(l,a,t),Qn=e):Fe(l,a,t));break;default:Fe(l,a,t)}}function _o(l){var a=l.alternate;if(a!==null&&(l=a.child,l!==null)){a.child=null;do a=l.sibling,l.sibling=null,l=a;while(l!==null)}}function kn(l){var a=l.deletions;if((l.flags&16)!==0){if(a!==null)for(var t=0;t<a.length;t++){var e=a[t];Gl=e,Eo(e,l)}_o(l)}if(l.subtreeFlags&10256)for(l=l.child;l!==null;)Ao(l),l=l.sibling}function Ao(l){switch(l.tag){case 0:case 11:case 15:kn(l),l.flags&2048&&wt(9,l,l.return);break;case 3:kn(l);break;case 12:kn(l);break;case 22:var a=l.stateNode;l.memoizedState!==null&&a._visibility&2&&(l.return===null||l.return.tag!==13)?(a._visibility&=-3,Vi(l)):kn(l);break;default:kn(l)}}function Vi(l){var a=l.deletions;if((l.flags&16)!==0){if(a!==null)for(var t=0;t<a.length;t++){var e=a[t];Gl=e,Eo(e,l)}_o(l)}for(l=l.child;l!==null;){switch(a=l,a.tag){case 0:case 11:case 15:wt(8,a,a.return),Vi(a);break;case 22:t=a.stateNode,t._visibility&2&&(t._visibility&=-3,Vi(a));break;default:Vi(a)}l=l.sibling}}function Eo(l,a){for(;Gl!==null;){var t=Gl;switch(t.tag){case 0:case 11:case 15:wt(8,t,a);break;case 23:case 22:if(t.memoizedState!==null&&t.memoizedState.cachePool!==null){var e=t.memoizedState.cachePool.pool;e!=null&&e.refCount++}break;case 24:En(t.memoizedState.cache)}if(e=t.child,e!==null)e.return=t,Gl=e;else l:for(t=l;Gl!==null;){e=Gl;var n=e.sibling,i=e.return;if(ho(e),e===t){Gl=null;break l}if(n!==null){n.return=i,Gl=n;break l}Gl=i}}}var y1={getCacheForType:function(l){var a=Xl(Tl),t=a.data.get(l);return t===void 0&&(t=l(),a.data.set(l,t)),t},cacheSignal:function(){return Xl(Tl).controller.signal}},p1=typeof WeakMap=="function"?WeakMap:Map,ll=0,fl=null,Z=null,K=0,el=0,ga=null,jt=!1,Ie=!1,Lc=!1,rt=0,Sl=0,Ut=0,de=0,Kc=0,ha=0,Pe=0,Xn=null,ea=null,Jc=!1,Zi=0,To=0,Li=1/0,Ki=null,Ct=null,Ul=0,Ht=null,ln=null,ot=0,Wc=0,$c=null,Mo=null,Vn=0,Fc=null;function ya(){return(ll&2)!==0&&K!==0?K&-K:x.T!==null?ef():kf()}function Oo(){if(ha===0)if((K&536870912)===0||W){var l=Ua;Ua<<=1,(Ua&3932160)===0&&(Ua=262144),ha=l}else ha=536870912;return l=da.current,l!==null&&(l.flags|=32),ha}function na(l,a,t){(l===fl&&(el===2||el===9)||l.cancelPendingCommit!==null)&&(an(l,0),Bt(l,K,ha,!1)),Ga(l,t),((ll&2)===0||l!==fl)&&(l===fl&&((ll&2)===0&&(de|=t),Sl===4&&Bt(l,K,ha,!1)),Va(l))}function No(l,a,t){if((ll&6)!==0)throw Error(m(327));var e=!t&&(a&127)===0&&(a&l.expiredLanes)===0||Ya(l,a),n=e?x1(l,a):Pc(l,a,!0),i=e;do{if(n===0){Ie&&!e&&Bt(l,a,0,!1);break}else{if(t=l.current.alternate,i&&!b1(t)){n=Pc(l,a,!1),i=!1;continue}if(n===2){if(i=a,l.errorRecoveryDisabledLanes&i)var u=0;else u=l.pendingLanes&-536870913,u=u!==0?u:u&536870912?536870912:0;if(u!==0){a=u;l:{var f=l;n=Xn;var r=f.current.memoizedState.isDehydrated;if(r&&(an(f,u).flags|=256),u=Pc(f,u,!1),u!==2){if(Lc&&!r){f.errorRecoveryDisabledLanes|=i,de|=i,n=4;break l}i=ea,ea=n,i!==null&&(ea===null?ea=i:ea.push.apply(ea,i))}n=u}if(i=!1,n!==2)continue}}if(n===1){an(l,0),Bt(l,a,0,!0);break}l:{switch(e=l,i=n,i){case 0:case 1:throw Error(m(345));case 4:if((a&4194048)!==a)break;case 6:Bt(e,a,ha,!jt);break l;case 2:ea=null;break;case 3:case 5:break;default:throw Error(m(329))}if((a&62914560)===a&&(n=Zi+300-Rl(),10<n)){if(Bt(e,a,ha,!jt),Ka(e,0,!0)!==0)break l;ot=a,e.timeoutHandle=ud(Do.bind(null,e,t,ea,Ki,Jc,a,ha,de,Pe,jt,i,"Throttled",-0,0),n);break l}Do(e,t,ea,Ki,Jc,a,ha,de,Pe,jt,i,null,-0,0)}}break}while(!0);Va(l)}function Do(l,a,t,e,n,i,u,f,r,y,S,_,p,v){if(l.timeoutHandle=-1,_=a.subtreeFlags,_&8192||(_&16785408)===16785408){_={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:$a},zo(a,i,_);var O=(i&62914560)===i?Zi-Rl():(i&4194048)===i?To-Rl():0;if(O=tm(_,O),O!==null){ot=i,l.cancelPendingCommit=O(qo.bind(null,l,a,i,t,e,n,u,f,r,S,_,null,p,v)),Bt(l,i,u,!y);return}}qo(l,a,i,t,e,n,u,f,r)}function b1(l){for(var a=l;;){var t=a.tag;if((t===0||t===11||t===15)&&a.flags&16384&&(t=a.updateQueue,t!==null&&(t=t.stores,t!==null)))for(var e=0;e<t.length;e++){var n=t[e],i=n.getSnapshot;n=n.value;try{if(!ra(i(),n))return!1}catch{return!1}}if(t=a.child,a.subtreeFlags&16384&&t!==null)t.return=a,a=t;else{if(a===l)break;for(;a.sibling===null;){if(a.return===null||a.return===l)return!0;a=a.return}a.sibling.return=a.return,a=a.sibling}}return!0}function Bt(l,a,t,e){a&=~Kc,a&=~de,l.suspendedLanes|=a,l.pingedLanes&=~a,e&&(l.warmLanes|=a),e=l.expirationTimes;for(var n=a;0<n;){var i=31-ql(n),u=1<<i;e[i]=-1,n&=~u}t!==0&&Ja(l,t,a)}function Ji(){return(ll&6)===0?(Zn(0),!1):!0}function Ic(){if(Z!==null){if(el===0)var l=Z.return;else l=Z,lt=ee=null,gc(l),Ze=null,Mn=0,l=Z;for(;l!==null;)uo(l.alternate,l),l=l.return;Z=null}}function an(l,a){var t=l.timeoutHandle;t!==-1&&(l.timeoutHandle=-1,q1(t)),t=l.cancelPendingCommit,t!==null&&(l.cancelPendingCommit=null,t()),ot=0,Ic(),fl=l,Z=t=Ia(l.current,null),K=a,el=0,ga=null,jt=!1,Ie=Ya(l,a),Lc=!1,Pe=ha=Kc=de=Ut=Sl=0,ea=Xn=null,Jc=!1,(a&8)!==0&&(a|=a&32);var e=l.entangledLanes;if(e!==0)for(l=l.entanglements,e&=a;0<e;){var n=31-ql(e),i=1<<n;a|=l[n],e&=~i}return rt=a,hi(),t}function wo(l,a){G=null,x.H=Hn,a===Ve||a===_i?(a=Ls(),el=3):a===tc?(a=Ls(),el=4):el=a===Dc?8:a!==null&&typeof a=="object"&&typeof a.then=="function"?6:1,ga=a,Z===null&&(Sl=1,Ri(l,_a(a,l.current)))}function jo(){var l=da.current;return l===null?!0:(K&4194048)===K?Ma===null:(K&62914560)===K||(K&536870912)!==0?l===Ma:!1}function Uo(){var l=x.H;return x.H=Hn,l===null?Hn:l}function Co(){var l=x.A;return x.A=y1,l}function Wi(){Sl=4,jt||(K&4194048)!==K&&da.current!==null||(Ie=!0),(Ut&134217727)===0&&(de&134217727)===0||fl===null||Bt(fl,K,ha,!1)}function Pc(l,a,t){var e=ll;ll|=2;var n=Uo(),i=Co();(fl!==l||K!==a)&&(Ki=null,an(l,a)),a=!1;var u=Sl;l:do try{if(el!==0&&Z!==null){var f=Z,r=ga;switch(el){case 8:Ic(),u=6;break l;case 3:case 2:case 9:case 6:da.current===null&&(a=!0);var y=el;if(el=0,ga=null,tn(l,f,r,y),t&&Ie){u=0;break l}break;default:y=el,el=0,ga=null,tn(l,f,r,y)}}v1(),u=Sl;break}catch(S){wo(l,S)}while(!0);return a&&l.shellSuspendCounter++,lt=ee=null,ll=e,x.H=n,x.A=i,Z===null&&(fl=null,K=0,hi()),u}function v1(){for(;Z!==null;)Ho(Z)}function x1(l,a){var t=ll;ll|=2;var e=Uo(),n=Co();fl!==l||K!==a?(Ki=null,Li=Rl()+500,an(l,a)):Ie=Ya(l,a);l:do try{if(el!==0&&Z!==null){a=Z;var i=ga;a:switch(el){case 1:el=0,ga=null,tn(l,a,i,1);break;case 2:case 9:if(Vs(i)){el=0,ga=null,Bo(a);break}a=function(){el!==2&&el!==9||fl!==l||(el=7),Va(l)},i.then(a,a);break l;case 3:el=7;break l;case 4:el=5;break l;case 7:Vs(i)?(el=0,ga=null,Bo(a)):(el=0,ga=null,tn(l,a,i,7));break;case 5:var u=null;switch(Z.tag){case 26:u=Z.memoizedState;case 5:case 27:var f=Z;if(u?Sd(u):f.stateNode.complete){el=0,ga=null;var r=f.sibling;if(r!==null)Z=r;else{var y=f.return;y!==null?(Z=y,$i(y)):Z=null}break a}}el=0,ga=null,tn(l,a,i,5);break;case 6:el=0,ga=null,tn(l,a,i,6);break;case 8:Ic(),Sl=6;break l;default:throw Error(m(462))}}S1();break}catch(S){wo(l,S)}while(!0);return lt=ee=null,x.H=e,x.A=n,ll=t,Z!==null?0:(fl=null,K=0,hi(),Sl)}function S1(){for(;Z!==null&&!ge();)Ho(Z)}function Ho(l){var a=no(l.alternate,l,rt);l.memoizedProps=l.pendingProps,a===null?$i(l):Z=a}function Bo(l){var a=l,t=a.alternate;switch(a.tag){case 15:case 0:a=Ir(t,a,a.pendingProps,a.type,void 0,K);break;case 11:a=Ir(t,a,a.pendingProps,a.type.render,a.ref,K);break;case 5:gc(a);default:uo(t,a),a=Z=Us(a,rt),a=no(t,a,rt)}l.memoizedProps=l.pendingProps,a===null?$i(l):Z=a}function tn(l,a,t,e){lt=ee=null,gc(a),Ze=null,Mn=0;var n=a.return;try{if(s1(l,n,a,t,K)){Sl=1,Ri(l,_a(t,l.current)),Z=null;return}}catch(i){if(n!==null)throw Z=n,i;Sl=1,Ri(l,_a(t,l.current)),Z=null;return}a.flags&32768?(W||e===1?l=!0:Ie||(K&536870912)!==0?l=!1:(jt=l=!0,(e===2||e===9||e===3||e===6)&&(e=da.current,e!==null&&e.tag===13&&(e.flags|=16384))),Ro(a,l)):$i(a)}function $i(l){var a=l;do{if((a.flags&32768)!==0){Ro(a,jt);return}l=a.return;var t=d1(a.alternate,a,rt);if(t!==null){Z=t;return}if(a=a.sibling,a!==null){Z=a;return}Z=a=l}while(a!==null);Sl===0&&(Sl=5)}function Ro(l,a){do{var t=m1(l.alternate,l);if(t!==null){t.flags&=32767,Z=t;return}if(t=l.return,t!==null&&(t.flags|=32768,t.subtreeFlags=0,t.deletions=null),!a&&(l=l.sibling,l!==null)){Z=l;return}Z=l=t}while(l!==null);Sl=6,Z=null}function qo(l,a,t,e,n,i,u,f,r){l.cancelPendingCommit=null;do Fi();while(Ul!==0);if((ll&6)!==0)throw Error(m(327));if(a!==null){if(a===l.current)throw Error(m(177));if(i=a.lanes|a.childLanes,i|=Qu,ei(l,t,i,u,f,r),l===fl&&(Z=fl=null,K=0),ln=a,Ht=l,ot=t,Wc=i,$c=n,Mo=e,(a.subtreeFlags&10256)!==0||(a.flags&10256)!==0?(l.callbackNode=null,l.callbackPriority=0,E1(La,function(){return Xo(),null})):(l.callbackNode=null,l.callbackPriority=0),e=(a.flags&13878)!==0,(a.subtreeFlags&13878)!==0||e){e=x.T,x.T=null,n=A.p,A.p=2,u=ll,ll|=4;try{g1(l,a,t)}finally{ll=u,A.p=n,x.T=e}}Ul=1,Yo(),Go(),Qo()}}function Yo(){if(Ul===1){Ul=0;var l=Ht,a=ln,t=(a.flags&13878)!==0;if((a.subtreeFlags&13878)!==0||t){t=x.T,x.T=null;var e=A.p;A.p=2;var n=ll;ll|=4;try{vo(a,l);var i=df,u=As(l.containerInfo),f=i.focusedElem,r=i.selectionRange;if(u!==f&&f&&f.ownerDocument&&_s(f.ownerDocument.documentElement,f)){if(r!==null&&Bu(f)){var y=r.start,S=r.end;if(S===void 0&&(S=y),"selectionStart"in f)f.selectionStart=y,f.selectionEnd=Math.min(S,f.value.length);else{var _=f.ownerDocument||document,p=_&&_.defaultView||window;if(p.getSelection){var v=p.getSelection(),O=f.textContent.length,H=Math.min(r.start,O),cl=r.end===void 0?H:Math.min(r.end,O);!v.extend&&H>cl&&(u=cl,cl=H,H=u);var g=zs(f,H),o=zs(f,cl);if(g&&o&&(v.rangeCount!==1||v.anchorNode!==g.node||v.anchorOffset!==g.offset||v.focusNode!==o.node||v.focusOffset!==o.offset)){var h=_.createRange();h.setStart(g.node,g.offset),v.removeAllRanges(),H>cl?(v.addRange(h),v.extend(o.node,o.offset)):(h.setEnd(o.node,o.offset),v.addRange(h))}}}}for(_=[],v=f;v=v.parentNode;)v.nodeType===1&&_.push({element:v,left:v.scrollLeft,top:v.scrollTop});for(typeof f.focus=="function"&&f.focus(),f=0;f<_.length;f++){var z=_[f];z.element.scrollLeft=z.left,z.element.scrollTop=z.top}}su=!!of,df=of=null}finally{ll=n,A.p=e,x.T=t}}l.current=a,Ul=2}}function Go(){if(Ul===2){Ul=0;var l=Ht,a=ln,t=(a.flags&8772)!==0;if((a.subtreeFlags&8772)!==0||t){t=x.T,x.T=null;var e=A.p;A.p=2;var n=ll;ll|=4;try{go(l,a.alternate,a)}finally{ll=n,A.p=e,x.T=t}}Ul=3}}function Qo(){if(Ul===4||Ul===3){Ul=0,he();var l=Ht,a=ln,t=ot,e=Mo;(a.subtreeFlags&10256)!==0||(a.flags&10256)!==0?Ul=5:(Ul=0,ln=Ht=null,ko(l,l.pendingLanes));var n=l.pendingLanes;if(n===0&&(Ct=null),pu(t),a=a.stateNode,El&&typeof El.onCommitFiberRoot=="function")try{El.onCommitFiberRoot(ba,a,void 0,(a.current.flags&128)===128)}catch{}if(e!==null){a=x.T,n=A.p,A.p=2,x.T=null;try{for(var i=l.onRecoverableError,u=0;u<e.length;u++){var f=e[u];i(f.value,{componentStack:f.stack})}}finally{x.T=a,A.p=n}}(ot&3)!==0&&Fi(),Va(l),n=l.pendingLanes,(t&261930)!==0&&(n&42)!==0?l===Fc?Vn++:(Vn=0,Fc=l):Vn=0,Zn(0)}}function ko(l,a){(l.pooledCacheLanes&=a)===0&&(a=l.pooledCache,a!=null&&(l.pooledCache=null,En(a)))}function Fi(){return Yo(),Go(),Qo(),Xo()}function Xo(){if(Ul!==5)return!1;var l=Ht,a=Wc;Wc=0;var t=pu(ot),e=x.T,n=A.p;try{A.p=32>t?32:t,x.T=null,t=$c,$c=null;var i=Ht,u=ot;if(Ul=0,ln=Ht=null,ot=0,(ll&6)!==0)throw Error(m(331));var f=ll;if(ll|=4,Ao(i.current),So(i,i.current,u,t),ll=f,Zn(0,!1),El&&typeof El.onPostCommitFiberRoot=="function")try{El.onPostCommitFiberRoot(ba,i)}catch{}return!0}finally{A.p=n,x.T=e,ko(l,a)}}function Vo(l,a,t){a=_a(t,a),a=Nc(l.stateNode,a,2),l=Ot(l,a,2),l!==null&&(Ga(l,2),Va(l))}function nl(l,a,t){if(l.tag===3)Vo(l,l,t);else for(;a!==null;){if(a.tag===3){Vo(a,l,t);break}else if(a.tag===1){var e=a.stateNode;if(typeof a.type.getDerivedStateFromError=="function"||typeof e.componentDidCatch=="function"&&(Ct===null||!Ct.has(e))){l=_a(t,l),t=Vr(2),e=Ot(a,t,2),e!==null&&(Zr(t,e,a,l),Ga(e,2),Va(e));break}}a=a.return}}function lf(l,a,t){var e=l.pingCache;if(e===null){e=l.pingCache=new p1;var n=new Set;e.set(a,n)}else n=e.get(a),n===void 0&&(n=new Set,e.set(a,n));n.has(t)||(Lc=!0,n.add(t),l=z1.bind(null,l,a,t),a.then(l,l))}function z1(l,a,t){var e=l.pingCache;e!==null&&e.delete(a),l.pingedLanes|=l.suspendedLanes&t,l.warmLanes&=~t,fl===l&&(K&t)===t&&(Sl===4||Sl===3&&(K&62914560)===K&&300>Rl()-Zi?(ll&2)===0&&an(l,0):Kc|=t,Pe===K&&(Pe=0)),Va(l)}function Zo(l,a){a===0&&(a=Wt()),l=le(l,a),l!==null&&(Ga(l,a),Va(l))}function _1(l){var a=l.memoizedState,t=0;a!==null&&(t=a.retryLane),Zo(l,t)}function A1(l,a){var t=0;switch(l.tag){case 31:case 13:var e=l.stateNode,n=l.memoizedState;n!==null&&(t=n.retryLane);break;case 19:e=l.stateNode;break;case 22:e=l.stateNode._retryCache;break;default:throw Error(m(314))}e!==null&&e.delete(a),Zo(l,t)}function E1(l,a){return pt(l,a)}var Ii=null,en=null,af=!1,Pi=!1,tf=!1,Rt=0;function Va(l){l!==en&&l.next===null&&(en===null?Ii=en=l:en=en.next=l),Pi=!0,af||(af=!0,M1())}function Zn(l,a){if(!tf&&Pi){tf=!0;do for(var t=!1,e=Ii;e!==null;){if(l!==0){var n=e.pendingLanes;if(n===0)var i=0;else{var u=e.suspendedLanes,f=e.pingedLanes;i=(1<<31-ql(42|l)+1)-1,i&=n&~(u&~f),i=i&201326741?i&201326741|1:i?i|2:0}i!==0&&(t=!0,Wo(e,i))}else i=K,i=Ka(e,e===fl?i:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),(i&3)===0||Ya(e,i)||(t=!0,Wo(e,i));e=e.next}while(t);tf=!1}}function T1(){Lo()}function Lo(){Pi=af=!1;var l=0;Rt!==0&&R1()&&(l=Rt);for(var a=Rl(),t=null,e=Ii;e!==null;){var n=e.next,i=Ko(e,a);i===0?(e.next=null,t===null?Ii=n:t.next=n,n===null&&(en=t)):(t=e,(l!==0||(i&3)!==0)&&(Pi=!0)),e=n}Ul!==0&&Ul!==5||Zn(l),Rt!==0&&(Rt=0)}function Ko(l,a){for(var t=l.suspendedLanes,e=l.pingedLanes,n=l.expirationTimes,i=l.pendingLanes&-62914561;0<i;){var u=31-ql(i),f=1<<u,r=n[u];r===-1?((f&t)===0||(f&e)!==0)&&(n[u]=_e(f,a)):r<=a&&(l.expiredLanes|=f),i&=~f}if(a=fl,t=K,t=Ka(l,l===a?t:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),e=l.callbackNode,t===0||l===a&&(el===2||el===9)||l.cancelPendingCommit!==null)return e!==null&&e!==null&&bt(e),l.callbackNode=null,l.callbackPriority=0;if((t&3)===0||Ya(l,t)){if(a=t&-t,a===l.callbackPriority)return a;switch(e!==null&&bt(e),pu(t)){case 2:case 8:t=Kt;break;case 32:t=La;break;case 268435456:t=Jt;break;default:t=La}return e=Jo.bind(null,l),t=pt(t,e),l.callbackPriority=a,l.callbackNode=t,a}return e!==null&&e!==null&&bt(e),l.callbackPriority=2,l.callbackNode=null,2}function Jo(l,a){if(Ul!==0&&Ul!==5)return l.callbackNode=null,l.callbackPriority=0,null;var t=l.callbackNode;if(Fi()&&l.callbackNode!==t)return null;var e=K;return e=Ka(l,l===fl?e:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),e===0?null:(No(l,e,a),Ko(l,Rl()),l.callbackNode!=null&&l.callbackNode===t?Jo.bind(null,l):null)}function Wo(l,a){if(Fi())return null;No(l,a,!0)}function M1(){Y1(function(){(ll&6)!==0?pt(Lt,T1):Lo()})}function ef(){if(Rt===0){var l=ke;l===0&&(l=ja,ja<<=1,(ja&261888)===0&&(ja=256)),Rt=l}return Rt}function $o(l){return l==null||typeof l=="symbol"||typeof l=="boolean"?null:typeof l=="function"?l:ci(""+l)}function Fo(l,a){var t=a.ownerDocument.createElement("input");return t.name=a.name,t.value=a.value,l.id&&t.setAttribute("form",l.id),a.parentNode.insertBefore(t,a),l=new FormData(l),t.parentNode.removeChild(t),l}function O1(l,a,t,e,n){if(a==="submit"&&t&&t.stateNode===n){var i=$o((n[Il]||null).action),u=e.submitter;u&&(a=(a=u[Il]||null)?$o(a.formAction):u.getAttribute("formAction"),a!==null&&(i=a,u=null));var f=new oi("action","action",null,e,n);l.push({event:f,listeners:[{instance:null,listener:function(){if(e.defaultPrevented){if(Rt!==0){var r=u?Fo(n,u):new FormData(n);_c(t,{pending:!0,data:r,method:n.method,action:i},null,r)}}else typeof i=="function"&&(f.preventDefault(),r=u?Fo(n,u):new FormData(n),_c(t,{pending:!0,data:r,method:n.method,action:i},i,r))},currentTarget:n}]})}}for(var nf=0;nf<Gu.length;nf++){var uf=Gu[nf],N1=uf.toLowerCase(),D1=uf[0].toUpperCase()+uf.slice(1);Ha(N1,"on"+D1)}Ha(Ms,"onAnimationEnd"),Ha(Os,"onAnimationIteration"),Ha(Ns,"onAnimationStart"),Ha("dblclick","onDoubleClick"),Ha("focusin","onFocus"),Ha("focusout","onBlur"),Ha(L0,"onTransitionRun"),Ha(K0,"onTransitionStart"),Ha(J0,"onTransitionCancel"),Ha(Ds,"onTransitionEnd"),Oe("onMouseEnter",["mouseout","mouseover"]),Oe("onMouseLeave",["mouseout","mouseover"]),Oe("onPointerEnter",["pointerout","pointerover"]),Oe("onPointerLeave",["pointerout","pointerover"]),$t("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),$t("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),$t("onBeforeInput",["compositionend","keypress","textInput","paste"]),$t("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),$t("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),$t("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ln="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),w1=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ln));function Io(l,a){a=(a&4)!==0;for(var t=0;t<l.length;t++){var e=l[t],n=e.event;e=e.listeners;l:{var i=void 0;if(a)for(var u=e.length-1;0<=u;u--){var f=e[u],r=f.instance,y=f.currentTarget;if(f=f.listener,r!==i&&n.isPropagationStopped())break l;i=f,n.currentTarget=y;try{i(n)}catch(S){gi(S)}n.currentTarget=null,i=r}else for(u=0;u<e.length;u++){if(f=e[u],r=f.instance,y=f.currentTarget,f=f.listener,r!==i&&n.isPropagationStopped())break l;i=f,n.currentTarget=y;try{i(n)}catch(S){gi(S)}n.currentTarget=null,i=r}}}}function L(l,a){var t=a[bu];t===void 0&&(t=a[bu]=new Set);var e=l+"__bubble";t.has(e)||(Po(a,l,2,!1),t.add(e))}function cf(l,a,t){var e=0;a&&(e|=4),Po(t,l,e,a)}var lu="_reactListening"+Math.random().toString(36).slice(2);function ff(l){if(!l[lu]){l[lu]=!0,Zf.forEach(function(t){t!=="selectionchange"&&(w1.has(t)||cf(t,!1,l),cf(t,!0,l))});var a=l.nodeType===9?l:l.ownerDocument;a===null||a[lu]||(a[lu]=!0,cf("selectionchange",!1,a))}}function Po(l,a,t,e){switch(Od(a)){case 2:var n=im;break;case 8:n=um;break;default:n=_f}t=n.bind(null,a,t,l),n=void 0,!Mu||a!=="touchstart"&&a!=="touchmove"&&a!=="wheel"||(n=!0),e?n!==void 0?l.addEventListener(a,t,{capture:!0,passive:n}):l.addEventListener(a,t,!0):n!==void 0?l.addEventListener(a,t,{passive:n}):l.addEventListener(a,t,!1)}function sf(l,a,t,e,n){var i=e;if((a&1)===0&&(a&2)===0&&e!==null)l:for(;;){if(e===null)return;var u=e.tag;if(u===3||u===4){var f=e.stateNode.containerInfo;if(f===n)break;if(u===4)for(u=e.return;u!==null;){var r=u.tag;if((r===3||r===4)&&u.stateNode.containerInfo===n)return;u=u.return}for(;f!==null;){if(u=Ee(f),u===null)return;if(r=u.tag,r===5||r===6||r===26||r===27){e=i=u;continue l}f=f.parentNode}}e=e.return}es(function(){var y=i,S=Eu(t),_=[];l:{var p=ws.get(l);if(p!==void 0){var v=oi,O=l;switch(l){case"keypress":if(si(t)===0)break l;case"keydown":case"keyup":v=A0;break;case"focusin":O="focus",v=wu;break;case"focusout":O="blur",v=wu;break;case"beforeblur":case"afterblur":v=wu;break;case"click":if(t.button===2)break l;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":v=us;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":v=d0;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":v=M0;break;case Ms:case Os:case Ns:v=h0;break;case Ds:v=N0;break;case"scroll":case"scrollend":v=r0;break;case"wheel":v=w0;break;case"copy":case"cut":case"paste":v=p0;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":v=fs;break;case"toggle":case"beforetoggle":v=U0}var H=(a&4)!==0,cl=!H&&(l==="scroll"||l==="scrollend"),g=H?p!==null?p+"Capture":null:p;H=[];for(var o=y,h;o!==null;){var z=o;if(h=z.stateNode,z=z.tag,z!==5&&z!==26&&z!==27||h===null||g===null||(z=gn(o,g),z!=null&&H.push(Kn(o,z,h))),cl)break;o=o.return}0<H.length&&(p=new v(p,O,null,t,S),_.push({event:p,listeners:H}))}}if((a&7)===0){l:{if(p=l==="mouseover"||l==="pointerover",v=l==="mouseout"||l==="pointerout",p&&t!==Au&&(O=t.relatedTarget||t.fromElement)&&(Ee(O)||O[Ae]))break l;if((v||p)&&(p=S.window===S?S:(p=S.ownerDocument)?p.defaultView||p.parentWindow:window,v?(O=t.relatedTarget||t.toElement,v=y,O=O?Ee(O):null,O!==null&&(cl=B(O),H=O.tag,O!==cl||H!==5&&H!==27&&H!==6)&&(O=null)):(v=null,O=y),v!==O)){if(H=us,z="onMouseLeave",g="onMouseEnter",o="mouse",(l==="pointerout"||l==="pointerover")&&(H=fs,z="onPointerLeave",g="onPointerEnter",o="pointer"),cl=v==null?p:mn(v),h=O==null?p:mn(O),p=new H(z,o+"leave",v,t,S),p.target=cl,p.relatedTarget=h,z=null,Ee(S)===y&&(H=new H(g,o+"enter",O,t,S),H.target=h,H.relatedTarget=cl,z=H),cl=z,v&&O)a:{for(H=j1,g=v,o=O,h=0,z=g;z;z=H(z))h++;z=0;for(var U=o;U;U=H(U))z++;for(;0<h-z;)g=H(g),h--;for(;0<z-h;)o=H(o),z--;for(;h--;){if(g===o||o!==null&&g===o.alternate){H=g;break a}g=H(g),o=H(o)}H=null}else H=null;v!==null&&ld(_,p,v,H,!1),O!==null&&cl!==null&&ld(_,cl,O,H,!0)}}l:{if(p=y?mn(y):window,v=p.nodeName&&p.nodeName.toLowerCase(),v==="select"||v==="input"&&p.type==="file")var I=ys;else if(gs(p))if(ps)I=X0;else{I=Q0;var N=G0}else v=p.nodeName,!v||v.toLowerCase()!=="input"||p.type!=="checkbox"&&p.type!=="radio"?y&&_u(y.elementType)&&(I=ys):I=k0;if(I&&(I=I(l,y))){hs(_,I,t,S);break l}N&&N(l,p,y),l==="focusout"&&y&&p.type==="number"&&y.memoizedProps.value!=null&&zu(p,"number",p.value)}switch(N=y?mn(y):window,l){case"focusin":(gs(N)||N.contentEditable==="true")&&(Ce=N,Ru=y,zn=null);break;case"focusout":zn=Ru=Ce=null;break;case"mousedown":qu=!0;break;case"contextmenu":case"mouseup":case"dragend":qu=!1,Es(_,t,S);break;case"selectionchange":if(Z0)break;case"keydown":case"keyup":Es(_,t,S)}var Q;if(Uu)l:{switch(l){case"compositionstart":var J="onCompositionStart";break l;case"compositionend":J="onCompositionEnd";break l;case"compositionupdate":J="onCompositionUpdate";break l}J=void 0}else Ue?ds(l,t)&&(J="onCompositionEnd"):l==="keydown"&&t.keyCode===229&&(J="onCompositionStart");J&&(ss&&t.locale!=="ko"&&(Ue||J!=="onCompositionStart"?J==="onCompositionEnd"&&Ue&&(Q=ns()):(St=S,Ou="value"in St?St.value:St.textContent,Ue=!0)),N=au(y,J),0<N.length&&(J=new cs(J,l,null,t,S),_.push({event:J,listeners:N}),Q?J.data=Q:(Q=ms(t),Q!==null&&(J.data=Q)))),(Q=H0?B0(l,t):R0(l,t))&&(J=au(y,"onBeforeInput"),0<J.length&&(N=new cs("onBeforeInput","beforeinput",null,t,S),_.push({event:N,listeners:J}),N.data=Q)),O1(_,l,y,t,S)}Io(_,a)})}function Kn(l,a,t){return{instance:l,listener:a,currentTarget:t}}function au(l,a){for(var t=a+"Capture",e=[];l!==null;){var n=l,i=n.stateNode;if(n=n.tag,n!==5&&n!==26&&n!==27||i===null||(n=gn(l,t),n!=null&&e.unshift(Kn(l,n,i)),n=gn(l,a),n!=null&&e.push(Kn(l,n,i))),l.tag===3)return e;l=l.return}return[]}function j1(l){if(l===null)return null;do l=l.return;while(l&&l.tag!==5&&l.tag!==27);return l||null}function ld(l,a,t,e,n){for(var i=a._reactName,u=[];t!==null&&t!==e;){var f=t,r=f.alternate,y=f.stateNode;if(f=f.tag,r!==null&&r===e)break;f!==5&&f!==26&&f!==27||y===null||(r=y,n?(y=gn(t,i),y!=null&&u.unshift(Kn(t,y,r))):n||(y=gn(t,i),y!=null&&u.push(Kn(t,y,r)))),t=t.return}u.length!==0&&l.push({event:a,listeners:u})}var U1=/\r\n?/g,C1=/\u0000|\uFFFD/g;function ad(l){return(typeof l=="string"?l:""+l).replace(U1,`
`).replace(C1,"")}function td(l,a){return a=ad(a),ad(l)===a}function ul(l,a,t,e,n,i){switch(t){case"children":typeof e=="string"?a==="body"||a==="textarea"&&e===""||De(l,e):(typeof e=="number"||typeof e=="bigint")&&a!=="body"&&De(l,""+e);break;case"className":ii(l,"class",e);break;case"tabIndex":ii(l,"tabindex",e);break;case"dir":case"role":case"viewBox":case"width":case"height":ii(l,t,e);break;case"style":as(l,e,i);break;case"data":if(a!=="object"){ii(l,"data",e);break}case"src":case"href":if(e===""&&(a!=="a"||t!=="href")){l.removeAttribute(t);break}if(e==null||typeof e=="function"||typeof e=="symbol"||typeof e=="boolean"){l.removeAttribute(t);break}e=ci(""+e),l.setAttribute(t,e);break;case"action":case"formAction":if(typeof e=="function"){l.setAttribute(t,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof i=="function"&&(t==="formAction"?(a!=="input"&&ul(l,a,"name",n.name,n,null),ul(l,a,"formEncType",n.formEncType,n,null),ul(l,a,"formMethod",n.formMethod,n,null),ul(l,a,"formTarget",n.formTarget,n,null)):(ul(l,a,"encType",n.encType,n,null),ul(l,a,"method",n.method,n,null),ul(l,a,"target",n.target,n,null)));if(e==null||typeof e=="symbol"||typeof e=="boolean"){l.removeAttribute(t);break}e=ci(""+e),l.setAttribute(t,e);break;case"onClick":e!=null&&(l.onclick=$a);break;case"onScroll":e!=null&&L("scroll",l);break;case"onScrollEnd":e!=null&&L("scrollend",l);break;case"dangerouslySetInnerHTML":if(e!=null){if(typeof e!="object"||!("__html"in e))throw Error(m(61));if(t=e.__html,t!=null){if(n.children!=null)throw Error(m(60));l.innerHTML=t}}break;case"multiple":l.multiple=e&&typeof e!="function"&&typeof e!="symbol";break;case"muted":l.muted=e&&typeof e!="function"&&typeof e!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(e==null||typeof e=="function"||typeof e=="boolean"||typeof e=="symbol"){l.removeAttribute("xlink:href");break}t=ci(""+e),l.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",t);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":e!=null&&typeof e!="function"&&typeof e!="symbol"?l.setAttribute(t,""+e):l.removeAttribute(t);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":e&&typeof e!="function"&&typeof e!="symbol"?l.setAttribute(t,""):l.removeAttribute(t);break;case"capture":case"download":e===!0?l.setAttribute(t,""):e!==!1&&e!=null&&typeof e!="function"&&typeof e!="symbol"?l.setAttribute(t,e):l.removeAttribute(t);break;case"cols":case"rows":case"size":case"span":e!=null&&typeof e!="function"&&typeof e!="symbol"&&!isNaN(e)&&1<=e?l.setAttribute(t,e):l.removeAttribute(t);break;case"rowSpan":case"start":e==null||typeof e=="function"||typeof e=="symbol"||isNaN(e)?l.removeAttribute(t):l.setAttribute(t,e);break;case"popover":L("beforetoggle",l),L("toggle",l),ni(l,"popover",e);break;case"xlinkActuate":Wa(l,"http://www.w3.org/1999/xlink","xlink:actuate",e);break;case"xlinkArcrole":Wa(l,"http://www.w3.org/1999/xlink","xlink:arcrole",e);break;case"xlinkRole":Wa(l,"http://www.w3.org/1999/xlink","xlink:role",e);break;case"xlinkShow":Wa(l,"http://www.w3.org/1999/xlink","xlink:show",e);break;case"xlinkTitle":Wa(l,"http://www.w3.org/1999/xlink","xlink:title",e);break;case"xlinkType":Wa(l,"http://www.w3.org/1999/xlink","xlink:type",e);break;case"xmlBase":Wa(l,"http://www.w3.org/XML/1998/namespace","xml:base",e);break;case"xmlLang":Wa(l,"http://www.w3.org/XML/1998/namespace","xml:lang",e);break;case"xmlSpace":Wa(l,"http://www.w3.org/XML/1998/namespace","xml:space",e);break;case"is":ni(l,"is",e);break;case"innerText":case"textContent":break;default:(!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(t=f0.get(t)||t,ni(l,t,e))}}function rf(l,a,t,e,n,i){switch(t){case"style":as(l,e,i);break;case"dangerouslySetInnerHTML":if(e!=null){if(typeof e!="object"||!("__html"in e))throw Error(m(61));if(t=e.__html,t!=null){if(n.children!=null)throw Error(m(60));l.innerHTML=t}}break;case"children":typeof e=="string"?De(l,e):(typeof e=="number"||typeof e=="bigint")&&De(l,""+e);break;case"onScroll":e!=null&&L("scroll",l);break;case"onScrollEnd":e!=null&&L("scrollend",l);break;case"onClick":e!=null&&(l.onclick=$a);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!Lf.hasOwnProperty(t))l:{if(t[0]==="o"&&t[1]==="n"&&(n=t.endsWith("Capture"),a=t.slice(2,n?t.length-7:void 0),i=l[Il]||null,i=i!=null?i[t]:null,typeof i=="function"&&l.removeEventListener(a,i,n),typeof e=="function")){typeof i!="function"&&i!==null&&(t in l?l[t]=null:l.hasAttribute(t)&&l.removeAttribute(t)),l.addEventListener(a,e,n);break l}t in l?l[t]=e:e===!0?l.setAttribute(t,""):ni(l,t,e)}}}function Zl(l,a,t){switch(a){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":L("error",l),L("load",l);var e=!1,n=!1,i;for(i in t)if(t.hasOwnProperty(i)){var u=t[i];if(u!=null)switch(i){case"src":e=!0;break;case"srcSet":n=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(m(137,a));default:ul(l,a,i,u,t,null)}}n&&ul(l,a,"srcSet",t.srcSet,t,null),e&&ul(l,a,"src",t.src,t,null);return;case"input":L("invalid",l);var f=i=u=n=null,r=null,y=null;for(e in t)if(t.hasOwnProperty(e)){var S=t[e];if(S!=null)switch(e){case"name":n=S;break;case"type":u=S;break;case"checked":r=S;break;case"defaultChecked":y=S;break;case"value":i=S;break;case"defaultValue":f=S;break;case"children":case"dangerouslySetInnerHTML":if(S!=null)throw Error(m(137,a));break;default:ul(l,a,e,S,t,null)}}Ff(l,i,f,r,y,u,n,!1);return;case"select":L("invalid",l),e=u=i=null;for(n in t)if(t.hasOwnProperty(n)&&(f=t[n],f!=null))switch(n){case"value":i=f;break;case"defaultValue":u=f;break;case"multiple":e=f;default:ul(l,a,n,f,t,null)}a=i,t=u,l.multiple=!!e,a!=null?Ne(l,!!e,a,!1):t!=null&&Ne(l,!!e,t,!0);return;case"textarea":L("invalid",l),i=n=e=null;for(u in t)if(t.hasOwnProperty(u)&&(f=t[u],f!=null))switch(u){case"value":e=f;break;case"defaultValue":n=f;break;case"children":i=f;break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(m(91));break;default:ul(l,a,u,f,t,null)}Pf(l,e,n,i);return;case"option":for(r in t)t.hasOwnProperty(r)&&(e=t[r],e!=null)&&(r==="selected"?l.selected=e&&typeof e!="function"&&typeof e!="symbol":ul(l,a,r,e,t,null));return;case"dialog":L("beforetoggle",l),L("toggle",l),L("cancel",l),L("close",l);break;case"iframe":case"object":L("load",l);break;case"video":case"audio":for(e=0;e<Ln.length;e++)L(Ln[e],l);break;case"image":L("error",l),L("load",l);break;case"details":L("toggle",l);break;case"embed":case"source":case"link":L("error",l),L("load",l);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(y in t)if(t.hasOwnProperty(y)&&(e=t[y],e!=null))switch(y){case"children":case"dangerouslySetInnerHTML":throw Error(m(137,a));default:ul(l,a,y,e,t,null)}return;default:if(_u(a)){for(S in t)t.hasOwnProperty(S)&&(e=t[S],e!==void 0&&rf(l,a,S,e,t,void 0));return}}for(f in t)t.hasOwnProperty(f)&&(e=t[f],e!=null&&ul(l,a,f,e,t,null))}function H1(l,a,t,e){switch(a){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var n=null,i=null,u=null,f=null,r=null,y=null,S=null;for(v in t){var _=t[v];if(t.hasOwnProperty(v)&&_!=null)switch(v){case"checked":break;case"value":break;case"defaultValue":r=_;default:e.hasOwnProperty(v)||ul(l,a,v,null,e,_)}}for(var p in e){var v=e[p];if(_=t[p],e.hasOwnProperty(p)&&(v!=null||_!=null))switch(p){case"type":i=v;break;case"name":n=v;break;case"checked":y=v;break;case"defaultChecked":S=v;break;case"value":u=v;break;case"defaultValue":f=v;break;case"children":case"dangerouslySetInnerHTML":if(v!=null)throw Error(m(137,a));break;default:v!==_&&ul(l,a,p,v,e,_)}}Su(l,u,f,r,y,S,i,n);return;case"select":v=u=f=p=null;for(i in t)if(r=t[i],t.hasOwnProperty(i)&&r!=null)switch(i){case"value":break;case"multiple":v=r;default:e.hasOwnProperty(i)||ul(l,a,i,null,e,r)}for(n in e)if(i=e[n],r=t[n],e.hasOwnProperty(n)&&(i!=null||r!=null))switch(n){case"value":p=i;break;case"defaultValue":f=i;break;case"multiple":u=i;default:i!==r&&ul(l,a,n,i,e,r)}a=f,t=u,e=v,p!=null?Ne(l,!!t,p,!1):!!e!=!!t&&(a!=null?Ne(l,!!t,a,!0):Ne(l,!!t,t?[]:"",!1));return;case"textarea":v=p=null;for(f in t)if(n=t[f],t.hasOwnProperty(f)&&n!=null&&!e.hasOwnProperty(f))switch(f){case"value":break;case"children":break;default:ul(l,a,f,null,e,n)}for(u in e)if(n=e[u],i=t[u],e.hasOwnProperty(u)&&(n!=null||i!=null))switch(u){case"value":p=n;break;case"defaultValue":v=n;break;case"children":break;case"dangerouslySetInnerHTML":if(n!=null)throw Error(m(91));break;default:n!==i&&ul(l,a,u,n,e,i)}If(l,p,v);return;case"option":for(var O in t)p=t[O],t.hasOwnProperty(O)&&p!=null&&!e.hasOwnProperty(O)&&(O==="selected"?l.selected=!1:ul(l,a,O,null,e,p));for(r in e)p=e[r],v=t[r],e.hasOwnProperty(r)&&p!==v&&(p!=null||v!=null)&&(r==="selected"?l.selected=p&&typeof p!="function"&&typeof p!="symbol":ul(l,a,r,p,e,v));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var H in t)p=t[H],t.hasOwnProperty(H)&&p!=null&&!e.hasOwnProperty(H)&&ul(l,a,H,null,e,p);for(y in e)if(p=e[y],v=t[y],e.hasOwnProperty(y)&&p!==v&&(p!=null||v!=null))switch(y){case"children":case"dangerouslySetInnerHTML":if(p!=null)throw Error(m(137,a));break;default:ul(l,a,y,p,e,v)}return;default:if(_u(a)){for(var cl in t)p=t[cl],t.hasOwnProperty(cl)&&p!==void 0&&!e.hasOwnProperty(cl)&&rf(l,a,cl,void 0,e,p);for(S in e)p=e[S],v=t[S],!e.hasOwnProperty(S)||p===v||p===void 0&&v===void 0||rf(l,a,S,p,e,v);return}}for(var g in t)p=t[g],t.hasOwnProperty(g)&&p!=null&&!e.hasOwnProperty(g)&&ul(l,a,g,null,e,p);for(_ in e)p=e[_],v=t[_],!e.hasOwnProperty(_)||p===v||p==null&&v==null||ul(l,a,_,p,e,v)}function ed(l){switch(l){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function B1(){if(typeof performance.getEntriesByType=="function"){for(var l=0,a=0,t=performance.getEntriesByType("resource"),e=0;e<t.length;e++){var n=t[e],i=n.transferSize,u=n.initiatorType,f=n.duration;if(i&&f&&ed(u)){for(u=0,f=n.responseEnd,e+=1;e<t.length;e++){var r=t[e],y=r.startTime;if(y>f)break;var S=r.transferSize,_=r.initiatorType;S&&ed(_)&&(r=r.responseEnd,u+=S*(r<f?1:(f-y)/(r-y)))}if(--e,a+=8*(i+u)/(n.duration/1e3),l++,10<l)break}}if(0<l)return a/l/1e6}return navigator.connection&&(l=navigator.connection.downlink,typeof l=="number")?l:5}var of=null,df=null;function tu(l){return l.nodeType===9?l:l.ownerDocument}function nd(l){switch(l){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function id(l,a){if(l===0)switch(a){case"svg":return 1;case"math":return 2;default:return 0}return l===1&&a==="foreignObject"?0:l}function mf(l,a){return l==="textarea"||l==="noscript"||typeof a.children=="string"||typeof a.children=="number"||typeof a.children=="bigint"||typeof a.dangerouslySetInnerHTML=="object"&&a.dangerouslySetInnerHTML!==null&&a.dangerouslySetInnerHTML.__html!=null}var gf=null;function R1(){var l=window.event;return l&&l.type==="popstate"?l===gf?!1:(gf=l,!0):(gf=null,!1)}var ud=typeof setTimeout=="function"?setTimeout:void 0,q1=typeof clearTimeout=="function"?clearTimeout:void 0,cd=typeof Promise=="function"?Promise:void 0,Y1=typeof queueMicrotask=="function"?queueMicrotask:typeof cd<"u"?function(l){return cd.resolve(null).then(l).catch(G1)}:ud;function G1(l){setTimeout(function(){throw l})}function qt(l){return l==="head"}function fd(l,a){var t=a,e=0;do{var n=t.nextSibling;if(l.removeChild(t),n&&n.nodeType===8)if(t=n.data,t==="/$"||t==="/&"){if(e===0){l.removeChild(n),fn(a);return}e--}else if(t==="$"||t==="$?"||t==="$~"||t==="$!"||t==="&")e++;else if(t==="html")Jn(l.ownerDocument.documentElement);else if(t==="head"){t=l.ownerDocument.head,Jn(t);for(var i=t.firstChild;i;){var u=i.nextSibling,f=i.nodeName;i[dn]||f==="SCRIPT"||f==="STYLE"||f==="LINK"&&i.rel.toLowerCase()==="stylesheet"||t.removeChild(i),i=u}}else t==="body"&&Jn(l.ownerDocument.body);t=n}while(t);fn(a)}function sd(l,a){var t=l;l=0;do{var e=t.nextSibling;if(t.nodeType===1?a?(t._stashedDisplay=t.style.display,t.style.display="none"):(t.style.display=t._stashedDisplay||"",t.getAttribute("style")===""&&t.removeAttribute("style")):t.nodeType===3&&(a?(t._stashedText=t.nodeValue,t.nodeValue=""):t.nodeValue=t._stashedText||""),e&&e.nodeType===8)if(t=e.data,t==="/$"){if(l===0)break;l--}else t!=="$"&&t!=="$?"&&t!=="$~"&&t!=="$!"||l++;t=e}while(t)}function hf(l){var a=l.firstChild;for(a&&a.nodeType===10&&(a=a.nextSibling);a;){var t=a;switch(a=a.nextSibling,t.nodeName){case"HTML":case"HEAD":case"BODY":hf(t),vu(t);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(t.rel.toLowerCase()==="stylesheet")continue}l.removeChild(t)}}function Q1(l,a,t,e){for(;l.nodeType===1;){var n=t;if(l.nodeName.toLowerCase()!==a.toLowerCase()){if(!e&&(l.nodeName!=="INPUT"||l.type!=="hidden"))break}else if(e){if(!l[dn])switch(a){case"meta":if(!l.hasAttribute("itemprop"))break;return l;case"link":if(i=l.getAttribute("rel"),i==="stylesheet"&&l.hasAttribute("data-precedence"))break;if(i!==n.rel||l.getAttribute("href")!==(n.href==null||n.href===""?null:n.href)||l.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin)||l.getAttribute("title")!==(n.title==null?null:n.title))break;return l;case"style":if(l.hasAttribute("data-precedence"))break;return l;case"script":if(i=l.getAttribute("src"),(i!==(n.src==null?null:n.src)||l.getAttribute("type")!==(n.type==null?null:n.type)||l.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin))&&i&&l.hasAttribute("async")&&!l.hasAttribute("itemprop"))break;return l;default:return l}}else if(a==="input"&&l.type==="hidden"){var i=n.name==null?null:""+n.name;if(n.type==="hidden"&&l.getAttribute("name")===i)return l}else return l;if(l=Oa(l.nextSibling),l===null)break}return null}function k1(l,a,t){if(a==="")return null;for(;l.nodeType!==3;)if((l.nodeType!==1||l.nodeName!=="INPUT"||l.type!=="hidden")&&!t||(l=Oa(l.nextSibling),l===null))return null;return l}function rd(l,a){for(;l.nodeType!==8;)if((l.nodeType!==1||l.nodeName!=="INPUT"||l.type!=="hidden")&&!a||(l=Oa(l.nextSibling),l===null))return null;return l}function yf(l){return l.data==="$?"||l.data==="$~"}function pf(l){return l.data==="$!"||l.data==="$?"&&l.ownerDocument.readyState!=="loading"}function X1(l,a){var t=l.ownerDocument;if(l.data==="$~")l._reactRetry=a;else if(l.data!=="$?"||t.readyState!=="loading")a();else{var e=function(){a(),t.removeEventListener("DOMContentLoaded",e)};t.addEventListener("DOMContentLoaded",e),l._reactRetry=e}}function Oa(l){for(;l!=null;l=l.nextSibling){var a=l.nodeType;if(a===1||a===3)break;if(a===8){if(a=l.data,a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"||a==="F!"||a==="F")break;if(a==="/$"||a==="/&")return null}}return l}var bf=null;function od(l){l=l.nextSibling;for(var a=0;l;){if(l.nodeType===8){var t=l.data;if(t==="/$"||t==="/&"){if(a===0)return Oa(l.nextSibling);a--}else t!=="$"&&t!=="$!"&&t!=="$?"&&t!=="$~"&&t!=="&"||a++}l=l.nextSibling}return null}function dd(l){l=l.previousSibling;for(var a=0;l;){if(l.nodeType===8){var t=l.data;if(t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"){if(a===0)return l;a--}else t!=="/$"&&t!=="/&"||a++}l=l.previousSibling}return null}function md(l,a,t){switch(a=tu(t),l){case"html":if(l=a.documentElement,!l)throw Error(m(452));return l;case"head":if(l=a.head,!l)throw Error(m(453));return l;case"body":if(l=a.body,!l)throw Error(m(454));return l;default:throw Error(m(451))}}function Jn(l){for(var a=l.attributes;a.length;)l.removeAttributeNode(a[0]);vu(l)}var Na=new Map,gd=new Set;function eu(l){return typeof l.getRootNode=="function"?l.getRootNode():l.nodeType===9?l:l.ownerDocument}var dt=A.d;A.d={f:V1,r:Z1,D:L1,C:K1,L:J1,m:W1,X:F1,S:$1,M:I1};function V1(){var l=dt.f(),a=Ji();return l||a}function Z1(l){var a=Te(l);a!==null&&a.tag===5&&a.type==="form"?Dr(a):dt.r(l)}var nn=typeof document>"u"?null:document;function hd(l,a,t){var e=nn;if(e&&typeof a=="string"&&a){var n=Sa(a);n='link[rel="'+l+'"][href="'+n+'"]',typeof t=="string"&&(n+='[crossorigin="'+t+'"]'),gd.has(n)||(gd.add(n),l={rel:l,crossOrigin:t,href:a},e.querySelector(n)===null&&(a=e.createElement("link"),Zl(a,"link",l),Yl(a),e.head.appendChild(a)))}}function L1(l){dt.D(l),hd("dns-prefetch",l,null)}function K1(l,a){dt.C(l,a),hd("preconnect",l,a)}function J1(l,a,t){dt.L(l,a,t);var e=nn;if(e&&l&&a){var n='link[rel="preload"][as="'+Sa(a)+'"]';a==="image"&&t&&t.imageSrcSet?(n+='[imagesrcset="'+Sa(t.imageSrcSet)+'"]',typeof t.imageSizes=="string"&&(n+='[imagesizes="'+Sa(t.imageSizes)+'"]')):n+='[href="'+Sa(l)+'"]';var i=n;switch(a){case"style":i=un(l);break;case"script":i=cn(l)}Na.has(i)||(l=E({rel:"preload",href:a==="image"&&t&&t.imageSrcSet?void 0:l,as:a},t),Na.set(i,l),e.querySelector(n)!==null||a==="style"&&e.querySelector(Wn(i))||a==="script"&&e.querySelector($n(i))||(a=e.createElement("link"),Zl(a,"link",l),Yl(a),e.head.appendChild(a)))}}function W1(l,a){dt.m(l,a);var t=nn;if(t&&l){var e=a&&typeof a.as=="string"?a.as:"script",n='link[rel="modulepreload"][as="'+Sa(e)+'"][href="'+Sa(l)+'"]',i=n;switch(e){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":i=cn(l)}if(!Na.has(i)&&(l=E({rel:"modulepreload",href:l},a),Na.set(i,l),t.querySelector(n)===null)){switch(e){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(t.querySelector($n(i)))return}e=t.createElement("link"),Zl(e,"link",l),Yl(e),t.head.appendChild(e)}}}function $1(l,a,t){dt.S(l,a,t);var e=nn;if(e&&l){var n=Me(e).hoistableStyles,i=un(l);a=a||"default";var u=n.get(i);if(!u){var f={loading:0,preload:null};if(u=e.querySelector(Wn(i)))f.loading=5;else{l=E({rel:"stylesheet",href:l,"data-precedence":a},t),(t=Na.get(i))&&vf(l,t);var r=u=e.createElement("link");Yl(r),Zl(r,"link",l),r._p=new Promise(function(y,S){r.onload=y,r.onerror=S}),r.addEventListener("load",function(){f.loading|=1}),r.addEventListener("error",function(){f.loading|=2}),f.loading|=4,nu(u,a,e)}u={type:"stylesheet",instance:u,count:1,state:f},n.set(i,u)}}}function F1(l,a){dt.X(l,a);var t=nn;if(t&&l){var e=Me(t).hoistableScripts,n=cn(l),i=e.get(n);i||(i=t.querySelector($n(n)),i||(l=E({src:l,async:!0},a),(a=Na.get(n))&&xf(l,a),i=t.createElement("script"),Yl(i),Zl(i,"link",l),t.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},e.set(n,i))}}function I1(l,a){dt.M(l,a);var t=nn;if(t&&l){var e=Me(t).hoistableScripts,n=cn(l),i=e.get(n);i||(i=t.querySelector($n(n)),i||(l=E({src:l,async:!0,type:"module"},a),(a=Na.get(n))&&xf(l,a),i=t.createElement("script"),Yl(i),Zl(i,"link",l),t.head.appendChild(i)),i={type:"script",instance:i,count:1,state:null},e.set(n,i))}}function yd(l,a,t,e){var n=(n=ca.current)?eu(n):null;if(!n)throw Error(m(446));switch(l){case"meta":case"title":return null;case"style":return typeof t.precedence=="string"&&typeof t.href=="string"?(a=un(t.href),t=Me(n).hoistableStyles,e=t.get(a),e||(e={type:"style",instance:null,count:0,state:null},t.set(a,e)),e):{type:"void",instance:null,count:0,state:null};case"link":if(t.rel==="stylesheet"&&typeof t.href=="string"&&typeof t.precedence=="string"){l=un(t.href);var i=Me(n).hoistableStyles,u=i.get(l);if(u||(n=n.ownerDocument||n,u={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},i.set(l,u),(i=n.querySelector(Wn(l)))&&!i._p&&(u.instance=i,u.state.loading=5),Na.has(l)||(t={rel:"preload",as:"style",href:t.href,crossOrigin:t.crossOrigin,integrity:t.integrity,media:t.media,hrefLang:t.hrefLang,referrerPolicy:t.referrerPolicy},Na.set(l,t),i||P1(n,l,t,u.state))),a&&e===null)throw Error(m(528,""));return u}if(a&&e!==null)throw Error(m(529,""));return null;case"script":return a=t.async,t=t.src,typeof t=="string"&&a&&typeof a!="function"&&typeof a!="symbol"?(a=cn(t),t=Me(n).hoistableScripts,e=t.get(a),e||(e={type:"script",instance:null,count:0,state:null},t.set(a,e)),e):{type:"void",instance:null,count:0,state:null};default:throw Error(m(444,l))}}function un(l){return'href="'+Sa(l)+'"'}function Wn(l){return'link[rel="stylesheet"]['+l+"]"}function pd(l){return E({},l,{"data-precedence":l.precedence,precedence:null})}function P1(l,a,t,e){l.querySelector('link[rel="preload"][as="style"]['+a+"]")?e.loading=1:(a=l.createElement("link"),e.preload=a,a.addEventListener("load",function(){return e.loading|=1}),a.addEventListener("error",function(){return e.loading|=2}),Zl(a,"link",t),Yl(a),l.head.appendChild(a))}function cn(l){return'[src="'+Sa(l)+'"]'}function $n(l){return"script[async]"+l}function bd(l,a,t){if(a.count++,a.instance===null)switch(a.type){case"style":var e=l.querySelector('style[data-href~="'+Sa(t.href)+'"]');if(e)return a.instance=e,Yl(e),e;var n=E({},t,{"data-href":t.href,"data-precedence":t.precedence,href:null,precedence:null});return e=(l.ownerDocument||l).createElement("style"),Yl(e),Zl(e,"style",n),nu(e,t.precedence,l),a.instance=e;case"stylesheet":n=un(t.href);var i=l.querySelector(Wn(n));if(i)return a.state.loading|=4,a.instance=i,Yl(i),i;e=pd(t),(n=Na.get(n))&&vf(e,n),i=(l.ownerDocument||l).createElement("link"),Yl(i);var u=i;return u._p=new Promise(function(f,r){u.onload=f,u.onerror=r}),Zl(i,"link",e),a.state.loading|=4,nu(i,t.precedence,l),a.instance=i;case"script":return i=cn(t.src),(n=l.querySelector($n(i)))?(a.instance=n,Yl(n),n):(e=t,(n=Na.get(i))&&(e=E({},t),xf(e,n)),l=l.ownerDocument||l,n=l.createElement("script"),Yl(n),Zl(n,"link",e),l.head.appendChild(n),a.instance=n);case"void":return null;default:throw Error(m(443,a.type))}else a.type==="stylesheet"&&(a.state.loading&4)===0&&(e=a.instance,a.state.loading|=4,nu(e,t.precedence,l));return a.instance}function nu(l,a,t){for(var e=t.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),n=e.length?e[e.length-1]:null,i=n,u=0;u<e.length;u++){var f=e[u];if(f.dataset.precedence===a)i=f;else if(i!==n)break}i?i.parentNode.insertBefore(l,i.nextSibling):(a=t.nodeType===9?t.head:t,a.insertBefore(l,a.firstChild))}function vf(l,a){l.crossOrigin==null&&(l.crossOrigin=a.crossOrigin),l.referrerPolicy==null&&(l.referrerPolicy=a.referrerPolicy),l.title==null&&(l.title=a.title)}function xf(l,a){l.crossOrigin==null&&(l.crossOrigin=a.crossOrigin),l.referrerPolicy==null&&(l.referrerPolicy=a.referrerPolicy),l.integrity==null&&(l.integrity=a.integrity)}var iu=null;function vd(l,a,t){if(iu===null){var e=new Map,n=iu=new Map;n.set(t,e)}else n=iu,e=n.get(t),e||(e=new Map,n.set(t,e));if(e.has(l))return e;for(e.set(l,null),t=t.getElementsByTagName(l),n=0;n<t.length;n++){var i=t[n];if(!(i[dn]||i[Ql]||l==="link"&&i.getAttribute("rel")==="stylesheet")&&i.namespaceURI!=="http://www.w3.org/2000/svg"){var u=i.getAttribute(a)||"";u=l+u;var f=e.get(u);f?f.push(i):e.set(u,[i])}}return e}function xd(l,a,t){l=l.ownerDocument||l,l.head.insertBefore(t,a==="title"?l.querySelector("head > title"):null)}function lm(l,a,t){if(t===1||a.itemProp!=null)return!1;switch(l){case"meta":case"title":return!0;case"style":if(typeof a.precedence!="string"||typeof a.href!="string"||a.href==="")break;return!0;case"link":if(typeof a.rel!="string"||typeof a.href!="string"||a.href===""||a.onLoad||a.onError)break;return a.rel==="stylesheet"?(l=a.disabled,typeof a.precedence=="string"&&l==null):!0;case"script":if(a.async&&typeof a.async!="function"&&typeof a.async!="symbol"&&!a.onLoad&&!a.onError&&a.src&&typeof a.src=="string")return!0}return!1}function Sd(l){return!(l.type==="stylesheet"&&(l.state.loading&3)===0)}function am(l,a,t,e){if(t.type==="stylesheet"&&(typeof e.media!="string"||matchMedia(e.media).matches!==!1)&&(t.state.loading&4)===0){if(t.instance===null){var n=un(e.href),i=a.querySelector(Wn(n));if(i){a=i._p,a!==null&&typeof a=="object"&&typeof a.then=="function"&&(l.count++,l=uu.bind(l),a.then(l,l)),t.state.loading|=4,t.instance=i,Yl(i);return}i=a.ownerDocument||a,e=pd(e),(n=Na.get(n))&&vf(e,n),i=i.createElement("link"),Yl(i);var u=i;u._p=new Promise(function(f,r){u.onload=f,u.onerror=r}),Zl(i,"link",e),t.instance=i}l.stylesheets===null&&(l.stylesheets=new Map),l.stylesheets.set(t,a),(a=t.state.preload)&&(t.state.loading&3)===0&&(l.count++,t=uu.bind(l),a.addEventListener("load",t),a.addEventListener("error",t))}}var Sf=0;function tm(l,a){return l.stylesheets&&l.count===0&&fu(l,l.stylesheets),0<l.count||0<l.imgCount?function(t){var e=setTimeout(function(){if(l.stylesheets&&fu(l,l.stylesheets),l.unsuspend){var i=l.unsuspend;l.unsuspend=null,i()}},6e4+a);0<l.imgBytes&&Sf===0&&(Sf=62500*B1());var n=setTimeout(function(){if(l.waitingForImages=!1,l.count===0&&(l.stylesheets&&fu(l,l.stylesheets),l.unsuspend)){var i=l.unsuspend;l.unsuspend=null,i()}},(l.imgBytes>Sf?50:800)+a);return l.unsuspend=t,function(){l.unsuspend=null,clearTimeout(e),clearTimeout(n)}}:null}function uu(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)fu(this,this.stylesheets);else if(this.unsuspend){var l=this.unsuspend;this.unsuspend=null,l()}}}var cu=null;function fu(l,a){l.stylesheets=null,l.unsuspend!==null&&(l.count++,cu=new Map,a.forEach(em,l),cu=null,uu.call(l))}function em(l,a){if(!(a.state.loading&4)){var t=cu.get(l);if(t)var e=t.get(null);else{t=new Map,cu.set(l,t);for(var n=l.querySelectorAll("link[data-precedence],style[data-precedence]"),i=0;i<n.length;i++){var u=n[i];(u.nodeName==="LINK"||u.getAttribute("media")!=="not all")&&(t.set(u.dataset.precedence,u),e=u)}e&&t.set(null,e)}n=a.instance,u=n.getAttribute("data-precedence"),i=t.get(u)||e,i===e&&t.set(null,n),t.set(u,n),this.count++,e=uu.bind(this),n.addEventListener("load",e),n.addEventListener("error",e),i?i.parentNode.insertBefore(n,i.nextSibling):(l=l.nodeType===9?l.head:l,l.insertBefore(n,l.firstChild)),a.state.loading|=4}}var Fn={$$typeof:sl,Provider:null,Consumer:null,_currentValue:j,_currentValue2:j,_threadCount:0};function nm(l,a,t,e,n,i,u,f,r){this.tag=1,this.containerInfo=l,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=vt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=vt(0),this.hiddenUpdates=vt(null),this.identifierPrefix=e,this.onUncaughtError=n,this.onCaughtError=i,this.onRecoverableError=u,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=r,this.incompleteTransitions=new Map}function zd(l,a,t,e,n,i,u,f,r,y,S,_){return l=new nm(l,a,t,u,r,y,S,_,f),a=1,i===!0&&(a|=24),i=oa(3,null,null,a),l.current=i,i.stateNode=l,a=Pu(),a.refCount++,l.pooledCache=a,a.refCount++,i.memoizedState={element:e,isDehydrated:t,cache:a},ec(i),l}function _d(l){return l?(l=Re,l):Re}function Ad(l,a,t,e,n,i){n=_d(n),e.context===null?e.context=n:e.pendingContext=n,e=Mt(a),e.payload={element:t},i=i===void 0?null:i,i!==null&&(e.callback=i),t=Ot(l,e,a),t!==null&&(na(t,l,a),Nn(t,l,a))}function Ed(l,a){if(l=l.memoizedState,l!==null&&l.dehydrated!==null){var t=l.retryLane;l.retryLane=t!==0&&t<a?t:a}}function zf(l,a){Ed(l,a),(l=l.alternate)&&Ed(l,a)}function Td(l){if(l.tag===13||l.tag===31){var a=le(l,67108864);a!==null&&na(a,l,67108864),zf(l,67108864)}}function Md(l){if(l.tag===13||l.tag===31){var a=ya();a=yu(a);var t=le(l,a);t!==null&&na(t,l,a),zf(l,a)}}var su=!0;function im(l,a,t,e){var n=x.T;x.T=null;var i=A.p;try{A.p=2,_f(l,a,t,e)}finally{A.p=i,x.T=n}}function um(l,a,t,e){var n=x.T;x.T=null;var i=A.p;try{A.p=8,_f(l,a,t,e)}finally{A.p=i,x.T=n}}function _f(l,a,t,e){if(su){var n=Af(e);if(n===null)sf(l,a,e,ru,t),Nd(l,e);else if(fm(n,l,a,t,e))e.stopPropagation();else if(Nd(l,e),a&4&&-1<cm.indexOf(l)){for(;n!==null;){var i=Te(n);if(i!==null)switch(i.tag){case 3:if(i=i.stateNode,i.current.memoizedState.isDehydrated){var u=va(i.pendingLanes);if(u!==0){var f=i;for(f.pendingLanes|=2,f.entangledLanes|=2;u;){var r=1<<31-ql(u);f.entanglements[1]|=r,u&=~r}Va(i),(ll&6)===0&&(Li=Rl()+500,Zn(0))}}break;case 31:case 13:f=le(i,2),f!==null&&na(f,i,2),Ji(),zf(i,2)}if(i=Af(e),i===null&&sf(l,a,e,ru,t),i===n)break;n=i}n!==null&&e.stopPropagation()}else sf(l,a,e,null,t)}}function Af(l){return l=Eu(l),Ef(l)}var ru=null;function Ef(l){if(ru=null,l=Ee(l),l!==null){var a=B(l);if(a===null)l=null;else{var t=a.tag;if(t===13){if(l=Y(a),l!==null)return l;l=null}else if(t===31){if(l=R(a),l!==null)return l;l=null}else if(t===3){if(a.stateNode.current.memoizedState.isDehydrated)return a.tag===3?a.stateNode.containerInfo:null;l=null}else a!==l&&(l=null)}}return ru=l,null}function Od(l){switch(l){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(ye()){case Lt:return 2;case Kt:return 8;case La:case pe:return 32;case Jt:return 268435456;default:return 32}default:return 32}}var Tf=!1,Yt=null,Gt=null,Qt=null,In=new Map,Pn=new Map,kt=[],cm="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Nd(l,a){switch(l){case"focusin":case"focusout":Yt=null;break;case"dragenter":case"dragleave":Gt=null;break;case"mouseover":case"mouseout":Qt=null;break;case"pointerover":case"pointerout":In.delete(a.pointerId);break;case"gotpointercapture":case"lostpointercapture":Pn.delete(a.pointerId)}}function li(l,a,t,e,n,i){return l===null||l.nativeEvent!==i?(l={blockedOn:a,domEventName:t,eventSystemFlags:e,nativeEvent:i,targetContainers:[n]},a!==null&&(a=Te(a),a!==null&&Td(a)),l):(l.eventSystemFlags|=e,a=l.targetContainers,n!==null&&a.indexOf(n)===-1&&a.push(n),l)}function fm(l,a,t,e,n){switch(a){case"focusin":return Yt=li(Yt,l,a,t,e,n),!0;case"dragenter":return Gt=li(Gt,l,a,t,e,n),!0;case"mouseover":return Qt=li(Qt,l,a,t,e,n),!0;case"pointerover":var i=n.pointerId;return In.set(i,li(In.get(i)||null,l,a,t,e,n)),!0;case"gotpointercapture":return i=n.pointerId,Pn.set(i,li(Pn.get(i)||null,l,a,t,e,n)),!0}return!1}function Dd(l){var a=Ee(l.target);if(a!==null){var t=B(a);if(t!==null){if(a=t.tag,a===13){if(a=Y(t),a!==null){l.blockedOn=a,Xf(l.priority,function(){Md(t)});return}}else if(a===31){if(a=R(t),a!==null){l.blockedOn=a,Xf(l.priority,function(){Md(t)});return}}else if(a===3&&t.stateNode.current.memoizedState.isDehydrated){l.blockedOn=t.tag===3?t.stateNode.containerInfo:null;return}}}l.blockedOn=null}function ou(l){if(l.blockedOn!==null)return!1;for(var a=l.targetContainers;0<a.length;){var t=Af(l.nativeEvent);if(t===null){t=l.nativeEvent;var e=new t.constructor(t.type,t);Au=e,t.target.dispatchEvent(e),Au=null}else return a=Te(t),a!==null&&Td(a),l.blockedOn=t,!1;a.shift()}return!0}function wd(l,a,t){ou(l)&&t.delete(a)}function sm(){Tf=!1,Yt!==null&&ou(Yt)&&(Yt=null),Gt!==null&&ou(Gt)&&(Gt=null),Qt!==null&&ou(Qt)&&(Qt=null),In.forEach(wd),Pn.forEach(wd)}function du(l,a){l.blockedOn===a&&(l.blockedOn=null,Tf||(Tf=!0,s.unstable_scheduleCallback(s.unstable_NormalPriority,sm)))}var mu=null;function jd(l){mu!==l&&(mu=l,s.unstable_scheduleCallback(s.unstable_NormalPriority,function(){mu===l&&(mu=null);for(var a=0;a<l.length;a+=3){var t=l[a],e=l[a+1],n=l[a+2];if(typeof e!="function"){if(Ef(e||t)===null)continue;break}var i=Te(t);i!==null&&(l.splice(a,3),a-=3,_c(i,{pending:!0,data:n,method:t.method,action:e},e,n))}}))}function fn(l){function a(r){return du(r,l)}Yt!==null&&du(Yt,l),Gt!==null&&du(Gt,l),Qt!==null&&du(Qt,l),In.forEach(a),Pn.forEach(a);for(var t=0;t<kt.length;t++){var e=kt[t];e.blockedOn===l&&(e.blockedOn=null)}for(;0<kt.length&&(t=kt[0],t.blockedOn===null);)Dd(t),t.blockedOn===null&&kt.shift();if(t=(l.ownerDocument||l).$$reactFormReplay,t!=null)for(e=0;e<t.length;e+=3){var n=t[e],i=t[e+1],u=n[Il]||null;if(typeof i=="function")u||jd(t);else if(u){var f=null;if(i&&i.hasAttribute("formAction")){if(n=i,u=i[Il]||null)f=u.formAction;else if(Ef(n)!==null)continue}else f=u.action;typeof f=="function"?t[e+1]=f:(t.splice(e,3),e-=3),jd(t)}}}function Ud(){function l(i){i.canIntercept&&i.info==="react-transition"&&i.intercept({handler:function(){return new Promise(function(u){return n=u})},focusReset:"manual",scroll:"manual"})}function a(){n!==null&&(n(),n=null),e||setTimeout(t,20)}function t(){if(!e&&!navigation.transition){var i=navigation.currentEntry;i&&i.url!=null&&navigation.navigate(i.url,{state:i.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var e=!1,n=null;return navigation.addEventListener("navigate",l),navigation.addEventListener("navigatesuccess",a),navigation.addEventListener("navigateerror",a),setTimeout(t,100),function(){e=!0,navigation.removeEventListener("navigate",l),navigation.removeEventListener("navigatesuccess",a),navigation.removeEventListener("navigateerror",a),n!==null&&(n(),n=null)}}}function Mf(l){this._internalRoot=l}gu.prototype.render=Mf.prototype.render=function(l){var a=this._internalRoot;if(a===null)throw Error(m(409));var t=a.current,e=ya();Ad(t,e,l,a,null,null)},gu.prototype.unmount=Mf.prototype.unmount=function(){var l=this._internalRoot;if(l!==null){this._internalRoot=null;var a=l.containerInfo;Ad(l.current,2,null,l,null,null),Ji(),a[Ae]=null}};function gu(l){this._internalRoot=l}gu.prototype.unstable_scheduleHydration=function(l){if(l){var a=kf();l={blockedOn:null,target:l,priority:a};for(var t=0;t<kt.length&&a!==0&&a<kt[t].priority;t++);kt.splice(t,0,l),t===0&&Dd(l)}};var Cd=c.version;if(Cd!=="19.2.5")throw Error(m(527,Cd,"19.2.5"));A.findDOMNode=function(l){var a=l._reactInternals;if(a===void 0)throw typeof l.render=="function"?Error(m(188)):(l=Object.keys(l).join(","),Error(m(268,l)));return l=b(a),l=l!==null?w(l):null,l=l===null?null:l.stateNode,l};var rm={bundleType:0,version:"19.2.5",rendererPackageName:"react-dom",currentDispatcherRef:x,reconcilerVersion:"19.2.5"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var hu=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!hu.isDisabled&&hu.supportsFiber)try{ba=hu.inject(rm),El=hu}catch{}}return ai.createRoot=function(l,a){if(!D(l))throw Error(m(299));var t=!1,e="",n=Gr,i=Qr,u=kr;return a!=null&&(a.unstable_strictMode===!0&&(t=!0),a.identifierPrefix!==void 0&&(e=a.identifierPrefix),a.onUncaughtError!==void 0&&(n=a.onUncaughtError),a.onCaughtError!==void 0&&(i=a.onCaughtError),a.onRecoverableError!==void 0&&(u=a.onRecoverableError)),a=zd(l,1,!1,null,null,t,e,null,n,i,u,Ud),l[Ae]=a.current,ff(l),new Mf(a)},ai.hydrateRoot=function(l,a,t){if(!D(l))throw Error(m(299));var e=!1,n="",i=Gr,u=Qr,f=kr,r=null;return t!=null&&(t.unstable_strictMode===!0&&(e=!0),t.identifierPrefix!==void 0&&(n=t.identifierPrefix),t.onUncaughtError!==void 0&&(i=t.onUncaughtError),t.onCaughtError!==void 0&&(u=t.onCaughtError),t.onRecoverableError!==void 0&&(f=t.onRecoverableError),t.formState!==void 0&&(r=t.formState)),a=zd(l,1,!0,a,t??null,e,n,r,i,u,f,Ud),a.context=_d(null),t=a.current,e=ya(),e=yu(e),n=Mt(e),n.callback=null,Ot(t,n,e),t=e,a.current.lanes=t,Ga(a,t),Va(a),l[Ae]=a.current,ff(l),new gu(a)},ai.version="19.2.5",ai}var Gd;function vm(){if(Gd)return Of.exports;Gd=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(c){console.error(c)}}return s(),Of.exports=bm(),Of.exports}var xm=vm();const Sm="modulepreload",zm=function(s){return"/"+s},Qd={},ia=function(c,T,m){let D=Promise.resolve();if(T&&T.length>0){let Y=function(b){return Promise.all(b.map(w=>Promise.resolve(w).then(E=>({status:"fulfilled",value:E}),E=>({status:"rejected",reason:E}))))};document.getElementsByTagName("link");const R=document.querySelector("meta[property=csp-nonce]"),M=R?.nonce||R?.getAttribute("nonce");D=Y(T.map(b=>{if(b=zm(b),b in Qd)return;Qd[b]=!0;const w=b.endsWith(".css"),E=w?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${b}"]${E}`))return;const C=document.createElement("link");if(C.rel=w?"stylesheet":Sm,w||(C.as="script"),C.crossOrigin="",C.href=b,M&&C.setAttribute("nonce",M),document.head.appendChild(C),w)return new Promise((tl,$)=>{C.addEventListener("load",tl),C.addEventListener("error",()=>$(new Error(`Unable to preload CSS for ${b}`)))})}))}function B(Y){const R=new Event("vite:preloadError",{cancelable:!0});if(R.payload=Y,window.dispatchEvent(R),!R.defaultPrevented)throw Y}return D.then(Y=>{for(const R of Y||[])R.status==="rejected"&&B(R.reason);return c().catch(B)})};var jf={exports:{}},Uf={};/**
 * @license React
 * react-compiler-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var kd;function _m(){if(kd)return Uf;kd=1;var s=Bf().__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;return Uf.c=function(c){return s.H.useMemoCache(c)},Uf}var Xd;function Am(){return Xd||(Xd=1,jf.exports=_m()),jf.exports}var ti=Am();/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $d=(...s)=>s.filter((c,T,m)=>!!c&&c.trim()!==""&&m.indexOf(c)===T).join(" ").trim();/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Em=s=>s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Tm=s=>s.replace(/^([A-Z])|[\s-_]+(\w)/g,(c,T,m)=>m?m.toUpperCase():T.toLowerCase());/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vd=s=>{const c=Tm(s);return c.charAt(0).toUpperCase()+c.slice(1)};/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var Cf={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mm=s=>{for(const c in s)if(c.startsWith("aria-")||c==="role"||c==="title")return!0;return!1},Om=k.createContext({}),Nm=()=>k.useContext(Om),Dm=k.forwardRef(({color:s,size:c,strokeWidth:T,absoluteStrokeWidth:m,className:D="",children:B,iconNode:Y,...R},M)=>{const{size:b=24,strokeWidth:w=2,absoluteStrokeWidth:E=!1,color:C="currentColor",className:tl=""}=Nm()??{},$=m??E?Number(T??w)*24/Number(c??b):T??w;return k.createElement("svg",{ref:M,...Cf,width:c??b??Cf.width,height:c??b??Cf.height,stroke:s??C,strokeWidth:$,className:$d("lucide",tl,D),...!B&&!Mm(R)&&{"aria-hidden":"true"},...R},[...Y.map(([F,hl])=>k.createElement(F,hl)),...Array.isArray(B)?B:[B]])});/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ua=(s,c)=>{const T=k.forwardRef(({className:m,...D},B)=>k.createElement(Dm,{ref:B,iconNode:c,className:$d(`lucide-${Em(Vd(s))}`,`lucide-${s}`,m),...D}));return T.displayName=Vd(s),T};/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wm=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],Zd=ua("arrow-right",wm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jm=[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M9 13a4.5 4.5 0 0 0 3-4",key:"10igwf"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M12 13h4",key:"1ku699"}],["path",{d:"M12 18h6a2 2 0 0 1 2 2v1",key:"105ag5"}],["path",{d:"M12 8h8",key:"1lhi5i"}],["path",{d:"M16 8V5a2 2 0 0 1 2-2",key:"u6izg6"}],["circle",{cx:"16",cy:"13",r:".5",key:"ry7gng"}],["circle",{cx:"18",cy:"3",r:".5",key:"1aiba7"}],["circle",{cx:"20",cy:"21",r:".5",key:"yhc1fs"}],["circle",{cx:"20",cy:"8",r:".5",key:"1e43v0"}]],Ld=ua("brain-circuit",jm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Um=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],Cm=ua("circle-alert",Um);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Hm=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]],Fd=ua("database",Hm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bm=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["circle",{cx:"11.5",cy:"14.5",r:"2.5",key:"1bq0ko"}],["path",{d:"M13.3 16.3 15 18",key:"2quom7"}]],Rm=ua("file-search",Bm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qm=[["path",{d:"M6 3v12",key:"qpgusn"}],["path",{d:"M18 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",key:"1d02ji"}],["path",{d:"M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",key:"chk6ph"}],["path",{d:"M15 6a9 9 0 0 0-9 9",key:"or332x"}],["path",{d:"M18 15v6",key:"9wciyi"}],["path",{d:"M21 18h-6",key:"139f0c"}]],Id=ua("git-branch-plus",qm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ym=[["circle",{cx:"18",cy:"18",r:"3",key:"1xkwt0"}],["circle",{cx:"6",cy:"6",r:"3",key:"1lh9wr"}],["path",{d:"M6 21V9a9 9 0 0 0 9 9",key:"7kw0sc"}]],Pd=ua("git-merge",Ym);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gm=[["rect",{x:"16",y:"16",width:"6",height:"6",rx:"1",key:"4q2zg0"}],["rect",{x:"2",y:"16",width:"6",height:"6",rx:"1",key:"8cvhb9"}],["rect",{x:"9",y:"2",width:"6",height:"6",rx:"1",key:"1egb70"}],["path",{d:"M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3",key:"1jsf9p"}],["path",{d:"M12 12V8",key:"2874zd"}]],Hf=ua("network",Gm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qm=[["path",{d:"M19.07 4.93A10 10 0 0 0 6.99 3.34",key:"z3du51"}],["path",{d:"M4 6h.01",key:"oypzma"}],["path",{d:"M2.29 9.62A10 10 0 1 0 21.31 8.35",key:"qzzz0"}],["path",{d:"M16.24 7.76A6 6 0 1 0 8.23 16.67",key:"1yjesh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M17.99 11.66A6 6 0 0 1 15.77 16.67",key:"1u2y91"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"m13.41 10.59 5.66-5.66",key:"mhq4k0"}]],km=ua("radar",Qm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xm=[["circle",{cx:"6",cy:"19",r:"3",key:"1kj8tv"}],["path",{d:"M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15",key:"1d8sl"}],["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}]],Vm=ua("route",Xm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zm=[["path",{d:"M12 3v18",key:"108xh3"}],["path",{d:"m19 8 3 8a5 5 0 0 1-6 0zV7",key:"zcdpyk"}],["path",{d:"M3 7h1a17 17 0 0 0 8-2 17 17 0 0 0 8 2h1",key:"1yorad"}],["path",{d:"m5 8 3 8a5 5 0 0 1-6 0zV7",key:"eua70x"}],["path",{d:"M7 21h10",key:"1b0cd5"}]],l0=ua("scale",Zm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Lm=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],Km=ua("search",Lm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jm=[["path",{d:"M14 17H5",key:"gfn3mx"}],["path",{d:"M19 7h-9",key:"6i9tg"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]],Wm=ua("settings-2",Jm);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $m=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],Kd=ua("shield-check",$m),Fm=5e3;class sn extends k.Component{settleTimer=null;constructor(c){super(c),this.state={hasError:!1,error:null,retryCount:0}}static getDerivedStateFromError(c){return{hasError:!0,error:c}}componentDidCatch(c,T){console.error("ErrorBoundary caught an error:",c,T),this.clearSettleTimer()}componentWillUnmount(){this.clearSettleTimer()}clearSettleTimer(){this.settleTimer!==null&&(clearTimeout(this.settleTimer),this.settleTimer=null)}resetErrorBoundary=()=>{this.clearSettleTimer(),this.setState(c=>({hasError:!1,error:null,retryCount:c.retryCount+1})),this.settleTimer=setTimeout(()=>{this.settleTimer=null,this.setState({retryCount:0})},Fm)};render(){if(this.state.hasError){const c=this.state.retryCount>=3;return d.jsxs("div",{className:"workspace-loading",style:{flexDirection:"column",gap:12,color:"var(--ws-red)"},children:[d.jsx(Cm,{size:32,style:{marginBottom:4,opacity:.8}}),d.jsx("div",{style:{fontWeight:500,fontSize:"15px"},children:"Something went wrong in this view."}),d.jsx("div",{style:{fontSize:"13px",opacity:.7,maxWidth:450,textAlign:"center",marginBottom:8,lineHeight:1.5},children:c?"This view continues to encounter a critical error. Please switch to another workspace or reload the page to restore functionality.":"An unexpected problem occurred while rendering this workspace. Your data is safe, but this view cannot be displayed."}),c?d.jsx("button",{className:"ws-btn ws-btn--ghost",style:{borderColor:"var(--ws-border)",color:"var(--ws-text)"},onClick:()=>window.location.reload(),children:"Reload Application"}):d.jsx("button",{className:"ws-btn ws-btn--ghost",style:{borderColor:"var(--ws-red-soft)",color:"var(--ws-red)"},onClick:this.resetErrorBoundary,children:"Try Again"})]})}return this.props.children}}function Im(s){const c=ti.c(18),{activeView:T,agentMemoryAvailable:m,onSelect:D}=s,B=T==="graph";let Y;c[0]!==D?(Y=()=>D("graph"),c[0]=D,c[1]=Y):Y=c[1];let R;c[2]!==B||c[3]!==Y?(R=d.jsx("button",{className:"workspace-tab","data-active":B,onClick:Y,children:"Semantica Explorer"}),c[2]=B,c[3]=Y,c[4]=R):R=c[4];let M;c[5]!==T||c[6]!==m||c[7]!==D?(M=m?d.jsx("button",{className:"workspace-tab","data-active":T==="memories",onClick:()=>D("memories"),children:"Memories"}):null,c[5]=T,c[6]=m,c[7]=D,c[8]=M):M=c[8];const b=T==="vocabulary";let w;c[9]!==D?(w=()=>D("vocabulary"),c[9]=D,c[10]=w):w=c[10];let E;c[11]!==b||c[12]!==w?(E=d.jsx("button",{className:"workspace-tab","data-active":b,onClick:w,children:"Vocabulary Browser"}),c[11]=b,c[12]=w,c[13]=E):E=c[13];let C;return c[14]!==R||c[15]!==M||c[16]!==E?(C=d.jsxs(d.Fragment,{children:[R,M,E]}),c[14]=R,c[15]=M,c[16]=E,c[17]=C):C=c[17],C}async function Pm(s=fetch){try{const c=await s("/api/info");return c.ok?(await c.json()).capabilities?.agent_memory===!0:!1}catch{return!1}}const Rf="ontologyTab",qf="ontologyEntity",lg="editor";function ag(s){const c=new URLSearchParams(s);return{tab:c.get(Rf)??void 0,entityUri:c.get(qf)??void 0}}function tg(s,c){const T=new URLSearchParams(s);return T.set(Rf,c),`?${T.toString()}`}function eg(s,c){const T=new URLSearchParams(s);return T.set(Rf,lg),T.set(qf,c),`?${T.toString()}`}function ng(s){const c=new URLSearchParams(s);return c.delete(qf),`?${c.toString()}`}function ig(s){try{return ag(window.location.search)}catch{return{}}}function ug(s){const{tab:c,entityUri:T}=ig();return c!==void 0||T!==void 0}function Yf(s){try{window.history.replaceState(null,"",`${s(window.location.search)}${window.location.hash}`)}catch{}}function Bg(s){Yf(c=>tg(c,s))}function Rg(s){Yf(c=>eg(c,s))}function qg(){Yf(ng)}const cg=k.lazy(()=>ia(()=>import("./DecisionWorkspace-DLnQoq1W.js"),__vite__mapDeps([0,1,2])).then(s=>({default:s.DecisionWorkspace}))),fg=k.lazy(()=>ia(()=>import("./DiffMergeWorkspace-DIj2n0oj.js"),__vite__mapDeps([3,1,4,5,6])).then(s=>({default:s.DiffMergeWorkspace}))),sg=k.lazy(()=>ia(()=>import("./GraphWorkspace-Dny3nAOi.js").then(s=>s.G),__vite__mapDeps([7,1,8,4,9,10,11,12,13,14])).then(s=>({default:s.GraphWorkspace}))),rg=k.lazy(()=>ia(()=>import("./MemoryWorkspace-sxRCjA3X.js"),__vite__mapDeps([15,1,16,9,6,10,17,18,14,19])).then(s=>({default:s.MemoryWorkspace}))),og=k.lazy(()=>ia(()=>import("./ImportExportWorkspace-XEcfgbkG.js"),__vite__mapDeps([20,1,21,4,22,6,23,5])).then(s=>({default:s.ImportExportWorkspace}))),dg=k.lazy(()=>ia(()=>import("./LineageDiagram-B3vC6gPJ.js"),__vite__mapDeps([24,1,25,26,27])).then(s=>({default:s.LineageDiagram}))),mg=k.lazy(()=>ia(()=>import("./ReasoningWorkspace-DIR9Cx8Q.js"),__vite__mapDeps([28,1,13,12,5,2])).then(s=>({default:s.ReasoningWorkspace}))),gg=k.lazy(()=>ia(()=>import("./SparqlWorkspace-Cb9BLgce.js"),__vite__mapDeps([29,1,30,17,13,23])).then(s=>({default:s.SparqlWorkspace}))),hg=k.lazy(()=>ia(()=>import("./VocabularyWorkspace-CWWyOE4h.js"),__vite__mapDeps([31,1,32,33,22,26,21,6,5])).then(s=>({default:s.VocabularyWorkspace}))),yg=k.lazy(()=>ia(()=>import("./RegistryTab-B0_aYFx8.js"),__vite__mapDeps([34,1,4,35,33])).then(s=>({default:s.RegistryTab}))),pg=k.lazy(()=>ia(()=>import("./EntityResolutionTab-DogkN3fi.js"),__vite__mapDeps([36,1,4,6,33,14])).then(s=>({default:s.EntityResolutionTab}))),bg=k.lazy(()=>ia(()=>import("./KGOverviewTab-lmsMI0ma.js"),__vite__mapDeps([37,1,6,10])).then(s=>({default:s.KGOverviewTab}))),vg=k.lazy(()=>ia(()=>import("./OntologySummaryTab-CUk0k8ue.js"),__vite__mapDeps([38,1,32,39,33,19])).then(s=>({default:s.OntologySummaryTab}))),xg=k.lazy(()=>ia(()=>import("./index-CbqBGY6W.js"),__vite__mapDeps([40,1,6,35,23,14,33,5,19,39,11,10,25,26,27,12,22,18,30,13])).then(s=>({default:s.OntologyWorkspace}))),Sg={checking:"Connecting…",online:"System Online",offline:"Backend Unreachable"},zg=new dm,_g=Array.from({length:42},(s,c)=>({cx:170+c*73%330,cy:170+c*47%210,r:2+c%3,fill:["#56d364","#58a6ff","#f2b66d","#ff9daf"][c%4]})),Ag=[{id:"explore",label:"Knowledge Explorer",hint:"Graph and vocabulary browsing",icon:Fd},{id:"analyze",label:"Analyze",hint:"Query and inspect the dataset",icon:Rm},{id:"decisions",label:"Decisions",hint:"Decision chains and precedent review",icon:l0},{id:"enrich",label:"Enrich",hint:"Import, export, and merge workflows",icon:Id},{id:"manage",label:"Manage",hint:"Lineage and governance tooling",icon:Wm},{id:"ontology-hub",label:"Ontology Hub",hint:"Schema governance, registry, and vocabulary management",icon:Pd}];function Eg(){return ug()?"ontology-hub":"welcome"}const Tg=`
  :root {
    --app-bg: #07111f;
    --panel-bg: rgba(7, 17, 31, 0.82);
    --panel-border: rgba(140, 192, 255, 0.14);
    --text-main: #ebf3ff;
    --text-muted: #8fa8c6;
    --accent: #4aa3ff;
    --accent-strong: #7fd0ff;
    --warm: #f2b66d;
    --success: #4cc38a;

    /* ── Shared workspace design tokens ── */
    --ws-bg: #060d1a;
    --ws-surface: rgba(255,255,255,0.028);
    --ws-surface-hover: rgba(74,163,255,0.07);
    --ws-border: rgba(74,163,255,0.13);
    --ws-border-strong: rgba(74,163,255,0.26);
    --ws-text: #ddeeff;
    --ws-text-muted: #5a7a9a;
    --ws-text-dim: #3a5570;
    --ws-accent: #4aa3ff;
    --ws-accent-soft: rgba(74,163,255,0.12);
    --ws-green: #4cc38a;
    --ws-green-soft: rgba(76,195,138,0.12);
    --ws-amber: #f2b66d;
    --ws-amber-soft: rgba(242,182,109,0.12);
    --ws-red: #ff7b72;
    --ws-red-soft: rgba(255,123,114,0.12);
    --ws-purple: #c084fc;
    --ws-purple-soft: rgba(192,132,252,0.1);
    --ws-radius: 14px;
    --ws-radius-sm: 8px;
    --ws-radius-lg: 20px;
  }

  /* ── Shared workspace primitives (available to all workspace components) ── */
  .ws-page {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background: var(--ws-bg);
    overflow: hidden;
  }

  .ws-scroll {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: thin;
    scrollbar-color: var(--ws-border) transparent;
  }

  .ws-padded {
    padding: 24px 28px;
  }

  .ws-split {
    display: grid;
    height: 100%;
    overflow: hidden;
  }

  .ws-split--2col { grid-template-columns: 300px 1fr; }
  .ws-split--half { grid-template-columns: 1fr 1fr; }
  .ws-split--rows { grid-template-rows: 1fr auto; }

  .ws-panel {
    background: var(--ws-surface);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius);
    overflow: hidden;
  }

  .ws-panel--inset {
    background: rgba(0,0,0,0.22);
    border: 1px solid rgba(74,163,255,0.09);
    border-radius: var(--ws-radius);
  }

  .ws-card {
    background: var(--ws-surface);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius);
    padding: 20px;
    position: relative;
    overflow: hidden;
    transition: border-color 180ms ease, background 180ms ease;
  }

  .ws-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(74,163,255,0.18), transparent);
  }

  .ws-card:hover {
    border-color: var(--ws-border-strong);
    background: var(--ws-surface-hover);
  }

  .ws-eyebrow {
    font-family: "JetBrains Mono", "Fira Code", monospace;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--ws-text-muted);
  }

  .ws-label {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--ws-text-muted);
    margin-bottom: 8px;
    display: block;
  }

  .ws-title {
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.035em;
    color: var(--ws-text);
    margin: 0;
  }

  .ws-body {
    font-size: 13px;
    line-height: 1.65;
    color: var(--ws-text-muted);
  }

  .ws-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 9px 16px;
    border-radius: var(--ws-radius-sm);
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: 160ms ease;
    border: 1px solid transparent;
  }

  .ws-btn--primary {
    background: linear-gradient(135deg, rgba(74,163,255,0.28), rgba(56,210,160,0.16));
    border-color: rgba(74,163,255,0.4);
    color: #e8f6ff;
    box-shadow: 0 0 0 1px rgba(74,163,255,0.08) inset;
  }

  .ws-btn--primary:hover:not(:disabled) {
    background: linear-gradient(135deg, rgba(74,163,255,0.4), rgba(56,210,160,0.24));
    border-color: rgba(74,163,255,0.6);
    box-shadow: 0 6px 20px rgba(74,163,255,0.18);
    transform: translateY(-1px);
  }

  .ws-btn--ghost {
    background: rgba(255,255,255,0.04);
    border-color: var(--ws-border);
    color: var(--ws-text-muted);
  }

  .ws-btn--ghost:hover:not(:disabled) {
    background: var(--ws-surface-hover);
    border-color: var(--ws-border-strong);
    color: var(--ws-text);
  }

  .ws-btn--danger {
    background: var(--ws-red-soft);
    border-color: rgba(255,123,114,0.3);
    color: #ff9e97;
  }

  .ws-btn--success {
    background: var(--ws-green-soft);
    border-color: rgba(76,195,138,0.3);
    color: #6ee7b7;
  }

  .ws-btn:disabled {
    opacity: 0.45;
    cursor: not-allowed;
    transform: none !important;
  }

  .ws-input {
    width: 100%;
    padding: 9px 12px;
    background: rgba(0,0,0,0.28);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius-sm);
    color: var(--ws-text);
    font-size: 13px;
    outline: none;
    transition: border-color 160ms ease;
    box-sizing: border-box;
  }

  .ws-input:focus {
    border-color: var(--ws-accent);
    box-shadow: 0 0 0 3px rgba(74,163,255,0.1);
  }

  .ws-textarea {
    width: 100%;
    padding: 12px;
    background: rgba(0,0,0,0.28);
    border: 1px solid var(--ws-border);
    border-radius: var(--ws-radius-sm);
    color: var(--ws-text);
    font-family: "JetBrains Mono", "Fira Code", "Consolas", monospace;
    font-size: 12.5px;
    line-height: 1.7;
    resize: vertical;
    outline: none;
    transition: border-color 160ms ease;
    box-sizing: border-box;
  }

  .ws-textarea:focus {
    border-color: var(--ws-accent);
    box-shadow: 0 0 0 3px rgba(74,163,255,0.1);
  }

  .ws-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 9px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.04em;
    white-space: nowrap;
  }

  .ws-pill--accent { color: #7fd0ff; background: var(--ws-accent-soft); border: 1px solid rgba(74,163,255,0.22); }
  .ws-pill--green  { color: #6ee7b7; background: var(--ws-green-soft);  border: 1px solid rgba(76,195,138,0.28); }
  .ws-pill--amber  { color: #fbbf24; background: var(--ws-amber-soft);  border: 1px solid rgba(242,182,109,0.28); }
  .ws-pill--red    { color: #fca5a5; background: var(--ws-red-soft);    border: 1px solid rgba(255,123,114,0.28); }
  .ws-pill--purple { color: #d8b4fe; background: var(--ws-purple-soft); border: 1px solid rgba(192,132,252,0.22); }
  .ws-pill--mono   { color: var(--ws-text-muted); background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); }

  .ws-divider {
    height: 1px;
    background: var(--ws-border);
    margin: 0;
  }

  .ws-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 48px 24px;
    gap: 10px;
    color: var(--ws-text-muted);
  }

  .ws-empty-icon { opacity: 0.35; margin-bottom: 4px; }
  .ws-empty-title { font-size: 14px; font-weight: 700; color: var(--ws-text); }
  .ws-empty-body { font-size: 12px; line-height: 1.5; max-width: 36ch; }

  .ws-sidebar {
    border-right: 1px solid var(--ws-border);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: rgba(0,0,0,0.12);
  }

  .ws-sidebar-header {
    padding: 18px 16px 14px;
    border-bottom: 1px solid var(--ws-border);
    flex-shrink: 0;
  }

  .ws-sidebar-body {
    flex: 1;
    overflow-y: auto;
    padding: 10px 10px;
    scrollbar-width: thin;
    scrollbar-color: var(--ws-border) transparent;
  }

  .ws-list-item {
    width: 100%;
    text-align: left;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid transparent;
    background: transparent;
    color: var(--ws-text-muted);
    cursor: pointer;
    transition: 140ms ease;
    display: block;
  }

  .ws-list-item:hover {
    background: var(--ws-surface);
    border-color: var(--ws-border);
    color: var(--ws-text);
  }

  .ws-list-item--active {
    background: var(--ws-accent-soft);
    border-color: var(--ws-border-strong);
    color: #e8f6ff;
  }

  .ws-stat-grid {
    display: grid;
    gap: 12px;
  }

  .ws-stat-grid--3 { grid-template-columns: repeat(3, 1fr); }
  .ws-stat-grid--4 { grid-template-columns: repeat(4, 1fr); }
  .ws-stat-grid--2 { grid-template-columns: repeat(2, 1fr); }

  .ws-stat-card {
    padding: 18px 20px;
    border-radius: var(--ws-radius);
    border: 1px solid var(--ws-border);
    background: var(--ws-surface);
    position: relative;
    overflow: hidden;
  }

  .ws-stat-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(74,163,255,0.2), transparent);
  }

  .ws-stat-value {
    font-size: 28px;
    font-weight: 800;
    letter-spacing: -0.04em;
    color: var(--ws-text);
    line-height: 1;
  }

  .ws-stat-label {
    margin-top: 6px;
    font-size: 11px;
    font-weight: 600;
    color: var(--ws-text-dim);
    letter-spacing: 0.04em;
  }

  @keyframes ws-spin { to { transform: rotate(360deg); } }
  .ws-spin { animation: ws-spin 0.8s linear infinite; }

  @keyframes ws-skeleton {
    0%, 100% { opacity: 0.4; }
    50% { opacity: 0.7; }
  }

  .ws-skeleton {
    background: rgba(255,255,255,0.06);
    border-radius: 8px;
    animation: ws-skeleton 1.4s ease-in-out infinite;
  }

  @keyframes ws-slide-up {
    from { opacity: 0; transform: translateY(14px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .ws-animate-in { animation: ws-slide-up 0.22s ease both; }

  .app-shell {
    display: flex;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    color: var(--text-main);
    background:
      radial-gradient(circle at top left, rgba(74, 163, 255, 0.12), transparent 32%),
      radial-gradient(circle at bottom right, rgba(242, 182, 109, 0.08), transparent 26%),
      linear-gradient(180deg, #091322 0%, #050b15 100%);
    font-family: "Segoe UI", "SF Pro Display", sans-serif;
  }

  .app-rail {
    width: 88px;
    padding: 20px 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    border-right: 1px solid var(--panel-border);
    background: rgba(3, 9, 18, 0.92);
    backdrop-filter: blur(18px);
  }

  .brand-pill {
    width: 100%;
    min-height: 56px;
    border-radius: 18px;
    display: grid;
    place-items: center;
    color: var(--text-main);
    background: linear-gradient(135deg, rgba(74, 163, 255, 0.22), rgba(127, 208, 255, 0.08));
    border: 1px solid rgba(127, 208, 255, 0.18);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.12em;
  }

  .nav-button {
    border: 1px solid transparent;
    background: transparent;
    color: var(--text-muted);
    border-radius: 18px;
    min-height: 72px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    transition: 160ms ease;
  }

  .nav-button:hover {
    color: var(--text-main);
    background: rgba(74, 163, 255, 0.08);
    border-color: rgba(74, 163, 255, 0.12);
  }

  .nav-button[data-active='true'] {
    color: var(--text-main);
    background: linear-gradient(180deg, rgba(74, 163, 255, 0.18), rgba(74, 163, 255, 0.08));
    border-color: rgba(127, 208, 255, 0.22);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
  }

  .nav-label {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
  }

  .workspace-shell {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
  }

  .workspace-header {
    padding: 14px 22px;
    border-bottom: 1px solid var(--panel-border);
    background: linear-gradient(180deg, rgba(7, 17, 31, 0.94), rgba(7, 17, 31, 0.82));
    backdrop-filter: blur(18px);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    min-height: 68px;
  }

  .workspace-header--compact {
    min-height: 60px;
    padding: 10px 18px;
    background: linear-gradient(180deg, rgba(7, 17, 31, 0.92), rgba(7, 17, 31, 0.72));
  }

  .workspace-header--compact .workspace-title {
    font-size: 16px;
  }

  .workspace-header--compact .workspace-subtitle {
    font-size: 11px;
  }

  .workspace-header-main {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 14px;
  }

  .workspace-kicker {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 10px;
    border-radius: 999px;
    background: rgba(74, 163, 255, 0.08);
    border: 1px solid rgba(127, 208, 255, 0.14);
    color: var(--text-muted);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    white-space: nowrap;
  }

  .workspace-kicker::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 999px;
    background: linear-gradient(135deg, var(--accent-strong), var(--warm));
    box-shadow: 0 0 14px rgba(127, 208, 255, 0.45);
  }

  .workspace-title-block {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 3px;
  }

  .workspace-title {
    margin: 0;
    font-size: 20px;
    line-height: 1;
    letter-spacing: -0.03em;
  }

  .workspace-subtitle {
    color: var(--text-muted);
    font-size: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .workspace-tabs {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    justify-content: flex-end;
  }

  .workspace-tab {
    border: 1px solid rgba(127, 208, 255, 0.18);
    background: rgba(9, 19, 34, 0.56);
    color: var(--text-muted);
    border-radius: 999px;
    padding: 8px 12px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
    transition: 160ms ease;
    white-space: nowrap;
  }

  .workspace-tab[data-active='true'] {
    color: var(--text-main);
    background: rgba(74, 163, 255, 0.16);
    border-color: rgba(127, 208, 255, 0.3);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.05);
  }

  .workspace-body {
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }

  /* ── Welcome page ─────────────────────────────────────── */
  .landing-page {
    position: relative;
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    background:
      radial-gradient(ellipse 80% 50% at 50% -10%, rgba(74, 163, 255, 0.18) 0%, transparent 60%),
      radial-gradient(ellipse 60% 40% at 80% 90%, rgba(242, 182, 109, 0.1) 0%, transparent 50%),
      linear-gradient(180deg, #060d1a 0%, #03070f 100%);
    scrollbar-width: thin;
    scrollbar-color: rgba(74,163,255,0.18) transparent;
  }

  .landing-page::before {
    content: "";
    position: fixed;
    inset: 0 0 0 88px;
    pointer-events: none;
    background:
      repeating-linear-gradient(0deg, transparent, transparent 79px, rgba(74,163,255,0.035) 80px),
      repeating-linear-gradient(90deg, transparent, transparent 79px, rgba(74,163,255,0.025) 80px);
    mask-image: radial-gradient(ellipse 90% 80% at 50% 20%, black 30%, transparent 100%);
  }

  .landing-shell {
    position: relative;
    z-index: 1;
    width: min(1360px, 100%);
    margin: 0 auto;
    padding: clamp(28px, 4vw, 56px) clamp(20px, 3vw, 48px);
    display: flex;
    flex-direction: column;
    gap: 56px;
  }

  /* ── Hero ──────────────────────────────────────────────── */
  .landing-hero {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(380px, 520px);
    gap: clamp(24px, 3vw, 48px);
    align-items: center;
    min-height: min(580px, calc(100vh - 140px));
  }

  .landing-copy {
    display: flex;
    flex-direction: column;
    gap: 0;
  }

  .landing-status-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 24px;
    --status-color: #4cc38a;
    --status-shadow-a: 0 0 0 3px rgba(76, 195, 138, 0.22), 0 0 12px rgba(76, 195, 138, 0.5);
    --status-shadow-b: 0 0 0 5px rgba(76, 195, 138, 0.1), 0 0 20px rgba(76, 195, 138, 0.35);
  }

  .landing-status-bar[data-status='checking'] {
    --status-color: #f2b66d;
    --status-shadow-a: 0 0 0 3px rgba(242, 182, 109, 0.22), 0 0 12px rgba(242, 182, 109, 0.5);
    --status-shadow-b: 0 0 0 5px rgba(242, 182, 109, 0.1), 0 0 20px rgba(242, 182, 109, 0.35);
  }

  .landing-status-bar[data-status='offline'] {
    --status-color: #ff7b72;
    --status-shadow-a: 0 0 0 3px rgba(255, 123, 114, 0.22), 0 0 12px rgba(255, 123, 114, 0.5);
    --status-shadow-b: 0 0 0 5px rgba(255, 123, 114, 0.1), 0 0 20px rgba(255, 123, 114, 0.35);
  }

  .landing-status-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: var(--status-color);
    box-shadow: var(--status-shadow-a);
    animation: landing-pulse 2.4s ease-in-out infinite;
  }

  .landing-status-text {
    color: var(--status-color);
    font: 700 11px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
  }

  .landing-status-divider {
    width: 1px;
    height: 14px;
    background: rgba(158, 217, 255, 0.2);
  }

  .landing-status-version {
    color: #5a7a9a;
    font: 600 11px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.06em;
  }

  .landing-kicker {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 5px 12px 5px 8px;
    border-radius: 999px;
    border: 1px solid rgba(74, 163, 255, 0.3);
    background: rgba(74, 163, 255, 0.08);
    color: #7fd0ff;
    font: 700 11px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    width: fit-content;
    margin-bottom: 20px;
  }

  .landing-kicker-mark {
    width: 16px;
    height: 16px;
    border-radius: 6px;
    background: linear-gradient(135deg, #4aa3ff, #56d3a0);
    display: grid;
    place-items: center;
    flex: 0 0 auto;
  }

  .landing-kicker-node { display: none; }

  .landing-kicker-mark::after {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 999px;
    background: rgba(3, 10, 20, 0.8);
  }

  .landing-title {
    margin: 0 0 20px;
    color: #f0f7ff;
    font-family: "Inter", "Segoe UI", sans-serif;
    font-size: clamp(38px, 4.8vw, 72px);
    line-height: 1.08;
    letter-spacing: -0.04em;
    font-weight: 800;
  }

  .landing-title span {
    color: transparent;
    background: linear-gradient(100deg, #7fd0ff 0%, #4cc38a 50%, #f2b66d 100%);
    -webkit-background-clip: text;
    background-clip: text;
  }

  .landing-subtitle {
    margin: 0 0 32px;
    color: #7a99b8;
    font-size: clamp(14px, 1.2vw, 17px);
    line-height: 1.7;
    max-width: 54ch;
  }

  .landing-cta-row {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
  }

  .landing-cta-primary {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 22px;
    border-radius: 12px;
    border: 1px solid rgba(74, 163, 255, 0.5);
    background: linear-gradient(135deg, rgba(74, 163, 255, 0.28), rgba(56, 210, 160, 0.18));
    color: #e8f6ff;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    transition: 180ms ease;
    box-shadow: 0 0 0 1px rgba(74, 163, 255, 0.1) inset, 0 8px 24px rgba(74, 163, 255, 0.15);
  }

  .landing-cta-primary:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, rgba(74, 163, 255, 0.38), rgba(56, 210, 160, 0.26));
    box-shadow: 0 0 0 1px rgba(74, 163, 255, 0.18) inset, 0 14px 32px rgba(74, 163, 255, 0.22);
  }

  .landing-cta-secondary {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 18px;
    border-radius: 12px;
    border: 1px solid rgba(158, 217, 255, 0.14);
    background: rgba(255, 255, 255, 0.04);
    color: #8fafc8;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: 180ms ease;
  }

  .landing-cta-secondary:hover {
    border-color: rgba(158, 217, 255, 0.26);
    color: #c5dcef;
    background: rgba(255, 255, 255, 0.07);
  }

  /* ── Preview panel ─────────────────────────────────────── */
  .landing-preview {
    position: relative;
    overflow: hidden;
    border-radius: 24px;
    border: 1px solid rgba(74, 163, 255, 0.18);
    background:
      radial-gradient(circle at 40% 30%, rgba(74, 163, 255, 0.14), transparent 46%),
      radial-gradient(circle at 70% 70%, rgba(242, 182, 109, 0.1), transparent 38%),
      linear-gradient(145deg, rgba(8, 17, 28, 0.96), rgba(3, 8, 14, 0.88));
    box-shadow: 0 24px 72px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255,255,255,0.04) inset;
    aspect-ratio: 4/3.2;
    min-height: 340px;
  }

  .landing-preview-topbar {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 38px;
    background: rgba(4, 10, 18, 0.82);
    border-bottom: 1px solid rgba(74, 163, 255, 0.1);
    backdrop-filter: blur(12px);
    display: flex;
    align-items: center;
    padding: 0 14px;
    gap: 8px;
  }

  .landing-preview-dot {
    width: 10px;
    height: 10px;
    border-radius: 999px;
  }

  .landing-preview-dot:nth-child(1) { background: rgba(255, 95, 86, 0.7); }
  .landing-preview-dot:nth-child(2) { background: rgba(255, 189, 46, 0.7); }
  .landing-preview-dot:nth-child(3) { background: rgba(39, 201, 63, 0.7); }

  .landing-preview-tab {
    margin-left: 12px;
    padding: 3px 10px;
    border-radius: 6px;
    background: rgba(74, 163, 255, 0.12);
    border: 1px solid rgba(74, 163, 255, 0.2);
    color: #7fd0ff;
    font: 600 10px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.06em;
  }

  .landing-preview-orbit {
    position: absolute;
    inset: 38px 0 0;
    opacity: 0.95;
  }

  .landing-preview-orbit svg {
    width: 100%;
    height: 100%;
    overflow: visible;
  }

  .landing-preview-line {
    stroke: rgba(74, 163, 255, 0.3);
    stroke-width: 1.2;
    fill: none;
    stroke-dasharray: 4 3;
  }

  .landing-preview-line--warm {
    stroke: rgba(242, 182, 109, 0.3);
  }

  .landing-preview-line--mint {
    stroke: rgba(76, 195, 138, 0.28);
  }

  .landing-node {
    transform-origin: center;
    animation: landing-float 7s ease-in-out infinite;
  }

  .landing-node:nth-child(2n) { animation-delay: -2.2s; }
  .landing-node:nth-child(3n) { animation-delay: -4.1s; }

  .landing-command-card,
  .landing-dossier-card,
  .landing-timeline-card {
    position: absolute;
    border: 1px solid rgba(74, 163, 255, 0.16);
    background: rgba(3, 9, 18, 0.84);
    backdrop-filter: blur(20px);
    box-shadow: 0 12px 32px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.04) inset;
  }

  .landing-command-card {
    top: 50px;
    left: 16px;
    right: 16px;
    border-radius: 14px;
    padding: 10px 14px;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .landing-command-icon {
    width: 32px;
    height: 32px;
    border-radius: 10px;
    display: grid;
    place-items: center;
    color: #56d3a0;
    background: rgba(76, 195, 138, 0.1);
    border: 1px solid rgba(76, 195, 138, 0.2);
    flex: 0 0 auto;
  }

  .landing-command-label {
    color: #c8dff0;
    font-size: 12px;
    font-weight: 700;
  }

  .landing-command-meta {
    margin-top: 2px;
    color: #4a6a85;
    font: 500 10px/1 "JetBrains Mono", monospace;
  }

  .landing-dossier-card {
    right: 14px;
    bottom: 80px;
    width: min(210px, calc(100% - 28px));
    border-radius: 16px;
    padding: 14px;
  }

  .landing-dossier-kicker {
    color: #56d3a0;
    font: 700 9px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
  }

  .landing-dossier-title {
    margin-top: 6px;
    color: #e8f4ff;
    font: 800 20px/1 "Inter", sans-serif;
    letter-spacing: -0.04em;
  }

  .landing-dossier-row {
    margin-top: 8px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    color: #5e7d98;
    font-size: 10px;
    font-weight: 600;
  }

  .landing-dossier-row strong { color: #f2b66d; font-weight: 700; }

  .landing-timeline-card {
    left: 14px;
    right: 14px;
    bottom: 14px;
    border-radius: 12px;
    padding: 10px 12px;
  }

  .landing-timeline-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
  }

  .landing-timeline-title {
    color: #5e7d98;
    font: 700 9px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .landing-timeline-badge {
    color: #7fd0ff;
    font: 700 9px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.06em;
  }

  .landing-timeline-track {
    position: relative;
    height: 4px;
    border-radius: 999px;
    background: rgba(74, 163, 255, 0.1);
    overflow: hidden;
  }

  .landing-timeline-track::after {
    content: "";
    position: absolute;
    inset: 0 28% 0 0;
    border-radius: inherit;
    background: linear-gradient(90deg, #4cc38a, #4aa3ff, #f2b66d);
  }

  .landing-timeline-labels {
    display: flex;
    justify-content: space-between;
    margin-top: 6px;
    color: #3a5570;
    font: 600 9px/1 "JetBrains Mono", monospace;
  }

  /* ── Metrics strip ─────────────────────────────────────── */
  .landing-metrics {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
  }

  .landing-metric {
    padding: 18px 20px;
    border-radius: 16px;
    border: 1px solid rgba(158, 217, 255, 0.09);
    background: rgba(255, 255, 255, 0.025);
    position: relative;
    overflow: hidden;
    transition: border-color 200ms ease;
  }

  .landing-metric::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(158, 217, 255, 0.2), transparent);
  }

  .landing-metric:hover {
    border-color: rgba(158, 217, 255, 0.18);
  }

  .landing-metric-value {
    color: #ddeeff;
    font: 800 28px/1 "Inter", sans-serif;
    letter-spacing: -0.04em;
  }

  .landing-metric[data-tone='mint'] .landing-metric-value { color: #56d3a0; }
  .landing-metric[data-tone='amber'] .landing-metric-value { color: #f2b66d; }
  .landing-metric[data-tone='rose'] .landing-metric-value { color: #ff9daf; }
  .landing-metric[data-tone='cyan'] .landing-metric-value { color: #7fd0ff; }

  .landing-metric-label {
    margin-top: 6px;
    color: #4a6a85;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
  }

  /* ── Workspace grid ────────────────────────────────────── */
  .landing-section-header {
    display: flex;
    align-items: baseline;
    gap: 14px;
    margin-bottom: 16px;
  }

  .landing-section-title {
    color: #c8dff0;
    font: 700 13px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin: 0;
  }

  .landing-section-line {
    flex: 1;
    height: 1px;
    background: rgba(74, 163, 255, 0.1);
  }

  .landing-workspace-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 12px;
  }

  .landing-workspace-card {
    position: relative;
    overflow: hidden;
    padding: 22px;
    border-radius: 18px;
    border: 1px solid rgba(158, 217, 255, 0.09);
    background: rgba(255, 255, 255, 0.025);
    cursor: pointer;
    text-align: left;
    color: inherit;
    transition: border-color 200ms ease, background 200ms ease, transform 200ms ease, box-shadow 200ms ease;
  }

  .landing-workspace-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(158, 217, 255, 0.16), transparent);
    opacity: 0;
    transition: opacity 200ms ease;
  }

  .landing-workspace-card:hover {
    border-color: rgba(74, 163, 255, 0.24);
    background: rgba(74, 163, 255, 0.06);
    transform: translateY(-3px);
    box-shadow: 0 12px 32px rgba(0,0,0,0.28);
  }

  .landing-workspace-card:hover::before { opacity: 1; }

  .landing-workspace-card--primary {
    grid-column: span 3;
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 24px;
    border-color: rgba(76, 195, 138, 0.22);
    background: linear-gradient(135deg, rgba(76, 195, 138, 0.08), rgba(74, 163, 255, 0.05));
  }

  .landing-workspace-card--primary:hover {
    border-color: rgba(76, 195, 138, 0.38);
    background: linear-gradient(135deg, rgba(76, 195, 138, 0.12), rgba(74, 163, 255, 0.08));
    box-shadow: 0 12px 40px rgba(76, 195, 138, 0.12);
  }

  .landing-workspace-card-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: grid;
    place-items: center;
    color: #7fd0ff;
    background: rgba(74, 163, 255, 0.1);
    border: 1px solid rgba(74, 163, 255, 0.2);
    margin-bottom: 14px;
  }

  .landing-workspace-card--primary .landing-workspace-card-icon {
    color: #56d3a0;
    background: rgba(76, 195, 138, 0.1);
    border-color: rgba(76, 195, 138, 0.22);
    width: 48px;
    height: 48px;
    border-radius: 14px;
    margin-bottom: 0;
  }

  .landing-workspace-card-eyebrow {
    color: #56d3a0;
    font: 700 10px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin-bottom: 6px;
  }

  .landing-workspace-card-title {
    color: #e2effb;
    font: 700 16px/1.2 "Inter", sans-serif;
    letter-spacing: -0.025em;
    margin-bottom: 6px;
  }

  .landing-workspace-card--primary .landing-workspace-card-title {
    font-size: 20px;
  }

  .landing-workspace-card-desc {
    color: #4a6a85;
    font-size: 12px;
    line-height: 1.5;
    max-width: 36ch;
  }

  .landing-workspace-card-arrow {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    display: grid;
    place-items: center;
    color: #56d3a0;
    background: rgba(76, 195, 138, 0.1);
    border: 1px solid rgba(76, 195, 138, 0.2);
    flex: 0 0 auto;
    transition: 180ms ease;
  }

  .landing-workspace-card--primary:hover .landing-workspace-card-arrow {
    background: rgba(76, 195, 138, 0.18);
    transform: translateX(3px);
  }

  /* ── Capability band ───────────────────────────────────── */
  .landing-capability-band {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    padding: 14px 18px;
    border: 1px solid rgba(74, 163, 255, 0.1);
    border-radius: 16px;
    background: rgba(3, 9, 18, 0.6);
    backdrop-filter: blur(12px);
  }

  .landing-capability-label {
    color: #3a5570;
    font: 700 10px/1 "JetBrains Mono", monospace;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin-right: 4px;
    white-space: nowrap;
  }

  .landing-capability {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    padding: 0 10px;
    border-radius: 999px;
    color: #5a7a9a;
    background: rgba(74, 163, 255, 0.05);
    border: 1px solid rgba(74, 163, 255, 0.12);
    font-size: 11px;
    font-weight: 600;
    transition: 160ms ease;
    cursor: default;
  }

  .landing-capability:hover {
    color: #9be8ff;
    border-color: rgba(74, 163, 255, 0.28);
    background: rgba(74, 163, 255, 0.1);
  }

  /* ── Animations ────────────────────────────────────────── */
  @keyframes landing-float {
    0%, 100% { transform: translateY(0) scale(1); }
    50% { transform: translateY(-8px) scale(1.05); }
  }

  @keyframes landing-pulse {
    0%, 100% { box-shadow: var(--status-shadow-a); }
    50% { box-shadow: var(--status-shadow-b); }
  }

  .workspace-loading {
    height: 100%;
    display: grid;
    place-items: center;
    color: var(--text-muted);
    background: linear-gradient(180deg, rgba(7, 17, 31, 0.8), rgba(5, 11, 21, 0.92));
    font-size: 14px;
  }

  @media (max-width: 980px) {
    .workspace-header {
      flex-direction: column;
      align-items: stretch;
      min-height: auto;
      padding: 12px 18px;
    }

    .workspace-header-main {
      justify-content: space-between;
    }

    .workspace-subtitle {
      white-space: normal;
    }

    .workspace-tabs {
      justify-content: flex-start;
    }

    .landing-hero {
      grid-template-columns: 1fr;
      min-height: auto;
    }

    .landing-workspace-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .landing-workspace-card--primary {
      grid-column: span 2;
    }

    .landing-metrics {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .landing-preview {
      aspect-ratio: 16/10;
      min-height: 320px;
    }
  }

  @media (max-width: 680px) {
    .app-rail {
      width: 72px;
      padding: 14px 9px;
    }

    .landing-shell {
      padding: 20px 16px;
      gap: 36px;
    }

    .landing-workspace-grid {
      grid-template-columns: 1fr;
    }

    .landing-workspace-card--primary {
      grid-column: span 1;
      grid-template-columns: 1fr;
    }

    .landing-workspace-card-arrow {
      display: none;
    }

    .landing-metrics {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .landing-preview {
      min-height: 280px;
    }

    .landing-dossier-card {
      left: 10px;
      right: 10px;
      width: auto;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .landing-node,
    .landing-workspace-card,
    .landing-cta-primary,
    .landing-cta-secondary {
      animation: none;
      transition: none;
    }
  }
`;function rn(s){const c=ti.c(23),{title:T,subtitle:m,tabs:D,compact:B,kicker:Y,children:R}=s,M=B===void 0?!1:B,b=Y===void 0?"Workspace":Y,w=`workspace-header${M?" workspace-header--compact":""}`;let E;c[0]!==b?(E=d.jsx("div",{className:"workspace-kicker",children:b}),c[0]=b,c[1]=E):E=c[1];let C;c[2]!==T?(C=d.jsx("h1",{className:"workspace-title",children:T}),c[2]=T,c[3]=C):C=c[3];let tl;c[4]!==m?(tl=m?d.jsx("div",{className:"workspace-subtitle",children:m}):null,c[4]=m,c[5]=tl):tl=c[5];let $;c[6]!==C||c[7]!==tl?($=d.jsxs("div",{className:"workspace-title-block",children:[C,tl]}),c[6]=C,c[7]=tl,c[8]=$):$=c[8];let F;c[9]!==E||c[10]!==$?(F=d.jsxs("div",{className:"workspace-header-main",children:[E,$]}),c[9]=E,c[10]=$,c[11]=F):F=c[11];let hl;c[12]!==D?(hl=D?d.jsx("div",{className:"workspace-tabs",children:D}):null,c[12]=D,c[13]=hl):hl=c[13];let ol;c[14]!==w||c[15]!==F||c[16]!==hl?(ol=d.jsxs("header",{className:w,children:[F,hl]}),c[14]=w,c[15]=F,c[16]=hl,c[17]=ol):ol=c[17];let bl;c[18]!==R?(bl=d.jsx("div",{className:"workspace-body",children:R}),c[18]=R,c[19]=bl):bl=c[19];let sl;return c[20]!==ol||c[21]!==bl?(sl=d.jsxs("section",{className:"workspace-shell",children:[ol,bl]}),c[20]=ol,c[21]=bl,c[22]=sl):sl=c[22],sl}function on(){const s=ti.c(1);let c;return s[0]===Symbol.for("react.memo_cache_sentinel")?(c=d.jsx("div",{className:"workspace-loading",children:"Loading workspace…"}),s[0]=c):c=s[0],c}function Jd(s,c){for(const T of c){const m=s[T];if(typeof m=="number"&&Number.isFinite(m))return m}return null}function Wd(s,c){return s===null?c:s.toLocaleString()}function Mg(s){const c=ti.c(107),{onOpenNetwork:T,onOpenVocabulary:m,onOpenReasoning:D,onOpenImport:B,onOpenDecisions:Y,onOpenManage:R}=s;let M;c[0]===Symbol.for("react.memo_cache_sentinel")?(M={nodes:null,edges:null,status:"checking"},c[0]=M):M=c[0];const[b,w]=k.useState(M);let E,C;c[1]===Symbol.for("react.memo_cache_sentinel")?(E=()=>{const ei=new AbortController;return fetch("/api/graph/stats",{signal:ei.signal}).then(Ug).then(Ja=>{if(!Ja){w(jg);return}w({nodes:Jd(Ja,["node_count","nodeCount","nodes"]),edges:Jd(Ja,["edge_count","edgeCount","edges"]),status:"online"})}).catch(Ja=>{Ja instanceof DOMException&&Ja.name==="AbortError"||w(wg)}),()=>ei.abort()},C=[],c[1]=E,c[2]=C):(E=c[1],C=c[2]),k.useEffect(E,C);const tl=b.status==="online";let $;c[3]!==b.nodes?($=Wd(b.nodes,"Live"),c[3]=b.nodes,c[4]=$):$=c[4];let F;c[5]!==$?(F={label:"Knowledge nodes",value:$,tone:"cyan"},c[5]=$,c[6]=F):F=c[6];let hl;c[7]!==b.edges?(hl=Wd(b.edges,"Ready"),c[7]=b.edges,c[8]=hl):hl=c[8];let ol;c[9]!==hl?(ol={label:"Relationships mapped",value:hl,tone:"mint"},c[9]=hl,c[10]=ol):ol=c[10];let bl;c[11]===Symbol.for("react.memo_cache_sentinel")?(bl={label:"Graph modes",value:"3",tone:"amber"},c[11]=bl):bl=c[11];const sl=tl?"Dataset online":"Ready to explore",Dl=tl?"Active":"Standby";let wl;c[12]!==Dl||c[13]!==sl?(wl={label:sl,value:Dl,tone:"rose"},c[12]=Dl,c[13]=sl,c[14]=wl):wl=c[14];let jl;c[15]!==wl||c[16]!==F||c[17]!==ol?(jl=[F,ol,bl,wl],c[15]=wl,c[16]=F,c[17]=ol,c[18]=jl):jl=c[18];const Cl=jl;let dl;c[19]!==m?(dl={label:"Vocabulary",description:"Schemes and terms",icon:Fd,onClick:m},c[19]=m,c[20]=dl):dl=c[20];let Hl;c[21]!==D?(Hl={label:"Analyze",description:"Inference and queries",icon:Ld,onClick:D},c[21]=D,c[22]=Hl):Hl=c[22];let Jl;c[23]!==Y?(Jl={label:"Decisions",description:"Chains and precedents",icon:l0,onClick:Y},c[23]=Y,c[24]=Jl):Jl=c[24];let Bl;c[25]!==B?(Bl={label:"Enrich",description:"Import and resolve",icon:Id,onClick:B},c[25]=B,c[26]=Bl):Bl=c[26];let rl;c[27]!==R?(rl={label:"Manage",description:"Lineage and ontology",icon:Kd,onClick:R},c[27]=R,c[28]=rl):rl=c[28];let Fl;c[29]!==dl||c[30]!==Hl||c[31]!==Jl||c[32]!==Bl||c[33]!==rl?(Fl=[dl,Hl,Jl,Bl,rl],c[29]=dl,c[30]=Hl,c[31]=Jl,c[32]=Bl,c[33]=rl,c[34]=Fl):Fl=c[34];const Ll=Fl;let zl;c[35]===Symbol.for("react.memo_cache_sentinel")?(zl=d.jsx("div",{className:"landing-status-dot"}),c[35]=zl):zl=c[35];const x=Sg[b.status];let A;c[36]!==x?(A=d.jsx("span",{className:"landing-status-text",children:x}),c[36]=x,c[37]=A):A=c[37];let j,q;c[38]===Symbol.for("react.memo_cache_sentinel")?(j=d.jsx("div",{className:"landing-status-divider"}),q=d.jsx("span",{className:"landing-status-version",children:"Semantica v2 · Semantic Intelligence"}),c[38]=j,c[39]=q):(j=c[38],q=c[39]);let X;c[40]!==b.status||c[41]!==A?(X=d.jsxs("div",{className:"landing-status-bar","data-status":b.status,children:[zl,A,j,q]}),c[40]=b.status,c[41]=A,c[42]=X):X=c[42];let vl;c[43]===Symbol.for("react.memo_cache_sentinel")?(vl=d.jsxs("div",{className:"landing-kicker","aria-label":"Product category",children:[d.jsx("span",{className:"landing-kicker-mark","aria-hidden":"true"}),"Knowledge Explorer"]}),c[43]=vl):vl=c[43];let al;c[44]===Symbol.for("react.memo_cache_sentinel")?(al=d.jsx("br",{}),c[44]=al):al=c[44];let V,pl;c[45]===Symbol.for("react.memo_cache_sentinel")?(V=d.jsxs("h1",{className:"landing-title",children:["Navigate knowledge",al,"like a ",d.jsx("span",{children:"living system."})]}),pl=d.jsx("p",{className:"landing-subtitle",children:"Semantica turns dense knowledge graphs into a navigable command center — discovery, reasoning, provenance, distance intelligence, and decision context, all in one interface."}),c[45]=V,c[46]=pl):(V=c[45],pl=c[46]);let Wl;c[47]===Symbol.for("react.memo_cache_sentinel")?(Wl=d.jsx(Hf,{size:16}),c[47]=Wl):Wl=c[47];let ca;c[48]===Symbol.for("react.memo_cache_sentinel")?(ca=d.jsx(Zd,{size:15}),c[48]=ca):ca=c[48];let Da;c[49]!==T?(Da=d.jsxs("button",{className:"landing-cta-primary",type:"button",onClick:T,children:[Wl,"Open Semantica Explorer",ca]}),c[49]=T,c[50]=Da):Da=c[50];let Za;c[51]===Symbol.for("react.memo_cache_sentinel")?(Za=d.jsx(Ld,{size:15}),c[51]=Za):Za=c[51];let fa;c[52]!==D?(fa=d.jsxs("button",{className:"landing-cta-secondary",type:"button",onClick:D,children:[Za,"Run Reasoning"]}),c[52]=D,c[53]=fa):fa=c[53];let qa;c[54]!==Da||c[55]!==fa?(qa=d.jsxs("div",{className:"landing-cta-row",children:[Da,fa]}),c[54]=Da,c[55]=fa,c[56]=qa):qa=c[56];let wa;c[57]!==X||c[58]!==qa?(wa=d.jsxs("div",{className:"landing-copy",children:[X,vl,V,pl,qa]}),c[57]=X,c[58]=qa,c[59]=wa):wa=c[59];let mt;c[60]===Symbol.for("react.memo_cache_sentinel")?(mt=d.jsxs("div",{className:"landing-preview-topbar","aria-hidden":"true",children:[d.jsx("div",{className:"landing-preview-dot"}),d.jsx("div",{className:"landing-preview-dot"}),d.jsx("div",{className:"landing-preview-dot"}),d.jsx("div",{className:"landing-preview-tab",children:"Semantica Explorer"})]}),c[60]=mt):mt=c[60];let Vt;c[61]===Symbol.for("react.memo_cache_sentinel")?(Vt=d.jsxs("div",{className:"landing-command-card",children:[d.jsx("div",{className:"landing-command-icon",children:d.jsx(Km,{size:15})}),d.jsxs("div",{children:[d.jsx("div",{className:"landing-command-label",children:"Search command, node, or concept"}),d.jsx("div",{className:"landing-command-meta",children:"distance heatmap · focused view · causal path"})]})]}),c[61]=Vt):Vt=c[61];let pa,gt,ht,me,Zt;c[62]===Symbol.for("react.memo_cache_sentinel")?(pa=d.jsx("path",{className:"landing-preview-line",d:"M110 310 C200 110 390 90 510 240"}),gt=d.jsx("path",{className:"landing-preview-line landing-preview-line--warm",d:"M120 190 C240 270 374 182 508 340"}),ht=d.jsx("path",{className:"landing-preview-line landing-preview-line--mint",d:"M168 378 C274 200 392 218 488 144"}),me=d.jsx("path",{className:"landing-preview-line landing-preview-line--warm",d:"M204 118 C318 340 408 368 526 284"}),Zt=d.jsx("path",{className:"landing-preview-line",d:"M110 310 C180 350 260 360 340 320 C420 280 480 260 510 240"}),c[62]=pa,c[63]=gt,c[64]=ht,c[65]=me,c[66]=Zt):(pa=c[62],gt=c[63],ht=c[64],me=c[65],Zt=c[66]);let yt;c[67]===Symbol.for("react.memo_cache_sentinel")?(yt=d.jsxs("g",{className:"landing-node",children:[d.jsx("circle",{cx:"110",cy:"310",r:"10",fill:"#4cc38a",fillOpacity:"0.9"}),d.jsx("circle",{cx:"110",cy:"310",r:"20",fill:"none",stroke:"rgba(76,195,138,0.24)",strokeWidth:"1.5"}),d.jsx("circle",{cx:"110",cy:"310",r:"34",fill:"none",stroke:"rgba(76,195,138,0.1)",strokeWidth:"1"})]}),c[67]=yt):yt=c[67];let pt;c[68]===Symbol.for("react.memo_cache_sentinel")?(pt=d.jsxs("g",{className:"landing-node",children:[d.jsx("circle",{cx:"204",cy:"118",r:"7",fill:"#4aa3ff",fillOpacity:"0.9"}),d.jsx("circle",{cx:"204",cy:"118",r:"16",fill:"none",stroke:"rgba(74,163,255,0.24)",strokeWidth:"1.5"})]}),c[68]=pt):pt=c[68];let bt;c[69]===Symbol.for("react.memo_cache_sentinel")?(bt=d.jsxs("g",{className:"landing-node",children:[d.jsx("circle",{cx:"510",cy:"240",r:"13",fill:"#f2b66d",fillOpacity:"0.9"}),d.jsx("circle",{cx:"510",cy:"240",r:"26",fill:"none",stroke:"rgba(242,182,109,0.26)",strokeWidth:"1.5"}),d.jsx("circle",{cx:"510",cy:"240",r:"40",fill:"none",stroke:"rgba(242,182,109,0.1)",strokeWidth:"1"})]}),c[69]=bt):bt=c[69];let ge;c[70]===Symbol.for("react.memo_cache_sentinel")?(ge=d.jsxs("g",{className:"landing-node",children:[d.jsx("circle",{cx:"488",cy:"144",r:"6",fill:"#ff9daf",fillOpacity:"0.9"}),d.jsx("circle",{cx:"488",cy:"144",r:"14",fill:"none",stroke:"rgba(255,157,175,0.22)",strokeWidth:"1.5"})]}),c[70]=ge):ge=c[70];let he;c[71]===Symbol.for("react.memo_cache_sentinel")?(he=d.jsxs("g",{className:"landing-node",children:[d.jsx("circle",{cx:"340",cy:"320",r:"9",fill:"#7fd0ff",fillOpacity:"0.9"}),d.jsx("circle",{cx:"340",cy:"320",r:"20",fill:"none",stroke:"rgba(127,208,255,0.22)",strokeWidth:"1.5"})]}),c[71]=he):he=c[71];let Rl;c[72]===Symbol.for("react.memo_cache_sentinel")?(Rl=d.jsx("div",{className:"landing-preview-orbit",children:d.jsxs("svg",{viewBox:"0 0 640 440",role:"img","aria-hidden":"true",children:[pa,gt,ht,me,Zt,yt,pt,bt,ge,he,d.jsx("g",{opacity:"0.45",children:_g.map(Dg)})]})}),c[72]=Rl):Rl=c[72];let ye,Lt;c[73]===Symbol.for("react.memo_cache_sentinel")?(ye=d.jsx("div",{className:"landing-dossier-kicker",children:"Entity Dossier"}),Lt=d.jsx("div",{className:"landing-dossier-title",children:"NSRP1"}),c[73]=ye,c[74]=Lt):(ye=c[73],Lt=c[74]);let Kt;c[75]===Symbol.for("react.memo_cache_sentinel")?(Kt=d.jsxs("div",{className:"landing-dossier-row",children:[d.jsx("span",{children:"Distance band"}),d.jsx("strong",{children:"Near"})]}),c[75]=Kt):Kt=c[75];let La;c[76]===Symbol.for("react.memo_cache_sentinel")?(La=d.jsxs("div",{className:"landing-dossier-row",children:[d.jsx("span",{children:"Path coherence"}),d.jsx("strong",{children:"0.84"})]}),c[76]=La):La=c[76];let pe;c[77]===Symbol.for("react.memo_cache_sentinel")?(pe=d.jsxs("div",{className:"landing-dossier-card",children:[ye,Lt,Kt,La,d.jsxs("div",{className:"landing-dossier-row",children:[d.jsx("span",{children:"Provenance"}),d.jsx("strong",{children:"Audited"})]})]}),c[77]=pe):pe=c[77];let Jt,be;c[78]===Symbol.for("react.memo_cache_sentinel")?(Jt=d.jsxs("div",{className:"landing-timeline-header",children:[d.jsx("span",{className:"landing-timeline-title",children:"Temporal Evidence"}),d.jsx("span",{className:"landing-timeline-badge",children:"66% coverage"})]}),be=d.jsx("div",{className:"landing-timeline-track"}),c[78]=Jt,c[79]=be):(Jt=c[78],be=c[79]);let ve;c[80]===Symbol.for("react.memo_cache_sentinel")?(ve=d.jsxs("div",{className:"landing-preview","aria-label":"Knowledge graph preview",children:[mt,Vt,Rl,pe,d.jsxs("div",{className:"landing-timeline-card",children:[Jt,be,d.jsxs("div",{className:"landing-timeline-labels",children:[d.jsx("span",{children:"1970"}),d.jsx("span",{children:"2030"})]})]})]}),c[80]=ve):ve=c[80];let ba;c[81]!==wa?(ba=d.jsxs("section",{className:"landing-hero",children:[wa,ve]}),c[81]=wa,c[82]=ba):ba=c[82];let El;c[83]!==Cl?(El=d.jsx("div",{className:"landing-metrics","aria-label":"System status",children:Cl.map(Ng)}),c[83]=Cl,c[84]=El):El=c[84];let sa;c[85]===Symbol.for("react.memo_cache_sentinel")?(sa=d.jsxs("div",{className:"landing-section-header",children:[d.jsx("h2",{className:"landing-section-title",children:"Workspaces"}),d.jsx("div",{className:"landing-section-line"})]}),c[85]=sa):sa=c[85];let ql,xe;c[86]===Symbol.for("react.memo_cache_sentinel")?(ql=d.jsxs("div",{children:[d.jsx("div",{className:"landing-workspace-card-eyebrow",children:"Primary Workspace"}),d.jsx("div",{className:"landing-workspace-card-title",children:"Semantica Explorer"}),d.jsx("div",{className:"landing-workspace-card-desc",children:"Full graph, grouped communities, focused neighborhoods, and distance intelligence — all in one canvas."})]}),xe={display:"flex",alignItems:"center",gap:"12px"},c[86]=ql,c[87]=xe):(ql=c[86],xe=c[87]);let Se;c[88]===Symbol.for("react.memo_cache_sentinel")?(Se=d.jsx("div",{className:"landing-workspace-card-icon",style:{marginBottom:0},children:d.jsx(Hf,{size:22})}),c[88]=Se):Se=c[88];let ze;c[89]===Symbol.for("react.memo_cache_sentinel")?(ze=d.jsxs("div",{style:xe,children:[Se,d.jsx("div",{className:"landing-workspace-card-arrow",children:d.jsx(Zd,{size:18})})]}),c[89]=ze):ze=c[89];let ja;c[90]!==T?(ja=d.jsxs("button",{className:"landing-workspace-card landing-workspace-card--primary",type:"button",onClick:T,children:[ql,ze]}),c[90]=T,c[91]=ja):ja=c[91];let Ua;c[92]!==Ll?(Ua=Ll.map(Og),c[92]=Ll,c[93]=Ua):Ua=c[93];let Ca;c[94]!==ja||c[95]!==Ua?(Ca=d.jsxs("section",{"aria-label":"Workspaces",children:[sa,d.jsxs("div",{className:"landing-workspace-grid",children:[ja,Ua]})]}),c[94]=ja,c[95]=Ua,c[96]=Ca):Ca=c[96];let va;c[97]===Symbol.for("react.memo_cache_sentinel")?(va=d.jsx("div",{className:"landing-capability-label",children:"Intelligence Layer"}),c[97]=va):va=c[97];let Ka;c[98]===Symbol.for("react.memo_cache_sentinel")?(Ka=d.jsxs("div",{className:"landing-capability",children:[d.jsx(km,{size:12}),"Distance Heatmap"]}),c[98]=Ka):Ka=c[98];let Ya;c[99]===Symbol.for("react.memo_cache_sentinel")?(Ya=d.jsxs("div",{className:"landing-capability",children:[d.jsx(Hf,{size:12}),"Focused Neighborhood"]}),c[99]=Ya):Ya=c[99];let _e;c[100]===Symbol.for("react.memo_cache_sentinel")?(_e=d.jsxs("div",{className:"landing-capability",children:[d.jsx(Pd,{size:12}),"Grouped Communities"]}),c[100]=_e):_e=c[100];let Wt;c[101]===Symbol.for("react.memo_cache_sentinel")?(Wt=d.jsxs("div",{className:"landing-capability",children:[d.jsx(Vm,{size:12}),"Trace Causal Path"]}),c[101]=Wt):Wt=c[101];let vt;c[102]===Symbol.for("react.memo_cache_sentinel")?(vt=d.jsxs("section",{className:"landing-capability-band","aria-label":"Intelligence capabilities",children:[va,Ka,Ya,_e,Wt,d.jsxs("div",{className:"landing-capability",children:[d.jsx(Kd,{size:12}),"Provenance Dossier"]})]}),c[102]=vt):vt=c[102];let Ga;return c[103]!==ba||c[104]!==El||c[105]!==Ca?(Ga=d.jsx("main",{className:"landing-page",children:d.jsxs("div",{className:"landing-shell",children:[ba,El,Ca,vt]})}),c[103]=ba,c[104]=El,c[105]=Ca,c[106]=Ga):Ga=c[106],Ga}function Og(s){const c=s.icon;return d.jsxs("button",{className:"landing-workspace-card",type:"button",onClick:s.onClick,children:[d.jsx("div",{className:"landing-workspace-card-icon",children:d.jsx(c,{size:18})}),d.jsx("div",{className:"landing-workspace-card-title",children:s.label}),d.jsx("div",{className:"landing-workspace-card-desc",children:s.description})]},s.label)}function Ng(s){return d.jsxs("div",{className:"landing-metric","data-tone":s.tone,children:[d.jsx("div",{className:"landing-metric-value",children:s.value}),d.jsx("div",{className:"landing-metric-label",children:s.label})]},s.label)}function Dg(s,c){return d.jsx("circle",{cx:s.cx,cy:s.cy*.82,r:s.r*.8,fill:s.fill},c)}function wg(s){return{...s,status:"offline"}}function jg(s){return{...s,status:"offline"}}function Ug(s){return s.ok?s.json():null}function Cg(){const s=ti.c(37),[c,T]=k.useState(Eg),[m,D]=k.useState("graph"),[B,Y]=k.useState("reasoning"),[R,M]=k.useState("import"),[b,w]=k.useState("lineage"),[E,C]=k.useState(null),[tl,$]=k.useState(!1),[F,hl]=k.useState(!1);let ol,bl;s[0]===Symbol.for("react.memo_cache_sentinel")?(ol=()=>{let q=!0;return Pm().then(X=>{q&&hl(X)}),()=>{q=!1}},bl=[],s[0]=ol,s[1]=bl):(ol=s[0],bl=s[1]),k.useEffect(ol,bl);let sl;s[2]!==tl?(sl=()=>!tl||window.confirm("Discard the unapplied Markdown draft and leave this resource?"),s[2]=tl,s[3]=sl):sl=s[3];const Dl=sl;let wl;s[4]!==Dl||s[5]!==m?(wl=q=>{q!==m&&Dl()&&($(!1),D(q))},s[4]=Dl,s[5]=m,s[6]=wl):wl=s[6];const jl=wl;let Cl;s[7]!==c||s[8]!==Dl?(Cl=q=>{q!==c&&(c==="explore"&&!Dl()||($(!1),T(q)))},s[7]=c,s[8]=Dl,s[9]=Cl):Cl=s[9];const dl=Cl;let Hl;s[10]!==c||s[11]!==F||s[12]!==B||s[13]!==R||s[14]!==m||s[15]!==E?.nodeId||s[16]!==E?.token||s[17]!==b||s[18]!==jl?(Hl=()=>c==="welcome"?d.jsx(Mg,{onOpenNetwork:()=>{T("explore"),D("graph")},onOpenVocabulary:()=>{T("explore"),D("vocabulary")},onOpenReasoning:()=>{T("analyze"),Y("reasoning")},onOpenImport:()=>{T("enrich"),M("import")},onOpenDecisions:()=>T("decisions"),onOpenManage:()=>T("manage")}):c==="explore"?d.jsx(rn,{title:"Explore",subtitle:m==="graph"?void 0:m==="memories"?"Browse and edit canonical AgentMemory documents.":"Browse the graph and switch views without leaving the workspace.",kicker:m==="graph"?"Graph Studio":m==="memories"?"Memory Browser":"Vocabulary Browser",compact:!0,tabs:d.jsx(Im,{activeView:m,agentMemoryAvailable:F,onSelect:jl}),children:d.jsx(sn,{children:d.jsx(k.Suspense,{fallback:d.jsx(on,{}),children:m==="graph"?d.jsx(sg,{externalFocusNodeId:E?.nodeId,externalFocusToken:E?.token,onDirtyChange:$}):m==="memories"?d.jsx(rg,{onDirtyChange:$}):d.jsx(hg,{})})},`explore-${m}`)}):c==="analyze"?d.jsx(rn,{title:"Analyze",subtitle:"Query the active graph and test inference rules.",kicker:B==="reasoning"?"Reasoning Engine":"SPARQL Query",tabs:d.jsxs(d.Fragment,{children:[d.jsx("button",{className:"workspace-tab","data-active":B==="reasoning",onClick:()=>Y("reasoning"),children:"Reasoning Playground"}),d.jsx("button",{className:"workspace-tab","data-active":B==="sparql",onClick:()=>Y("sparql"),children:"SPARQL Querying"})]}),children:d.jsx(sn,{children:d.jsx(k.Suspense,{fallback:d.jsx(on,{}),children:B==="reasoning"?d.jsx(mg,{}):d.jsx(gg,{})})},`analyze-${B}`)}):c==="decisions"?d.jsx(rn,{title:"Decisions",subtitle:"Inspect decision chains, causal context, and precedent matches.",kicker:"Decision Intelligence",children:d.jsx(sn,{children:d.jsx(k.Suspense,{fallback:d.jsx(on,{}),children:d.jsx(cg,{})})},"decisions")}):c==="enrich"?d.jsx(rn,{title:"Enrich",subtitle:"Import, export, reconcile, and audit graph entities.",kicker:"Knowledge Audit",tabs:d.jsxs(d.Fragment,{children:[d.jsx("button",{className:"workspace-tab","data-active":R==="import",onClick:()=>M("import"),children:"Import and Export"}),d.jsx("button",{className:"workspace-tab","data-active":R==="merge",onClick:()=>M("merge"),children:"Diff and Merge"}),d.jsx("button",{className:"workspace-tab","data-active":R==="resolve",onClick:()=>M("resolve"),children:"Entity Resolution"}),d.jsx("button",{className:"workspace-tab","data-active":R==="registry",onClick:()=>M("registry"),children:"Registry"})]}),children:d.jsx(sn,{children:d.jsx(k.Suspense,{fallback:d.jsx(on,{}),children:R==="import"?d.jsx(og,{}):R==="merge"?d.jsx(fg,{}):R==="resolve"?d.jsx(pg,{}):d.jsx(yg,{})})},`enrich-${R}`)}):c==="ontology-hub"?d.jsx(rn,{title:"Ontology Hub",subtitle:"Load, browse, edit, and govern ontologies and vocabularies.",kicker:"Schema Governance",compact:!0,children:d.jsx(sn,{children:d.jsx(k.Suspense,{fallback:d.jsx(on,{}),children:d.jsx(xg,{onJumpToGraphNode:q=>{C({nodeId:q,token:Date.now()}),T("explore"),D("graph")}})})},"ontology-hub")}):d.jsx(rn,{title:"Manage",subtitle:"Review provenance, lineage, ontology, and governance context.",kicker:"Graph Governance",tabs:d.jsxs(d.Fragment,{children:[d.jsx("button",{className:"workspace-tab","data-active":b==="lineage",onClick:()=>w("lineage"),children:"PROV-O Lineage"}),d.jsx("button",{className:"workspace-tab","data-active":b==="kg-overview",onClick:()=>w("kg-overview"),children:"KG Overview"}),d.jsx("button",{className:"workspace-tab","data-active":b==="ontology",onClick:()=>w("ontology"),children:"Ontology Summary"})]}),children:d.jsx(sn,{children:d.jsx(k.Suspense,{fallback:d.jsx(on,{}),children:b==="lineage"?d.jsx(dg,{}):b==="kg-overview"?d.jsx(bg,{}):d.jsx(vg,{onOpenVocabularyBrowser:()=>{T("explore"),D("vocabulary")}})})},`manage-${b}`)}),s[10]=c,s[11]=F,s[12]=B,s[13]=R,s[14]=m,s[15]=E?.nodeId,s[16]=E?.token,s[17]=b,s[18]=jl,s[19]=Hl):Hl=s[19];const Jl=Hl;let Bl;s[20]===Symbol.for("react.memo_cache_sentinel")?(Bl=d.jsx("style",{children:Tg}),s[20]=Bl):Bl=s[20];let rl;s[21]!==dl?(rl=()=>dl("welcome"),s[21]=dl,s[22]=rl):rl=s[22];let Fl;s[23]===Symbol.for("react.memo_cache_sentinel")?(Fl={cursor:"pointer",border:"1px solid rgba(127,208,255,0.18)"},s[23]=Fl):Fl=s[23];let Ll;s[24]!==rl?(Ll=d.jsx("button",{className:"brand-pill",title:"Semantica Knowledge Explorer",onClick:rl,style:Fl,children:"SKE"}),s[24]=rl,s[25]=Ll):Ll=s[25];let zl;s[26]!==c||s[27]!==dl?(zl=Ag.map(q=>{const{id:X,label:vl,hint:al,icon:V}=q;return d.jsxs("button",{className:"nav-button","data-active":c===X,onClick:()=>dl(X),title:al,children:[d.jsx(V,{size:20}),d.jsx("span",{className:"nav-label",children:vl})]},X)}),s[26]=c,s[27]=dl,s[28]=zl):zl=s[28];let x;s[29]!==zl||s[30]!==Ll?(x=d.jsxs("aside",{className:"app-rail",children:[Ll,zl]}),s[29]=zl,s[30]=Ll,s[31]=x):x=s[31];let A;s[32]!==Jl?(A=Jl(),s[32]=Jl,s[33]=A):A=s[33];let j;return s[34]!==x||s[35]!==A?(j=d.jsxs(mm,{client:zg,children:[Bl,d.jsxs("div",{className:"app-shell",children:[x,A]})]}),s[34]=x,s[35]=A,s[36]=j):j=s[36],j}xm.createRoot(document.getElementById("root")).render(d.jsx(Cg,{}));export{Zd as A,Ld as B,Cm as C,Pd as G,Hf as N,l0 as S,ia as _,Km as a,ua as b,ti as c,qg as d,Bg as e,pm as f,ig as r,Rg as w};
